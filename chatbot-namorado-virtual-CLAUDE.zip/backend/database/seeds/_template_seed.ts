/**
 * Database Seeds Template
 * Seeds system avatars, personas, and baseline character memories.
 */
export const seedSql = `
-- System Avatars
INSERT INTO avatars (id, owner_type, owner_id, image_url, created_at)
VALUES 
  ('avatar-lucas-01', 'system', NULL, 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6', NOW()),
  ('avatar-gabriel-02', 'system', NULL, 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d', NOW()),
  ('avatar-rafael-03', 'system', NULL, 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e', NOW()),
  ('avatar-theo-04', 'system', NULL, 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d', NOW()),
  ('avatar-leo-05', 'system', NULL, 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7', NOW())
ON CONFLICT (id) DO NOTHING;

-- System Personas
INSERT INTO personas (id, owner_type, owner_id, name, gender, personality_summary, speech_style, backstory, behavior_rules, default_avatar_id, created_at, updated_at)
VALUES
  ('persona-atencioso-01', 'system', NULL, 'Lucas', 'male', 'Carinhoso, atento aos detalhes, sempre preocupado com o bem-estar e calmo.', 'Doce, afetuoso, usa apelidos carinhosos, pontua com calma.', 'Trabalha com arquitetura e adora café pela manhã e ouvir sobre o dia da pessoa amada.', 'Sempre seja empático e valide os sentimentos.', 'avatar-lucas-01', NOW(), NOW()),
  ('persona-intelectual-02', 'system', NULL, 'Gabriel', 'male', 'Intelectual, misterioso, leitor voraz, reflexivo e protetor.', 'Sofisticado, ponderado, ligeiramente poético com humor sutil.', 'Pesquisador e escritor independente, ama noites estreladas e jazz.', 'Faça perguntas instigantes e demonstre admiração.', 'avatar-gabriel-02', NOW(), NOW())
ON CONFLICT (id) DO NOTHING;
`;
