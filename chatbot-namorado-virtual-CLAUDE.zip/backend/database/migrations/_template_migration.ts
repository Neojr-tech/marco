/**
 * Database Migrations Template & Sequence Order:
 * 
 * Order of Migrations (as mandated by Section 25):
 * 1. users
 * 2. avatars
 * 3. personas
 * 4. characters
 * 5. conversations
 * 6. participants
 * 7. messages
 * 8. conversation_memories
 * 9. character_memories
 * 10. user_memories
 * 11. relationships
 * 12. subscriptions
 * 
 * (group_memories remains future)
 */

export const migrationSql = `
-- 1. USERS
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255),
  display_name VARCHAR(255) NOT NULL,
  birth_date DATE,
  auth_provider VARCHAR(50) DEFAULT 'email',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  status VARCHAR(50) DEFAULT 'active',
  onboarding_completed_at TIMESTAMP WITH TIME ZONE
);

-- 2. AVATARS
CREATE TABLE IF NOT EXISTS avatars (
  id UUID PRIMARY KEY,
  owner_type VARCHAR(50) NOT NULL,
  owner_id UUID,
  image_url TEXT NOT NULL,
  voice_ref VARCHAR(255),
  video_ref VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. PERSONAS
CREATE TABLE IF NOT EXISTS personas (
  id UUID PRIMARY KEY,
  owner_type VARCHAR(50) NOT NULL,
  owner_id UUID,
  name VARCHAR(255) NOT NULL,
  gender VARCHAR(50) NOT NULL,
  personality_summary TEXT NOT NULL,
  speech_style TEXT NOT NULL,
  backstory TEXT NOT NULL,
  behavior_rules TEXT NOT NULL,
  default_avatar_id UUID REFERENCES avatars(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. CHARACTERS
CREATE TABLE IF NOT EXISTS characters (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  persona_id UUID NOT NULL REFERENCES personas(id),
  avatar_id UUID NOT NULL REFERENCES avatars(id),
  nickname VARCHAR(255) NOT NULL,
  ai_config_override JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  archived_at TIMESTAMP WITH TIME ZONE
);

-- 5. CONVERSATIONS
CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL,
  title VARCHAR(255) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_message_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  status VARCHAR(50) DEFAULT 'active'
);

-- 6. PARTICIPANTS
CREATE TABLE IF NOT EXISTS participants (
  id UUID PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  character_id UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  role_in_group VARCHAR(50),
  CONSTRAINT unique_conversation_participant UNIQUE (conversation_id, character_id)
);

-- 7. MESSAGES
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_type VARCHAR(50) NOT NULL,
  sender_id UUID NOT NULL,
  content TEXT NOT NULL,
  content_type VARCHAR(50) DEFAULT 'text',
  media_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  reply_to_message_id UUID REFERENCES messages(id)
);

-- 8. CONVERSATION_MEMORIES
CREATE TABLE IF NOT EXISTS conversation_memories (
  id UUID PRIMARY KEY,
  conversation_id UUID UNIQUE NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  summary TEXT NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 9. CHARACTER_MEMORIES
CREATE TABLE IF NOT EXISTS character_memories (
  id UUID PRIMARY KEY,
  persona_id UUID NOT NULL REFERENCES personas(id) ON DELETE CASCADE,
  fact TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 10. USER_MEMORIES
CREATE TABLE IF NOT EXISTS user_memories (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  fact TEXT NOT NULL,
  source_message_id UUID REFERENCES messages(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 11. RELATIONSHIPS
CREATE TABLE IF NOT EXISTS relationships (
  id UUID PRIMARY KEY,
  subject_type VARCHAR(50) NOT NULL,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  character_id UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  related_character_id UUID REFERENCES characters(id) ON DELETE CASCADE,
  level INTEGER DEFAULT 1,
  milestones JSONB,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  CONSTRAINT unique_user_character_relationship UNIQUE (user_id, character_id)
);

-- 12. SUBSCRIPTIONS (Prepared Structure)
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan VARCHAR(50) NOT NULL,
  status VARCHAR(50) NOT NULL,
  started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  ends_at TIMESTAMP WITH TIME ZONE
);
`;
