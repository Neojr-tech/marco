export type RelationshipSubjectType = 'user_character' | 'character_character';

export interface Relationship {
  id: string; // UUID PK
  subject_type: RelationshipSubjectType;
  user_id: string | null; // FK -> users.id (when user_character)
  character_id: string; // FK -> characters.id
  related_character_id: string | null; // FK -> characters.id (future for character_character)
  level: number; // gamification: A DEFINIR
  milestones: Record<string, any> | string[]; // gamification: A DEFINIR
  updated_at: string;
}

export type CreateRelationshipInput = {
  subject_type: RelationshipSubjectType;
  user_id?: string | null;
  character_id: string;
  related_character_id?: string | null;
  level?: number;
  milestones?: Record<string, any> | string[];
};
