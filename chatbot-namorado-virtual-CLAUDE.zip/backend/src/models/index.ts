import { v4 as uuidv4 } from 'uuid';
import { User, CreateUserInput } from './user.model.js';
import { Avatar, CreateAvatarInput } from './avatar.model.js';
import { Persona, CreatePersonaInput } from './persona.model.js';
import { Character, CreateCharacterInput } from './character.model.js';
import { Conversation, CreateConversationInput } from './conversation.model.js';
import { Participant, CreateParticipantInput } from './participant.model.js';
import { Message, CreateMessageInput } from './message.model.js';
import {
  ConversationMemory,
  CharacterMemory,
  UserMemory,
  GroupMemory,
} from './memory.model.js';
import { Relationship, CreateRelationshipInput } from './relationship.model.js';
import { Subscription } from './subscription.model.js';

export * from './user.model.js';
export * from './avatar.model.js';
export * from './persona.model.js';
export * from './character.model.js';
export * from './conversation.model.js';
export * from './participant.model.js';
export * from './message.model.js';
export * from './memory.model.js';
export * from './relationship.model.js';
export * from './subscription.model.js';

// In-Memory Database Store with initial seed data matching PostgreSQL relational structure
class DatabaseStore {
  public users: Map<string, User> = new Map();
  public avatars: Map<string, Avatar> = new Map();
  public personas: Map<string, Persona> = new Map();
  public characters: Map<string, Character> = new Map();
  public conversations: Map<string, Conversation> = new Map();
  public participants: Map<string, Participant> = new Map();
  public messages: Map<string, Message> = new Map();
  public conversationMemories: Map<string, ConversationMemory> = new Map(); // key = conversation_id
  public characterMemories: Map<string, CharacterMemory[]> = new Map(); // key = persona_id
  public userMemories: Map<string, UserMemory[]> = new Map(); // key = user_id
  public groupMemories: Map<string, GroupMemory> = new Map(); // key = conversation_id
  public relationships: Map<string, Relationship> = new Map(); // key = `${userId}_${characterId}`
  public subscriptions: Map<string, Subscription> = new Map();

  constructor() {
    this.seedInitialData();
  }

  public seedInitialData() {
    // 1. Seed System Avatars
    const defaultAvatars: Avatar[] = [
      {
        id: 'avatar-lucas-01',
        owner_type: 'system',
        owner_id: null,
        image_url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=600&q=80',
        voice_ref: null,
        video_ref: null,
        created_at: new Date().toISOString(),
      },
      {
        id: 'avatar-gabriel-02',
        owner_type: 'system',
        owner_id: null,
        image_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
        voice_ref: null,
        video_ref: null,
        created_at: new Date().toISOString(),
      },
      {
        id: 'avatar-rafael-03',
        owner_type: 'system',
        owner_id: null,
        image_url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80',
        voice_ref: null,
        video_ref: null,
        created_at: new Date().toISOString(),
      },
      {
        id: 'avatar-theo-04',
        owner_type: 'system',
        owner_id: null,
        image_url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=600&q=80',
        voice_ref: null,
        video_ref: null,
        created_at: new Date().toISOString(),
      },
      {
        id: 'avatar-leo-05',
        owner_type: 'system',
        owner_id: null,
        image_url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=600&q=80',
        voice_ref: null,
        video_ref: null,
        created_at: new Date().toISOString(),
      },
    ];

    defaultAvatars.forEach((a) => this.avatars.set(a.id, a));

    // 2. Seed System Personas
    const defaultPersonas: Persona[] = [
      {
        id: 'persona-atencioso-01',
        owner_type: 'system',
        owner_id: null,
        name: 'Lucas',
        gender: 'male',
        personality_summary: 'Carinhoso, atento aos detalhes, sempre preocupado com o bem-estar e calmo.',
        speech_style: 'Doce, afetuoso, usa apelidos carinhosos, pontua com calma e demonstra interesse genuíno.',
        backstory: 'Trabalha com arquitetura e adora café pela manhã, dias chuvosos e ouvir sobre como foi o dia da pessoa amada.',
        behavior_rules: 'Sempre pergunte como o usuário está se sentindo, seja empático, valide os sentimentos e nunca seja agressivo ou frio.',
        default_avatar_id: 'avatar-lucas-01',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
      {
        id: 'persona-intelectual-02',
        owner_type: 'system',
        owner_id: null,
        name: 'Gabriel',
        gender: 'male',
        personality_summary: 'Intelectual, misterioso, leitor voraz, reflexivo e protetor.',
        speech_style: 'Sofisticado, ponderado, ligeiramente poético com humor sutil e charme inteligente.',
        backstory: 'Pesquisador e escritor independente, ama noites estreladas, jazz e conversas profundas até a madrugada.',
        behavior_rules: 'Faça perguntas instigantes, compartilhe reflexões poéticas leves, demonstre admiração pela inteligência do parceiro.',
        default_avatar_id: 'avatar-gabriel-02',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
      {
        id: 'persona-aventureiro-03',
        owner_type: 'system',
        owner_id: null,
        name: 'Rafael',
        gender: 'male',
        personality_summary: 'Aventureiro, divertido, enérgico, espontâneo e otimista contagiante.',
        speech_style: 'Descontraído, usa gírias leves, muito expressivo com risadas e emojis alegres.',
        backstory: 'Fotógrafo de natureza e amante de esportes ao ar livre, adora planejar passeios de surpresa e viagens.',
        behavior_rules: 'Mantenha o astral elevado, convide para sonhar com planos juntos, seja leal e encorajador.',
        default_avatar_id: 'avatar-rafael-03',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
      {
        id: 'persona-artista-04',
        owner_type: 'system',
        owner_id: null,
        name: 'Theo',
        gender: 'male',
        personality_summary: 'Sensível, músico, romântico incorrigível, empático e sonhador.',
        speech_style: 'Romântico, melódico, expressa carinho através de metáforas e aprecia arte e sentimentos sinceros.',
        backstory: 'Compositor e guitarrista, escreve músicas inspiradas na pessoa que ama e adora noites aconchegantes.',
        behavior_rules: 'Dedique pequenos pensamentos românticos, seja sincero nas emoções, mostre vulnerabilidade saudável.',
        default_avatar_id: 'avatar-theo-04',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ];

    defaultPersonas.forEach((p) => {
      this.personas.set(p.id, p);
      // Seed initial character memories for fixed persona traits
      this.characterMemories.set(p.id, [
        {
          id: uuidv4(),
          persona_id: p.id,
          fact: `Gosta de mandar mensagens de bom dia e lembrar de momentos especiais.`,
          created_at: new Date().toISOString(),
        },
        {
          id: uuidv4(),
          persona_id: p.id,
          fact: `Tem hábitos e gostos consistentes alinhados com sua história de vida.`,
          created_at: new Date().toISOString(),
        },
      ]);
    });
  }

  // Helper Methods
  public findUserByEmail(email: string): User | undefined {
    return Array.from(this.users.values()).find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserById(id: string): User | undefined {
    return this.users.get(id);
  }

  public findCharacterById(id: string): Character | undefined {
    return this.characters.get(id);
  }

  public findPersonaById(id: string): Persona | undefined {
    return this.personas.get(id);
  }

  public findAvatarById(id: string): Avatar | undefined {
    return this.avatars.get(id);
  }

  public getCharactersByUserId(userId: string): Character[] {
    return Array.from(this.characters.values()).filter(
      (c) => c.user_id === userId && !c.archived_at
    );
  }

  public getConversationById(id: string): Conversation | undefined {
    return this.conversations.get(id);
  }

  public getParticipantsByConversationId(conversationId: string): Participant[] {
    return Array.from(this.participants.values()).filter(
      (p) => p.conversation_id === conversationId
    );
  }

  public getMessagesByConversationId(conversationId: string): Message[] {
    return Array.from(this.messages.values())
      .filter((m) => m.conversation_id === conversationId)
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  }

  public getConversationMemory(conversationId: string): ConversationMemory | undefined {
    return this.conversationMemories.get(conversationId);
  }

  public getCharacterMemories(personaId: string): CharacterMemory[] {
    return this.characterMemories.get(personaId) || [];
  }

  public getUserMemories(userId: string): UserMemory[] {
    return this.userMemories.get(userId) || [];
  }

  public getRelationship(userId: string, characterId: string): Relationship | undefined {
    const key = `${userId}_${characterId}`;
    return this.relationships.get(key);
  }
}

export const db = new DatabaseStore();
