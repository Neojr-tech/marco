export interface Participant {
  id: string; // UUID PK
  conversation_id: string; // FK -> conversations.id
  character_id: string; // FK -> characters.id
  joined_at: string;
  role_in_group: string | null; // future for group chats (A DEFINIR)
}

export type CreateParticipantInput = {
  conversation_id: string;
  character_id: string;
  role_in_group?: string | null;
};
