/**
 * Memory Models
 * Layers: ConversationMemory, CharacterMemory, UserMemory, GroupMemory (future)
 */

export interface ConversationMemory {
  id: string; // UUID PK
  conversation_id: string; // FK -> conversations.id (unique 0..1 per conversation)
  summary: string;
  updated_at: string;
}

export interface CharacterMemory {
  id: string; // UUID PK
  persona_id: string; // FK -> personas.id
  fact: string;
  created_at: string;
}

export interface UserMemory {
  id: string; // UUID PK
  user_id: string; // FK -> users.id
  fact: string;
  source_message_id: string | null; // FK -> messages.id nullable
  created_at: string;
}

export interface GroupMemory {
  id: string; // UUID PK
  conversation_id: string; // FK -> conversations.id
  group_summary: string;
  dynamics_notes: string;
  created_at: string;
  updated_at: string;
}
