export type ConversationType = 'individual' | 'group';
export type ConversationStatus = 'active' | 'archived' | 'closed';

export interface Conversation {
  id: string; // UUID PK
  user_id: string; // FK -> users.id
  type: ConversationType;
  title: string;
  created_at: string;
  last_message_at: string;
  status: ConversationStatus;
}

export type CreateConversationInput = {
  user_id: string;
  type: ConversationType;
  title: string;
  status?: ConversationStatus;
};
