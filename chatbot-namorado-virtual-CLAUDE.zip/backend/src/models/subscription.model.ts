/**
 * Subscription Entity (Prepared structure for future monetization)
 * No payment logic or monetization enforced in prototype.
 */
export type SubscriptionPlan = 'free' | 'premium' | 'vip' | string; // A DEFINIR
export type SubscriptionStatus = 'active' | 'cancelled' | 'expired' | 'trial';

export interface Subscription {
  id: string; // UUID PK
  user_id: string; // FK -> users.id
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  started_at: string;
  ends_at: string | null;
}
