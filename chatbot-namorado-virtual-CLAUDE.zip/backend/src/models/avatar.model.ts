export type AvatarOwnerType = 'system' | 'user';

export interface Avatar {
  id: string; // UUID PK
  owner_type: AvatarOwnerType;
  owner_id: string | null; // nullable when system
  image_url: string;
  voice_ref: string | null; // future (A DEFINIR)
  video_ref: string | null; // future (A DEFINIR)
  created_at: string;
}

export type CreateAvatarInput = Omit<Avatar, 'id' | 'created_at'>;
