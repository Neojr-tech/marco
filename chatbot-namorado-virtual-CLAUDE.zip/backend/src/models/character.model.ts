export interface Character {
  id: string; // UUID PK
  user_id: string; // FK -> users.id
  persona_id: string; // FK -> personas.id
  avatar_id: string; // FK -> avatars.id
  nickname: string;
  ai_config_override: Record<string, any> | null; // future
  created_at: string;
  archived_at: string | null;
}

export type CreateCharacterInput = {
  user_id: string;
  persona_id: string;
  avatar_id: string;
  nickname: string;
  ai_config_override?: Record<string, any> | null;
};
