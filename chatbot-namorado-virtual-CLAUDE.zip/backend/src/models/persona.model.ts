export type PersonaOwnerType = 'system' | 'user';
export type PersonaGender = 'male' | 'female' | 'non_binary' | string; // Gênero: A DEFINIR valores exatos

export interface Persona {
  id: string; // UUID PK
  owner_type: PersonaOwnerType;
  owner_id: string | null; // nullable when system
  name: string;
  gender: PersonaGender;
  personality_summary: string;
  speech_style: string;
  backstory: string;
  behavior_rules: string;
  default_avatar_id: string | null;
  created_at: string;
  updated_at: string;
}

export type CreatePersonaInput = Omit<Persona, 'id' | 'created_at' | 'updated_at'>;
