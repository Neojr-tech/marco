export type UserAuthProvider = 'email' | 'google' | 'apple';
export type UserStatus = 'active' | 'suspended' | 'deleted';

export interface User {
  id: string; // UUID PK
  email: string;
  password_hash: string | null;
  display_name: string;
  birth_date: string | null; // date
  auth_provider: UserAuthProvider;
  created_at: string; // timestamp
  updated_at: string; // timestamp
  status: UserStatus;
  onboarding_completed_at: string | null; // timestamp nullable
}

export type CreateUserInput = Omit<User, 'id' | 'created_at' | 'updated_at' | 'status' | 'onboarding_completed_at'> & {
  password?: string;
  status?: UserStatus;
};
