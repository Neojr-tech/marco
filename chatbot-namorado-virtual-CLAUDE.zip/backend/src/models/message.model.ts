export type MessageSenderType = 'user' | 'character';
export type MessageContentType = 'text' | 'image' | 'audio' | 'video';

export interface Message {
  id: string; // UUID PK
  conversation_id: string; // FK -> conversations.id
  sender_type: MessageSenderType;
  sender_id: string; // User.id or Character.id
  content: string;
  content_type: MessageContentType; // In initial prototype, only 'text' is active
  media_url: string | null;
  created_at: string;
  reply_to_message_id: string | null;
}

export type CreateMessageInput = {
  conversation_id: string;
  sender_type: MessageSenderType;
  sender_id: string;
  content: string;
  content_type?: MessageContentType;
  media_url?: string | null;
  reply_to_message_id?: string | null;
};
