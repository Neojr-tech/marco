import { Router, Response, NextFunction } from 'express';
import { authMiddleware, AuthenticatedRequest } from '../middleware/auth.middleware.js';
import { characterService } from '../services/character/character.service.js';
import { personaService } from '../services/character/persona.service.js';
import { avatarService } from '../services/character/avatar.service.js';
import { characterMemoryService } from '../services/memory/character_memory.service.js';

const router = Router();

// GET /api/characters/avatars - List available avatars (system + user owned)
router.get('/avatars', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const avatars = await avatarService.listAvatars(req.user?.id);
    res.json({ avatars });
  } catch (err) {
    next(err);
  }
});

// POST /api/characters/avatars - Create custom avatar
router.post('/avatars', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { imageUrl, voiceRef, videoRef } = req.body;
    if (!imageUrl) {
      res.status(400).json({ error: 'URL da imagem do avatar é obrigatória.' });
      return;
    }
    const avatar = await avatarService.createAvatar({
      owner_type: 'user',
      owner_id: req.user!.id,
      image_url: imageUrl,
      voice_ref: voiceRef,
      video_ref: videoRef,
    });
    res.status(201).json({ avatar });
  } catch (err) {
    next(err);
  }
});

// GET /api/characters/personas - List preset or user personas
router.get('/personas', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const personas = await personaService.listPersonas(req.user?.id);
    res.json({ personas });
  } catch (err) {
    next(err);
  }
});

// POST /api/characters/personas - Create custom persona
router.post('/personas', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { name, gender, personalitySummary, speechStyle, backstory, behaviorRules, defaultAvatarId, initialMemories } = req.body;
    if (!name || !personalitySummary) {
      res.status(400).json({ error: 'Nome e resumo de personalidade são obrigatórios.' });
      return;
    }
    const persona = await personaService.createPersona({
      owner_type: 'user',
      owner_id: req.user!.id,
      name,
      gender: gender || 'male',
      personality_summary: personalitySummary,
      speech_style: speechStyle || 'Carinhoso e amigável',
      backstory: backstory || '',
      behavior_rules: behaviorRules || 'Seja respeitoso e acolhedor.',
      default_avatar_id: defaultAvatarId || null,
      initial_memories: initialMemories || [],
    });
    res.status(201).json({ persona });
  } catch (err) {
    next(err);
  }
});

// GET /api/characters - List user characters
router.get('/', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const characters = await characterService.listUserCharacters(req.user!.id);
    res.json({ characters });
  } catch (err) {
    next(err);
  }
});

// GET /api/characters/:id - Get character details
router.get('/:id', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const character = await characterService.getCharacterById(req.params.id);
    if (!character || character.user_id !== req.user!.id) {
      res.status(404).json({ error: 'Personagem não encontrado.' });
      return;
    }
    const memories = await characterMemoryService.getMemories(character.persona_id);
    res.json({ character, memories });
  } catch (err) {
    next(err);
  }
});

// POST /api/characters - Create character linking User + Persona + Avatar
router.post('/', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { personaId, avatarId, nickname, aiConfigOverride } = req.body;
    if (!personaId || !avatarId) {
      res.status(400).json({ error: 'personaId e avatarId são obrigatórios.' });
      return;
    }
    const character = await characterService.createCharacter({
      user_id: req.user!.id,
      persona_id: personaId,
      avatar_id: avatarId,
      nickname: nickname || '',
      ai_config_override: aiConfigOverride,
    });
    res.status(201).json({ character });
  } catch (err) {
    next(err);
  }
});

export default router;
