import { Router, Response, NextFunction } from 'express';
import { authMiddleware, AuthenticatedRequest } from '../middleware/auth.middleware.js';
import { userService } from '../services/user/user.service.js';
import { userMemoryService } from '../services/memory/user_memory.service.js';

const router = Router();

// GET /api/user/me
router.get('/me', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const user = req.user!;
    const memories = await userMemoryService.getMemories(user.id);
    res.json({ user, memories });
  } catch (err) {
    next(err);
  }
});

// POST /api/user/onboarding/complete
router.post('/onboarding/complete', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const updated = await userService.completeOnboarding(req.user!.id);
    res.json({ user: updated });
  } catch (err) {
    next(err);
  }
});

// PATCH /api/user/profile
router.patch('/profile', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { displayName, birthDate } = req.body;
    const updated = await userService.updateProfile(req.user!.id, {
      display_name: displayName,
      birth_date: birthDate,
    });
    res.json({ user: updated });
  } catch (err) {
    next(err);
  }
});

export default router;
