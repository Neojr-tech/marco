import { Router, Request, Response, NextFunction } from 'express';
import { authService } from '../services/auth/auth.service.js';

const router = Router();

// POST /api/auth/register
router.post('/register', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { email, password, displayName, birthDate, authProvider } = req.body;
    if (!email || !displayName) {
      res.status(400).json({ error: 'E-mail e nome de exibição são obrigatórios.' });
      return;
    }
    const result = await authService.register({
      email,
      password,
      displayName,
      birthDate,
      authProvider,
    });
    res.status(201).json(result);
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/login
router.post('/login', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { email, password } = req.body;
    if (!email) {
      res.status(400).json({ error: 'E-mail é obrigatório.' });
      return;
    }
    const result = await authService.login({ email, password });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

export default router;
