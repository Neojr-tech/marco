import { Router, Response, NextFunction } from 'express';
import { authMiddleware, AuthenticatedRequest } from '../middleware/auth.middleware.js';
import { individualChatService } from '../services/chat/individual_chat.service.js';

const router = Router();

// POST /api/chat/individual/session - Start or retrieve individual chat with character
router.post('/individual/session', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { characterId } = req.body;
    if (!characterId) {
      res.status(400).json({ error: 'characterId é obrigatório.' });
      return;
    }
    const session = await individualChatService.getOrCreateConversation(req.user!.id, characterId);
    res.json(session);
  } catch (err) {
    next(err);
  }
});

// POST /api/chat/individual/message - Send message to character and receive AI reply
router.post('/individual/message', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { conversationId, content, replyToMessageId } = req.body;
    if (!conversationId || !content || !content.trim()) {
      res.status(400).json({ error: 'conversationId e content são obrigatórios.' });
      return;
    }
    const result = await individualChatService.sendMessage({
      userId: req.user!.id,
      conversationId,
      content,
      replyToMessageId,
    });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

export default router;
