import { Router, Response, NextFunction } from 'express';
import { authMiddleware, AuthenticatedRequest } from '../middleware/auth.middleware.js';
import { groupChatService } from '../services/chat/group_chat.service.js';

const router = Router();

// POST /api/group/create (Prepared Architecture)
router.post('/create', authMiddleware, async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const { title, characterIds } = req.body;
    if (!title || !characterIds || !Array.isArray(characterIds)) {
      res.status(400).json({ error: 'title e characterIds (array) são obrigatórios.' });
      return;
    }
    const groupConversation = await groupChatService.createGroupConversation({
      userId: req.user!.id,
      title,
      characterIds,
    });
    res.status(201).json({ groupConversation, note: 'Arquitetura de grupo preparada.' });
  } catch (err) {
    next(err);
  }
});

export default router;
