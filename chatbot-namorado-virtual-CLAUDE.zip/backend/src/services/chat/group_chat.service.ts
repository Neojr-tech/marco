import { v4 as uuidv4 } from 'uuid';
import { db, Conversation, Participant, Message } from '../../models/index.js';

/**
 * Group Chat Service (Prepared Architecture)
 * Rule 4: Group conversation possesses 2 or more character participants.
 * Role in group and group turn orchestration are prepared.
 */
export class GroupChatService {
  public async createGroupConversation(input: {
    userId: string;
    title: string;
    characterIds: string[];
  }): Promise<Conversation> {
    if (input.characterIds.length < 2) {
      throw new Error('Regra de integridade: Conversas em grupo devem conter pelo menos 2 personagens.');
    }

    const now = new Date().toISOString();
    const conversation: Conversation = {
      id: uuidv4(),
      user_id: input.userId,
      type: 'group',
      title: input.title,
      created_at: now,
      last_message_at: now,
      status: 'active',
    };
    db.conversations.set(conversation.id, conversation);

    for (const charId of input.characterIds) {
      const participant: Participant = {
        id: uuidv4(),
        conversation_id: conversation.id,
        character_id: charId,
        joined_at: now,
        role_in_group: 'member',
      };
      db.participants.set(participant.id, participant);
    }

    return conversation;
  }
}

export const groupChatService = new GroupChatService();
