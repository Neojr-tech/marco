import { v4 as uuidv4 } from 'uuid';
import {
  db,
  Conversation,
  Message,
  Participant,
  Character,
  Persona,
  Avatar,
  Relationship,
} from '../../models/index.js';
import { conversationMemoryService } from '../memory/conversation_memory.service.js';
import { characterMemoryService } from '../memory/character_memory.service.js';
import { userMemoryService } from '../memory/user_memory.service.js';
import { relationshipMemoryService } from '../memory/relationship_memory.service.js';
import { aiGateway } from '../ai-gateway/index.js';

export interface ChatSessionPayload {
  conversation: Conversation;
  character: Character & { persona: Persona; avatar: Avatar };
  relationship: Relationship;
  messages: Message[];
  conversationSummary: string;
  characterMemories: string[];
  userMemories: string[];
}

export class IndividualChatService {
  /**
   * Get or start an individual conversation between user and character
   * Integrity Rule 3: Conversation individual possui exatamente 1 personagem.
   */
  public async getOrCreateConversation(
    userId: string,
    characterId: string
  ): Promise<ChatSessionPayload> {
    const character = db.findCharacterById(characterId);
    if (!character || character.archived_at) {
      throw new Error('Personagem não encontrado.');
    }
    const persona = db.findPersonaById(character.persona_id);
    const avatar = db.findAvatarById(character.avatar_id);
    if (!persona || !avatar) {
      throw new Error('Dados de Persona ou Avatar corrompidos.');
    }

    // Find existing individual conversation
    const userConvs = Array.from(db.conversations.values()).filter(
      (c) => c.user_id === userId && c.type === 'individual' && c.status === 'active'
    );

    let conversation: Conversation | undefined;
    for (const c of userConvs) {
      const parts = db.getParticipantsByConversationId(c.id);
      if (parts.length === 1 && parts[0].character_id === characterId) {
        conversation = c;
        break;
      }
    }

    if (!conversation) {
      const now = new Date().toISOString();
      conversation = {
        id: uuidv4(),
        user_id: userId,
        type: 'individual',
        title: `Conversa com ${character.nickname}`,
        created_at: now,
        last_message_at: now,
        status: 'active',
      };
      db.conversations.set(conversation.id, conversation);

      // Add single character participant
      const participant: Participant = {
        id: uuidv4(),
        conversation_id: conversation.id,
        character_id: characterId,
        joined_at: now,
        role_in_group: null,
      };
      db.participants.set(participant.id, participant);

      // Create welcome message from character
      const welcomeMsg: Message = {
        id: uuidv4(),
        conversation_id: conversation.id,
        sender_type: 'character',
        sender_id: characterId,
        content: `Oi amor! Que bom que você veio falar comigo. Estava com saudades. Como você está hoje? ❤️`,
        content_type: 'text',
        media_url: null,
        created_at: now,
        reply_to_message_id: null,
      };
      db.messages.set(welcomeMsg.id, welcomeMsg);
    }

    const messages = db.getMessagesByConversationId(conversation.id);
    const relationship = await relationshipMemoryService.getOrCreateRelationship(userId, characterId);
    const summary = await conversationMemoryService.getSummary(conversation.id);
    const charMems = (await characterMemoryService.getMemories(persona.id)).map((m) => m.fact);
    const userMems = (await userMemoryService.getMemories(userId)).map((m) => m.fact);

    return {
      conversation,
      character: { ...character, persona, avatar },
      relationship,
      messages,
      conversationSummary: summary,
      characterMemories: charMems,
      userMemories: userMems,
    };
  }

  /**
   * Process incoming user message, assemble memory context, call AI Gateway, and record response.
   */
  public async sendMessage(input: {
    userId: string;
    conversationId: string;
    content: string;
    replyToMessageId?: string | null;
  }): Promise<{
    userMessage: Message;
    characterMessage: Message;
    relationship: Relationship;
    contextDebug: {
      provider: string;
      model: string;
      injectedMemoriesCount: number;
    };
  }> {
    const conversation = db.getConversationById(input.conversationId);
    if (!conversation || conversation.user_id !== input.userId) {
      throw new Error('Conversa não encontrada ou não autorizada.');
    }

    const participants = db.getParticipantsByConversationId(conversation.id);
    if (participants.length !== 1) {
      throw new Error('Erro de integridade: conversa individual deve conter exatamente 1 personagem.');
    }

    const characterId = participants[0].character_id;
    const character = db.findCharacterById(characterId);
    if (!character) throw new Error('Personagem não encontrado.');

    const persona = db.findPersonaById(character.persona_id);
    const avatar = db.findAvatarById(character.avatar_id);
    if (!persona || !avatar) throw new Error('Persona ou Avatar associados não encontrados.');

    const now = new Date().toISOString();

    // 1. Record User Message
    const userMessage: Message = {
      id: uuidv4(),
      conversation_id: conversation.id,
      sender_type: 'user',
      sender_id: input.userId,
      content: input.content.trim(),
      content_type: 'text',
      media_url: null,
      created_at: now,
      reply_to_message_id: input.replyToMessageId || null,
    };
    db.messages.set(userMessage.id, userMessage);

    // 2. Extract potential user facts into UserMemory
    const extractedFacts = userMemoryService.extractPotentialFacts(userMessage.content);
    for (const fact of extractedFacts) {
      await userMemoryService.addMemory(input.userId, fact, userMessage.id);
    }

    // 3. Assemble Memory Layers before AI Call
    const conversationSummary = await conversationMemoryService.getSummary(conversation.id);
    const characterMemories = await characterMemoryService.getMemories(persona.id);
    const userMemories = await userMemoryService.getMemories(input.userId);
    const relationship = await relationshipMemoryService.getOrCreateRelationship(input.userId, characterId);

    // 4. Build System Prompt with modular components
    const systemPrompt = `
Você é ${persona.name} (apelido carinhoso: "${character.nickname}"), o namorado virtual do usuário.

## IDENTIDADE E PERSONALIDADE (Persona):
- Gênero: ${persona.gender}
- Resumo da Personalidade: ${persona.personality_summary}
- Estilo de Fala: ${persona.speech_style}
- História e Fundo Pessoal: ${persona.backstory}
- Regras de Comportamento: ${persona.behavior_rules}

## MEMÓRIAS E CONTEXTO ATIVO:
- Vínculo/Nível de Relacionamento: Nível ${relationship.level} (${Array.isArray(relationship.milestones) ? relationship.milestones.join(', ') : 'Início'}).
- Resumo da Conversa (ConversationMemory): ${conversationSummary}
- Fatos Fixos sobre você (CharacterMemory):
${characterMemories.map((m) => `  * ${m.fact}`).join('\n') || '  (Sem fatos extras)'}
- Fatos conhecidos sobre o Usuário (UserMemory):
${userMemories.map((m) => `  * ${m.fact}`).join('\n') || '  (Ainda conhecendo o usuário)'}

## DIRETRIZES DE RESPOSTA:
1. Responda diretamente na voz do personagem, em português brasileiro caloroso, afetuoso e empático.
2. Mantenha as mensagens naturais (1 a 3 parágrafos curtos), condizentes com um app de mensagens real.
3. Demonstre que você se lembra dos fatos do usuário e use termos carinhosos apropriados ao nível de relacionamento.
4. Jamais quebre o personagem ou se identifique como IA genérica.
`.trim();

    // 5. Gather Recent History (last 10 messages)
    const allMessages = db.getMessagesByConversationId(conversation.id);
    const recentMessages = allMessages.slice(-10).map((m) => ({
      role: (m.sender_type === 'user' ? 'user' : 'assistant') as 'user' | 'assistant',
      content: m.content,
    }));

    // 6. Call AI Gateway (isolated behind ai-gateway/ layer)
    const aiResult = await aiGateway.conversation.generateReply({
      systemPrompt,
      messages: recentMessages,
    });

    // 7. Record Character Message
    const characterMessage: Message = {
      id: uuidv4(),
      conversation_id: conversation.id,
      sender_type: 'character',
      sender_id: characterId,
      content: aiResult.reply,
      content_type: 'text',
      media_url: null,
      created_at: new Date().toISOString(),
      reply_to_message_id: userMessage.id,
    };
    db.messages.set(characterMessage.id, characterMessage);

    // 8. Update conversation last message timestamp
    conversation.last_message_at = characterMessage.created_at;
    db.conversations.set(conversation.id, conversation);

    // 9. Advance Relationship Gamification Level
    const updatedRelationship = await relationshipMemoryService.recordInteraction(
      input.userId,
      characterId,
      allMessages.length + 1
    );

    // 10. Update Conversation Memory Summary periodically
    if (allMessages.length > 0 && allMessages.length % 6 === 0) {
      const updatedSummary = `Conversa em andamento abordando o dia a dia, sentimentos mútuos e planos. Mensagens recentes: ${allMessages.length + 1}.`;
      await conversationMemoryService.updateSummary(conversation.id, updatedSummary);
    }

    return {
      userMessage,
      characterMessage,
      relationship: updatedRelationship,
      contextDebug: {
        provider: aiResult.provider,
        model: aiResult.model,
        injectedMemoriesCount: characterMemories.length + userMemories.length,
      },
    };
  }
}

export const individualChatService = new IndividualChatService();
