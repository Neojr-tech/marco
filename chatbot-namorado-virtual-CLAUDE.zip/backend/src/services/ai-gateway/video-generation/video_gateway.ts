/**
 * Video Generation Gateway (Prepared Architecture — Provider A DEFINIR)
 */
export interface VideoGenInput {
  prompt: string;
  avatarRef?: string;
}

export interface VideoGenResult {
  videoUrl: string | null;
  status: 'prepared' | 'active';
}

export class VideoGateway {
  public async generateVideo(input: VideoGenInput): Promise<VideoGenResult> {
    return {
      videoUrl: null,
      status: 'prepared',
    };
  }
}

export const videoGateway = new VideoGateway();
