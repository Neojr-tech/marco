/**
 * Voice Gateway (Prepared Architecture — Provider A DEFINIR)
 */
export interface VoiceInput {
  text: string;
  voiceRef?: string | null;
}

export interface VoiceResult {
  audioUrl: string | null;
  status: 'prepared' | 'active';
}

export class VoiceGateway {
  public async synthesizeSpeech(input: VoiceInput): Promise<VoiceResult> {
    return {
      audioUrl: null,
      status: 'prepared',
    };
  }
}

export const voiceGateway = new VoiceGateway();
