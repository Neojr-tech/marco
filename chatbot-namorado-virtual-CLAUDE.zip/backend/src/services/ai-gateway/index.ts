import { conversationGateway, ConversationGateway } from './conversation/conversation_gateway.js';
import { visionGateway, VisionGateway } from './vision/vision_gateway.js';
import { imageGateway, ImageGateway } from './image-generation/image_gateway.js';
import { videoGateway, VideoGateway } from './video-generation/video_gateway.js';
import { voiceGateway, VoiceGateway } from './voice/voice_gateway.js';

export class AIGateway {
  public conversation: ConversationGateway = conversationGateway;
  public vision: VisionGateway = visionGateway;
  public image: ImageGateway = imageGateway;
  public video: VideoGateway = videoGateway;
  public voice: VoiceGateway = voiceGateway;
}

export const aiGateway = new AIGateway();
export * from './conversation/conversation_gateway.js';
export * from './vision/vision_gateway.js';
export * from './image-generation/image_gateway.js';
export * from './video-generation/video_gateway.js';
export * from './voice/voice_gateway.js';
