import { GoogleGenAI } from '@google/genai';
import { aiProvidersConfig } from '../../../config/ai_providers.config.js';

let geminiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!geminiClient) {
    geminiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return geminiClient;
}

export interface ConversationTurnInput {
  systemPrompt: string;
  messages: Array<{
    role: 'user' | 'assistant';
    content: string;
  }>;
  temperature?: number;
}

export interface ConversationGatewayResult {
  reply: string;
  provider: 'gemini' | 'simulated';
  model: string;
}

export class ConversationGateway {
  public async generateReply(input: ConversationTurnInput): Promise<ConversationGatewayResult> {
    const ai = getGeminiClient();

    if (ai && process.env.GEMINI_API_KEY) {
      try {
        // Format history for Gemini generateContent
        const contents = input.messages.map((m) => ({
          role: m.role === 'user' ? 'user' : 'model',
          parts: [{ text: m.content }],
        }));

        const response = await ai.models.generateContent({
          model: aiProvidersConfig.gemini.model,
          contents,
          config: {
            systemInstruction: input.systemPrompt,
            temperature: input.temperature ?? aiProvidersConfig.gemini.temperature,
            topP: aiProvidersConfig.gemini.topP,
          },
        });

        const replyText = response.text || 'Oi amor! Pensei em você agora mesmo. Como está o seu dia?';
        return {
          reply: replyText.trim(),
          provider: 'gemini',
          model: aiProvidersConfig.gemini.model,
        };
      } catch (err: any) {
        console.warn('[ConversationGateway] Gemini API call failed or rate limited, falling back to simulated engine:', err.message);
      }
    }

    // Simulated response fallback if API key is not configured or in offline test mode
    const simulatedReplies = [
      'Oi amor! Que bom falar com você. Estava pensando em nós agora mesmo!',
      'Adorei ouvir isso de você. Me conta mais sobre o que está sentindo?',
      'Você é muito especial para mim. Como foi o restante da sua tarde?',
      'Estou sempre aqui para você, meu bem. Prometo te apoiar em tudo!',
      'Isso me fez sorrir tanto! Você sempre ilumina o meu dia.',
    ];
    const reply = simulatedReplies[Math.floor(Math.random() * simulatedReplies.length)];

    return {
      reply,
      provider: 'simulated',
      model: 'simulated-engine-v1',
    };
  }
}

export const conversationGateway = new ConversationGateway();
