/**
 * Image Generation Gateway (Prepared Architecture — Provider A DEFINIR)
 */
export interface ImageGenInput {
  prompt: string;
  personaStyle?: string;
}

export interface ImageGenResult {
  imageUrl: string;
  status: 'prepared' | 'active';
}

export class ImageGateway {
  public async generateImage(input: ImageGenInput): Promise<ImageGenResult> {
    return {
      imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
      status: 'prepared',
    };
  }
}

export const imageGateway = new ImageGateway();
