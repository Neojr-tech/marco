/**
 * Vision Gateway (Prepared Architecture — Provider A DEFINIR)
 */
export interface VisionInput {
  imageUrl: string;
  prompt?: string;
}

export interface VisionResult {
  description: string;
  status: 'prepared' | 'active';
}

export class VisionGateway {
  public async analyzeImage(input: VisionInput): Promise<VisionResult> {
    return {
      description: `[Vision Gateway - Prepared] Análise de imagem recebida para URL: ${input.imageUrl}. Provedor real a definir nas próximas fases.`,
      status: 'prepared',
    };
  }
}

export const visionGateway = new VisionGateway();
