import { v4 as uuidv4 } from 'uuid';
import { db, Persona, CreatePersonaInput } from '../../models/index.js';
import { characterMemoryService } from '../memory/character_memory.service.js';

export class PersonaService {
  public async listPersonas(userId?: string): Promise<Persona[]> {
    return Array.from(db.personas.values()).filter(
      (p) => p.owner_type === 'system' || (userId && p.owner_id === userId)
    );
  }

  public async getPersonaById(id: string): Promise<Persona | null> {
    return db.findPersonaById(id) || null;
  }

  public async createPersona(input: {
    owner_type: 'system' | 'user';
    owner_id: string | null;
    name: string;
    gender: string;
    personality_summary: string;
    speech_style: string;
    backstory: string;
    behavior_rules: string;
    default_avatar_id?: string | null;
    initial_memories?: string[];
  }): Promise<Persona> {
    const now = new Date().toISOString();
    const persona: Persona = {
      id: uuidv4(),
      owner_type: input.owner_type,
      owner_id: input.owner_id,
      name: input.name,
      gender: input.gender,
      personality_summary: input.personality_summary,
      speech_style: input.speech_style,
      backstory: input.backstory,
      behavior_rules: input.behavior_rules,
      default_avatar_id: input.default_avatar_id || null,
      created_at: now,
      updated_at: now,
    };

    db.personas.set(persona.id, persona);

    // Initial character memories
    if (input.initial_memories && input.initial_memories.length > 0) {
      for (const fact of input.initial_memories) {
        await characterMemoryService.addMemory(persona.id, fact);
      }
    }

    return persona;
  }
}

export const personaService = new PersonaService();
