import { v4 as uuidv4 } from 'uuid';
import { db, Avatar, CreateAvatarInput } from '../../models/index.js';

export class AvatarService {
  public async listAvatars(userId?: string): Promise<Avatar[]> {
    return Array.from(db.avatars.values()).filter(
      (a) => a.owner_type === 'system' || (userId && a.owner_id === userId)
    );
  }

  public async getAvatarById(id: string): Promise<Avatar | null> {
    return db.findAvatarById(id) || null;
  }

  public async createAvatar(input: {
    owner_type: 'system' | 'user';
    owner_id: string | null;
    image_url: string;
    voice_ref?: string | null;
    video_ref?: string | null;
  }): Promise<Avatar> {
    const avatar: Avatar = {
      id: uuidv4(),
      owner_type: input.owner_type,
      owner_id: input.owner_id,
      image_url: input.image_url,
      voice_ref: input.voice_ref || null,
      video_ref: input.video_ref || null,
      created_at: new Date().toISOString(),
    };
    db.avatars.set(avatar.id, avatar);
    return avatar;
  }
}

export const avatarService = new AvatarService();
