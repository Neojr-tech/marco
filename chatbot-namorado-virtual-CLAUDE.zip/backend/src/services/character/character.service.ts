import { v4 as uuidv4 } from 'uuid';
import { db, Character, Persona, Avatar } from '../../models/index.js';
import { relationshipMemoryService } from '../memory/relationship_memory.service.js';

export interface CharacterWithDetails extends Character {
  persona: Persona;
  avatar: Avatar;
  relationshipLevel: number;
}

export class CharacterService {
  /**
   * List characters belonging to a user with persona and avatar populated
   */
  public async listUserCharacters(userId: string): Promise<CharacterWithDetails[]> {
    const characters = db.getCharactersByUserId(userId);
    const result: CharacterWithDetails[] = [];

    for (const c of characters) {
      const persona = db.findPersonaById(c.persona_id);
      const avatar = db.findAvatarById(c.avatar_id);
      if (persona && avatar) {
        const rel = await relationshipMemoryService.getOrCreateRelationship(userId, c.id);
        result.push({
          ...c,
          persona,
          avatar,
          relationshipLevel: rel.level,
        });
      }
    }

    return result;
  }

  public async getCharacterById(characterId: string): Promise<CharacterWithDetails | null> {
    const c = db.findCharacterById(characterId);
    if (!c || c.archived_at) return null;

    const persona = db.findPersonaById(c.persona_id);
    const avatar = db.findAvatarById(c.avatar_id);
    if (!persona || !avatar) return null;

    const rel = await relationshipMemoryService.getOrCreateRelationship(c.user_id, c.id);
    return {
      ...c,
      persona,
      avatar,
      relationshipLevel: rel.level,
    };
  }

  /**
   * Create a Character linking User + Persona + Avatar
   * Integrity Rule 1: Character ALWAYS has User, Persona, and Avatar.
   */
  public async createCharacter(input: {
    user_id: string;
    persona_id: string;
    avatar_id: string;
    nickname: string;
    ai_config_override?: Record<string, any> | null;
  }): Promise<CharacterWithDetails> {
    const user = db.findUserById(input.user_id);
    if (!user) throw new Error('Usuário inválido para criação de personagem.');

    const persona = db.findPersonaById(input.persona_id);
    if (!persona) throw new Error('Persona não encontrada.');

    const avatar = db.findAvatarById(input.avatar_id);
    if (!avatar) throw new Error('Avatar não encontrado.');

    const character: Character = {
      id: uuidv4(),
      user_id: input.user_id,
      persona_id: input.persona_id,
      avatar_id: input.avatar_id,
      nickname: input.nickname.trim() || persona.name,
      ai_config_override: input.ai_config_override || null,
      created_at: new Date().toISOString(),
      archived_at: null,
    };

    db.characters.set(character.id, character);

    // Initialize Relationship
    const rel = await relationshipMemoryService.getOrCreateRelationship(input.user_id, character.id);

    return {
      ...character,
      persona,
      avatar,
      relationshipLevel: rel.level,
    };
  }

  /**
   * Archive / Soft delete character
   */
  public async archiveCharacter(characterId: string, userId: string): Promise<boolean> {
    const char = db.findCharacterById(characterId);
    if (!char || char.user_id !== userId) {
      throw new Error('Personagem não encontrado ou acesso não autorizado.');
    }
    char.archived_at = new Date().toISOString();
    db.characters.set(char.id, char);
    return true;
  }
}

export const characterService = new CharacterService();
