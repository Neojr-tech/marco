import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { db, User, CreateUserInput } from '../../models/index.js';

export interface AuthTokenPayload {
  userId: string;
  email: string;
  displayName: string;
}

export class AuthService {
  public async register(input: {
    email: string;
    password?: string;
    displayName: string;
    birthDate?: string | null;
    authProvider?: 'email' | 'google' | 'apple';
  }): Promise<{ user: User; token: string }> {
    const existing = db.findUserByEmail(input.email);
    if (existing) {
      throw new Error('E-mail já cadastrado no sistema.');
    }

    const passwordHash = input.password ? await bcrypt.hash(input.password, 10) : null;
    const now = new Date().toISOString();

    const user: User = {
      id: uuidv4(),
      email: input.email,
      password_hash: passwordHash,
      display_name: input.displayName,
      birth_date: input.birthDate || null,
      auth_provider: input.authProvider || 'email',
      created_at: now,
      updated_at: now,
      status: 'active',
      onboarding_completed_at: null,
    };

    db.users.set(user.id, user);

    // Mock/Simple token for session management
    const token = `token_${user.id}_${Date.now()}`;
    return { user, token };
  }

  public async login(input: {
    email: string;
    password?: string;
  }): Promise<{ user: User; token: string }> {
    const user = db.findUserByEmail(input.email);
    if (!user) {
      throw new Error('Usuário ou senha incorretos.');
    }

    if (user.status !== 'active') {
      throw new Error('Conta suspensa ou inativa.');
    }

    if (user.password_hash && input.password) {
      const match = await bcrypt.compare(input.password, user.password_hash);
      if (!match) {
        throw new Error('Usuário ou senha incorretos.');
      }
    }

    const token = `token_${user.id}_${Date.now()}`;
    return { user, token };
  }

  public async validateToken(token: string): Promise<User | null> {
    if (!token) return null;
    const parts = token.split('_');
    if (parts.length >= 2 && parts[0] === 'token') {
      const userId = parts[1];
      const user = db.findUserById(userId);
      if (user && user.status === 'active') {
        return user;
      }
    }
    return null;
  }
}

export const authService = new AuthService();
