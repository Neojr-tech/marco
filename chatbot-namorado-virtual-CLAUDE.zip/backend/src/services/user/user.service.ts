import { db, User } from '../../models/index.js';

export class UserService {
  public async getUserById(userId: string): Promise<User | null> {
    return db.findUserById(userId) || null;
  }

  public async completeOnboarding(userId: string): Promise<User> {
    const user = db.findUserById(userId);
    if (!user) {
      throw new Error('Usuário não encontrado.');
    }
    user.onboarding_completed_at = new Date().toISOString();
    user.updated_at = new Date().toISOString();
    db.users.set(userId, user);
    return user;
  }

  public async updateProfile(userId: string, updates: Partial<Pick<User, 'display_name' | 'birth_date'>>): Promise<User> {
    const user = db.findUserById(userId);
    if (!user) {
      throw new Error('Usuário não encontrado.');
    }
    if (updates.display_name !== undefined) user.display_name = updates.display_name;
    if (updates.birth_date !== undefined) user.birth_date = updates.birth_date;
    user.updated_at = new Date().toISOString();
    db.users.set(userId, user);
    return user;
  }
}

export const userService = new UserService();
