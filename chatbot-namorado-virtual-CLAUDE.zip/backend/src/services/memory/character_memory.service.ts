import { v4 as uuidv4 } from 'uuid';
import { db, CharacterMemory } from '../../models/index.js';

export class CharacterMemoryService {
  /**
   * Retrieve fixed traits and facts for a Persona
   */
  public async getMemories(personaId: string): Promise<CharacterMemory[]> {
    return db.getCharacterMemories(personaId);
  }

  /**
   * Add a fixed fact or memory to a Persona
   */
  public async addMemory(personaId: string, fact: string): Promise<CharacterMemory> {
    const memories = db.getCharacterMemories(personaId);
    const newMemory: CharacterMemory = {
      id: uuidv4(),
      persona_id: personaId,
      fact,
      created_at: new Date().toISOString(),
    };
    memories.push(newMemory);
    db.characterMemories.set(personaId, memories);
    return newMemory;
  }
}

export const characterMemoryService = new CharacterMemoryService();
