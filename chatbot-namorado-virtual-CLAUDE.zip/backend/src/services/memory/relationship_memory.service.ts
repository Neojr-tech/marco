import { v4 as uuidv4 } from 'uuid';
import { db, Relationship } from '../../models/index.js';

export class RelationshipMemoryService {
  /**
   * Get or create initial relationship between a User and a Character
   */
  public async getOrCreateRelationship(userId: string, characterId: string): Promise<Relationship> {
    let rel = db.getRelationship(userId, characterId);
    if (!rel) {
      rel = {
        id: uuidv4(),
        subject_type: 'user_character',
        user_id: userId,
        character_id: characterId,
        related_character_id: null,
        level: 1,
        milestones: ['Primeira conversa iniciada'],
        updated_at: new Date().toISOString(),
      };
      db.relationships.set(`${userId}_${characterId}`, rel);
    }
    return rel;
  }

  /**
   * Increment interaction points / relationship level
   * DECISÃO PROVISÓRIA — A VALIDAR:
   * O uso de level e milestones para gamificação permanece A DEFINIR na especificação.
   * Provisoriamente incrementamos a cada lote de conversas.
   */
  public async recordInteraction(userId: string, characterId: string, messageCount: number): Promise<Relationship> {
    const rel = await this.getOrCreateRelationship(userId, characterId);

    const calculatedLevel = Math.min(10, Math.floor(messageCount / 5) + 1);
    const milestones = Array.isArray(rel.milestones) ? [...rel.milestones] : [];

    if (calculatedLevel >= 2 && !milestones.includes('Conhecendo gostos mútuos')) {
      milestones.push('Conhecendo gostos mútuos');
    }
    if (calculatedLevel >= 4 && !milestones.includes('Primeiro momento carinhoso')) {
      milestones.push('Primeiro momento carinhoso');
    }
    if (calculatedLevel >= 7 && !milestones.includes('Conexão profunda estabelecida')) {
      milestones.push('Conexão profunda estabelecida');
    }

    rel.level = calculatedLevel;
    rel.milestones = milestones;
    rel.updated_at = new Date().toISOString();

    db.relationships.set(`${userId}_${characterId}`, rel);
    return rel;
  }
}

export const relationshipMemoryService = new RelationshipMemoryService();
