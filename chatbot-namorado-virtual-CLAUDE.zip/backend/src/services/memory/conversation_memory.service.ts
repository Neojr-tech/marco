import { v4 as uuidv4 } from 'uuid';
import { db, ConversationMemory } from '../../models/index.js';

export class ConversationMemoryService {
  /**
   * Get memory summary for a conversation
   */
  public async getSummary(conversationId: string): Promise<string> {
    const memory = db.getConversationMemory(conversationId);
    return memory ? memory.summary : 'Início de conversa. Nenhum resumo anterior.';
  }

  /**
   * Update conversation memory summary
   * DECISÃO PROVISÓRIA — A VALIDAR:
   * A regra exata de quando e como atualizar ConversationMemory está A DEFINIR.
   * Provisoriamente atualizamos quando o número de mensagens cresce, resumindo os tópicos principais.
   */
  public async updateSummary(conversationId: string, newSummary: string): Promise<ConversationMemory> {
    const existing = db.getConversationMemory(conversationId);
    const updated: ConversationMemory = {
      id: existing ? existing.id : uuidv4(),
      conversation_id: conversationId,
      summary: newSummary,
      updated_at: new Date().toISOString(),
    };
    db.conversationMemories.set(conversationId, updated);
    return updated;
  }
}

export const conversationMemoryService = new ConversationMemoryService();
