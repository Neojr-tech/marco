import { v4 as uuidv4 } from 'uuid';
import { db, UserMemory } from '../../models/index.js';

export class UserMemoryService {
  /**
   * Get all facts stored about the User
   */
  public async getMemories(userId: string): Promise<UserMemory[]> {
    return db.getUserMemories(userId);
  }

  /**
   * Add a user fact extracted from conversation
   */
  public async addMemory(userId: string, fact: string, sourceMessageId: string | null = null): Promise<UserMemory> {
    const memories = db.getUserMemories(userId);
    const newMemory: UserMemory = {
      id: uuidv4(),
      user_id: userId,
      fact,
      source_message_id: sourceMessageId,
      created_at: new Date().toISOString(),
    };
    memories.push(newMemory);
    db.userMemories.set(userId, memories);
    return newMemory;
  }

  /**
   * Simple rule-based fact extractor (extracts likes/hobbies/names mentioned)
   */
  public extractPotentialFacts(userMessage: string): string[] {
    const facts: string[] = [];
    const lower = userMessage.toLowerCase();

    if (lower.includes('meu nome é') || lower.includes('me chamo')) {
      facts.push(`Usuário mencionou seu nome na mensagem: "${userMessage}"`);
    }
    if (lower.includes('eu gosto de') || lower.includes('adoro') || lower.includes('amo')) {
      facts.push(`Preferência compartilhada: "${userMessage}"`);
    }
    if (lower.includes('meu aniversário') || lower.includes('nasci em')) {
      facts.push(`Data importante mencionada: "${userMessage}"`);
    }
    if (lower.includes('meu trabalho') || lower.includes('trabalho como') || lower.includes('estudo')) {
      facts.push(`Rotina/profissão mencionada: "${userMessage}"`);
    }

    return facts;
  }
}

export const userMemoryService = new UserMemoryService();
