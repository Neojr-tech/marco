/**
 * Database Configuration
 * Prepares configuration for PostgreSQL database connection.
 * In prototype mode, in-memory repository with structured schemas is used
 * while retaining PostgreSQL schema compliance and migration readiness.
 */
export const databaseConfig = {
  type: 'postgres' as const,
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432', 10),
  username: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'namorado_virtual_db',
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  entitiesOrder: [
    'users',
    'avatars',
    'personas',
    'characters',
    'conversations',
    'participants',
    'messages',
    'conversation_memories',
    'character_memories',
    'user_memories',
    'relationships',
    'subscriptions',
  ],
};
