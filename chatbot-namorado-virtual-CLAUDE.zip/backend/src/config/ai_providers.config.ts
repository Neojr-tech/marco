/**
 * AI Providers Configuration
 * Defines gateways and active model providers.
 * Provider selection remains extensible and isolated behind ai-gateway/.
 */
export const aiProvidersConfig = {
  activeConversationProvider: 'gemini', // 'gemini' | 'simulated'
  gemini: {
    model: 'gemini-3.7-flash',
    temperature: 0.85,
    topP: 0.95,
    maxOutputTokens: 800,
  },
  // Future Gateways Configuration (A DEFINIR)
  vision: {
    provider: 'A_DEFINIR',
    status: 'prepared',
  },
  imageGeneration: {
    provider: 'A_DEFINIR',
    status: 'prepared',
  },
  videoGeneration: {
    provider: 'A_DEFINIR',
    status: 'prepared',
  },
  voice: {
    provider: 'A_DEFINIR',
    status: 'prepared',
  },
};
