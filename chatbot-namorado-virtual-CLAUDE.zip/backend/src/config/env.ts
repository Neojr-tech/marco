export const env = {
  PORT: process.env.PORT ? parseInt(process.env.PORT, 10) : 3000,
  NODE_ENV: process.env.NODE_ENV || 'development',
  GEMINI_API_KEY: process.env.GEMINI_API_KEY || '',
  APP_URL: process.env.APP_URL || 'http://localhost:3000',
  JWT_SECRET: process.env.JWT_SECRET || 'chatbot-namorado-virtual-jwt-secret-key-2026',
  AI_PROVIDER: process.env.AI_PROVIDER || 'gemini', // 'gemini' | 'simulated'
};
