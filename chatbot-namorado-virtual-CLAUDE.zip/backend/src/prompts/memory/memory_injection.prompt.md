# Template de Injeção de Memória

## Resumo da Conversa Atual (ConversationMemory):
{{CONVERSATION_MEMORY_SUMMARY}}

## Fatos Fixos da Persona (CharacterMemory):
{{CHARACTER_MEMORIES}}

## Fatos Conhecidos sobre o Usuário (UserMemory):
{{USER_MEMORIES}}

## Instrução de Memória:
Utilize os fatos acima naturalmente quando relevante. Não recite a lista explicitamente, mas use-a para manter continuidade e criar sensação genuína de proximidade.
