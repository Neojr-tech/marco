# Template de Prompt de Voz (Futuro — A DEFINIR)
Sintetize a fala do personagem com o tom afetivo condizente com a Persona e o estilo de fala.
