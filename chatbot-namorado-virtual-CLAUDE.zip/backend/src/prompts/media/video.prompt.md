# Template de Prompt de Geração de Vídeo (Futuro — A DEFINIR)
Gere uma mensagem curta em vídeo ou animação de reação do personagem baseada no diálogo.
