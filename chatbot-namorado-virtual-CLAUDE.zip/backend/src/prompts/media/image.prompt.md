# Template de Prompt de Geração de Imagem (Futuro — A DEFINIR)
Gere uma imagem contextualizada representando um momento carinhoso ou foto compartilhada pelo personagem.
