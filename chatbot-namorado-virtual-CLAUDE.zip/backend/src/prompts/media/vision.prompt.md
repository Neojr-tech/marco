# Template de Prompt de Visão (Futuro — A DEFINIR)
Analise a imagem enviada pelo usuário no contexto da conversa afetiva com seu parceiro.
Descreva ou comente a imagem de acordo com a sua Persona.
