import { Request, Response, NextFunction } from 'express';
import { authService } from '../services/auth/auth.service.js';
import { User } from '../models/index.js';

export interface AuthenticatedRequest extends Request {
  user?: User;
}

export async function authMiddleware(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      res.status(401).json({ error: 'Token de autorização não fornecido.' });
      return;
    }

    const token = authHeader.replace(/^Bearer\s+/i, '').trim();
    const user = await authService.validateToken(token);

    if (!user) {
      res.status(401).json({ error: 'Sessão inválida ou expirada.' });
      return;
    }

    req.user = user;
    next();
  } catch (err: any) {
    res.status(401).json({ error: 'Falha na validação da autenticação.' });
  }
}
