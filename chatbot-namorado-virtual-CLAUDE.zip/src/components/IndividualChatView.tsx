import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { Character, ChatSessionData, Message, Relationship } from '../types';
import {
  Send,
  Heart,
  Brain,
  Sparkles,
  Info,
  ChevronRight,
  X,
  Smile,
  ShieldCheck,
  RefreshCw,
  Clock,
  BookOpen,
  UserCheck
} from 'lucide-react';

interface IndividualChatViewProps {
  character: Character;
  onBackToCharacters: () => void;
  onOpenCreationModal: () => void;
}

export const IndividualChatView: React.FC<IndividualChatViewProps> = ({
  character,
  onBackToCharacters,
  onOpenCreationModal,
}) => {
  const [session, setSession] = useState<ChatSessionData | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [loadingSession, setLoadingSession] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showMemoryInspector, setShowMemoryInspector] = useState(false);
  const [contextDebugInfo, setContextDebugInfo] = useState<{
    provider: string;
    model: string;
    injectedMemoriesCount: number;
  } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadChatSession();
  }, [character.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const loadChatSession = async () => {
    setLoadingSession(true);
    setError(null);
    try {
      const data = await api.startChatSession(character.id);
      setSession(data);
      setMessages(data.messages);
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar sessão de conversa.');
    } finally {
      setLoadingSession(false);
    }
  };

  const handleSendMessage = async (customContent?: string) => {
    const textToSend = customContent || inputText;
    if (!textToSend.trim() || !session || isTyping) return;

    const userContent = textToSend.trim();
    if (!customContent) {
      setInputText('');
    }

    // Optimistic UI for user message
    const tempUserMsg: Message = {
      id: `temp-${Date.now()}`,
      conversation_id: session.conversation.id,
      sender_type: 'user',
      sender_id: session.conversation.user_id,
      content: userContent,
      content_type: 'text',
      media_url: null,
      created_at: new Date().toISOString(),
      reply_to_message_id: null,
    };

    setMessages((prev) => [...prev, tempUserMsg]);
    setIsTyping(true);
    setError(null);

    try {
      const res = await api.sendMessage({
        conversationId: session.conversation.id,
        content: userContent,
      });

      setMessages((prev) => [
        ...prev.filter((m) => m.id !== tempUserMsg.id),
        res.userMessage,
        res.characterMessage,
      ]);

      // Update relationship and debug context
      if (session) {
        setSession({
          ...session,
          relationship: res.relationship,
        });
      }
      setContextDebugInfo(res.contextDebug);
    } catch (err: any) {
      setError(err.message || 'Falha ao enviar mensagem ao namorado virtual.');
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const quickPrompts = [
    'Oi meu amor! Como você está hoje?',
    'O que você mais gosta de fazer no seu tempo livre?',
    'Me conta um pouco sobre seus sonhos e seu dia a dia?',
    'Tive um dia um pouco cansativo hoje...',
  ];

  if (loadingSession) {
    return (
      <div className="min-h-[calc(100vh-65px)] flex flex-col items-center justify-center p-6 space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600 animate-pulse">
          <Heart className="w-6 h-6 fill-current" />
        </div>
        <p className="text-sm font-semibold text-stone-600">
          Iniciando sessão com {character.nickname}...
        </p>
      </div>
    );
  }

  const relationshipLevel = session?.relationship?.level || character.relationshipLevel || 1;

  return (
    <div className="max-w-5xl mx-auto p-2 sm:p-4 h-[calc(100vh-65px)] flex flex-col relative">
      {/* Top Header Card */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs p-3.5 sm:p-4 mb-3 flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={character.avatar?.image_url}
              alt={character.nickname}
              referrerPolicy="no-referrer"
              className="w-12 h-12 rounded-2xl object-cover border border-rose-200 shadow-xs"
            />
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-stone-900 leading-tight">
                {character.nickname}
              </h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-50 text-rose-600 border border-rose-200 flex items-center gap-1">
                <Heart className="w-2.5 h-2.5 fill-rose-500 text-rose-500" />
                Nível {relationshipLevel}
              </span>
            </div>
            <p className="text-xs text-stone-500">
              {character.persona?.name} • {character.persona?.personality_summary}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            id="toggle-memory-drawer-btn"
            onClick={() => setShowMemoryInspector(!showMemoryInspector)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              showMemoryInspector
                ? 'bg-rose-50 text-rose-700 border-rose-200'
                : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
            }`}
          >
            <Brain className="w-3.5 h-3.5 text-rose-500" />
            <span className="hidden sm:inline">Memória & Contexto</span>
          </button>

          <button
            id="back-to-list-btn"
            onClick={onBackToCharacters}
            className="px-3 py-1.5 rounded-xl text-xs font-medium text-stone-600 hover:bg-stone-100 transition-colors hidden sm:block"
          >
            Trocar
          </button>
        </div>
      </div>

      {/* Chat Messages Container */}
      <div className="flex-1 bg-stone-100/60 rounded-3xl border border-stone-200/80 p-4 overflow-y-auto flex flex-col justify-between space-y-4">
        {/* Messages Stream */}
        <div className="space-y-3.5">
          {/* Welcome Intro Message in Conversation */}
          <div className="p-3.5 rounded-2xl bg-white border border-stone-200 max-w-md mx-auto text-center space-y-1.5 shadow-xs">
            <div className="w-8 h-8 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto">
              <Sparkles className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-bold text-stone-900">
              Você está conversando com {character.nickname}
            </h4>
            <p className="text-[11px] text-stone-500 leading-relaxed">
              Este chat possui memória contínua. Fatos sobre você e a história da relação são recordados a cada mensagem.
            </p>
          </div>

          {messages.map((msg) => {
            const isUser = msg.sender_type === 'user';
            return (
              <div
                key={msg.id}
                id={`message-bubble-${msg.id}`}
                className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <img
                    src={character.avatar?.image_url}
                    alt={character.nickname}
                    referrerPolicy="no-referrer"
                    className="w-8 h-8 rounded-xl object-cover shrink-0 border border-rose-200 self-end mb-1"
                  />
                )}

                <div
                  className={`max-w-[82%] sm:max-w-[70%] rounded-2xl px-4 py-2.5 shadow-xs text-sm leading-relaxed ${
                    isUser
                      ? 'bg-rose-600 text-white rounded-br-xs'
                      : 'bg-white text-stone-900 border border-stone-200/80 rounded-bl-xs'
                  }`}
                >
                  {!isUser && (
                    <div className="text-[10px] font-bold text-rose-600 mb-0.5 flex items-center gap-1">
                      <span>{character.nickname}</span>
                      <span className="text-stone-300">•</span>
                      <span className="text-stone-400 font-normal">
                        {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  )}

                  <p className="whitespace-pre-wrap">{msg.content}</p>

                  {isUser && (
                    <div className="text-[10px] text-rose-200 text-right mt-0.5">
                      {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex gap-2.5 justify-start items-center">
              <img
                src={character.avatar?.image_url}
                alt={character.nickname}
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-xl object-cover shrink-0 border border-rose-200"
              />
              <div className="bg-white border border-stone-200/80 rounded-2xl px-4 py-3 shadow-xs flex items-center gap-1.5">
                <span className="text-xs text-stone-400 font-medium mr-1">
                  {character.nickname} está digitando
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-bounce [animation-delay:-0.3s]" />
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-bounce [animation-delay:-0.15s]" />
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-bounce" />
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Prompts */}
        {messages.length <= 4 && (
          <div className="pt-2">
            <p className="text-[11px] font-semibold text-stone-400 mb-2">Sugestões de assunto:</p>
            <div className="flex flex-wrap gap-2">
              {quickPrompts.map((prompt, idx) => (
                <button
                  key={idx}
                  id={`quick-prompt-${idx}`}
                  onClick={() => handleSendMessage(prompt)}
                  disabled={isTyping}
                  className="px-3 py-1.5 rounded-xl bg-white hover:bg-rose-50 hover:text-rose-700 text-stone-600 text-xs border border-stone-200 transition-all text-left"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Input Bar */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs p-2.5 mt-3 flex items-center gap-2">
        <input
          id="chat-message-input"
          type="text"
          placeholder={`Converse com ${character.nickname}...`}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isTyping}
          className="flex-1 px-4 py-2.5 rounded-2xl bg-stone-50 border border-stone-200 text-sm focus:border-rose-500 focus:bg-white outline-hidden transition-all"
        />

        <button
          id="send-message-btn"
          onClick={() => handleSendMessage()}
          disabled={!inputText.trim() || isTyping}
          className="w-11 h-11 rounded-2xl bg-rose-600 hover:bg-rose-700 disabled:opacity-40 text-white flex items-center justify-center shadow-md shadow-rose-200 transition-all shrink-0 cursor-pointer"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

      {/* Slide-over Memory & Context Inspector */}
      {showMemoryInspector && (
        <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-white shadow-2xl border-l border-stone-200 p-6 flex flex-col justify-between animate-slide-left overflow-y-auto">
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-stone-100">
              <div className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-rose-600" />
                <h3 className="text-base font-bold text-stone-900">
                  Inspetor de Memória & Contexto
                </h3>
              </div>
              <button
                id="close-memory-inspector-btn"
                onClick={() => setShowMemoryInspector(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Relationship Status */}
            <div className="p-4 rounded-2xl bg-rose-50/50 border border-rose-100 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-800">Vínculo Afetivo</span>
                <span className="text-xs font-extrabold text-rose-600 bg-white px-2 py-0.5 rounded-full border border-rose-200">
                  Nível {relationshipLevel} / 10
                </span>
              </div>
              <p className="text-xs text-rose-900/80">
                A intimidade emocional e profundidade das respostas aumentam conforme você conversa.
              </p>
            </div>

            {/* Conversation Memory */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-stone-500" />
                <span>1. Memória da Conversa (ConversationMemory)</span>
              </h4>
              <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 text-xs text-stone-600 leading-relaxed">
                {session?.conversationSummary || 'Iniciando histórico da conversa atual...'}
              </div>
            </div>

            {/* Character Memory */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-purple-500" />
                <span>2. Fatos Fixos da Persona (CharacterMemory)</span>
              </h4>
              <div className="space-y-1.5">
                {session?.characterMemories && session.characterMemories.length > 0 ? (
                  session.characterMemories.map((fact, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-purple-50/40 border border-purple-100 text-xs text-purple-900"
                    >
                      • {fact}
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-stone-400 italic">Sem fatos adicionais configurados.</p>
                )}
              </div>
            </div>

            {/* User Memory */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-emerald-600" />
                <span>3. Memórias sobre Você (UserMemory)</span>
              </h4>
              <div className="space-y-1.5">
                {session?.userMemories && session.userMemories.length > 0 ? (
                  session.userMemories.map((fact, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-emerald-50/40 border border-emerald-100 text-xs text-emerald-900"
                    >
                      ✓ {fact}
                    </div>
                  ))
                ) : (
                  <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 text-xs text-stone-500">
                    O namorado aprenderá seus hábitos e preferências conforme você compartilha informações no chat.
                  </div>
                )}
              </div>
            </div>

            {/* AI Provider Info */}
            <div className="p-4 rounded-2xl bg-stone-900 text-white space-y-1.5 text-xs">
              <div className="flex items-center justify-between text-stone-400">
                <span>Provedor de Conversação:</span>
                <span className="text-rose-400 font-mono font-bold">
                  {contextDebugInfo?.provider || 'Google Gemini'}
                </span>
              </div>
              <div className="flex items-center justify-between text-stone-400">
                <span>Modelo Ativo:</span>
                <span className="text-stone-200 font-mono">
                  {contextDebugInfo?.model || 'gemini-3.7-flash'}
                </span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-stone-100 text-center">
            <button
              id="refresh-session-btn"
              onClick={loadChatSession}
              className="w-full py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Recarregar Camadas de Memória</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
