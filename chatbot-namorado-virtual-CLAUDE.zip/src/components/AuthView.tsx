import React, { useState } from 'react';
import { api } from '../services/api';
import { User } from '../types';
import { Heart, Lock, Mail, User as UserIcon, Calendar, ArrowRight, Sparkles, AlertCircle } from 'lucide-react';

interface AuthViewProps {
  onSuccess: (user: User) => void;
}

export const AuthView: React.FC<AuthViewProps> = ({ onSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    try {
      if (mode === 'register') {
        if (!displayName.trim() || !email.trim() || !password.trim()) {
          throw new Error('Por favor, preencha todos os campos obrigatórios.');
        }
        const res = await api.register({
          email: email.trim(),
          password,
          displayName: displayName.trim(),
          birthDate: birthDate || undefined,
        });
        onSuccess(res.user);
      } else {
        if (!email.trim() || !password.trim()) {
          throw new Error('Por favor, informe seu e-mail e senha.');
        }
        const res = await api.login({
          email: email.trim(),
          password,
        });
        onSuccess(res.user);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Ocorreu um erro ao processar sua requisição.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoAccount = async (name: string, mail: string) => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      try {
        const res = await api.login({ email: mail, password: 'password123' });
        onSuccess(res.user);
      } catch {
        const res = await api.register({
          email: mail,
          password: 'password123',
          displayName: name,
          birthDate: '2000-01-01',
        });
        onSuccess(res.user);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Falha ao acessar conta de demonstração.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-65px)] flex items-center justify-center p-4 sm:p-6 bg-stone-50">
      <div className="max-w-md w-full bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-stone-200">
        {/* Header Icon */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-100 flex items-center justify-center mx-auto text-rose-600 mb-3 shadow-xs">
            <Heart className="w-6 h-6 fill-current" />
          </div>
          <h2 className="text-xl font-bold text-stone-900">
            {mode === 'register' ? 'Crie sua conta' : 'Acesse seu perfil'}
          </h2>
          <p className="text-xs text-stone-500 mt-1">
            {mode === 'register'
              ? 'Conecte-se e comece a conversar com seu namorado virtual'
              : 'Seja bem-vindo de volta ao seu espaço afetivo'}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex bg-stone-100 p-1 rounded-xl mb-6 border border-stone-200/60">
          <button
            id="tab-register-btn"
            type="button"
            onClick={() => {
              setMode('register');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
              mode === 'register' ? 'bg-white text-rose-600 shadow-xs' : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            Criar Conta
          </button>
          <button
            id="tab-login-btn"
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
              mode === 'login' ? 'bg-white text-rose-600 shadow-xs' : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            Entrar
          </button>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                Seu Nome de Exibição *
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
                <input
                  id="input-display-name"
                  type="text"
                  required
                  placeholder="Como o namorado deve te chamar"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:border-rose-500 focus:ring-2 focus:ring-rose-100 outline-hidden transition-all"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1.5">
              E-mail *
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
              <input
                id="input-email"
                type="email"
                required
                placeholder="seu.email@exemplo.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:border-rose-500 focus:ring-2 focus:ring-rose-100 outline-hidden transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1.5">
              Senha *
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
              <input
                id="input-password"
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:border-rose-500 focus:ring-2 focus:ring-rose-100 outline-hidden transition-all"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                Data de Nascimento (Opcional)
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
                <input
                  id="input-birthdate"
                  type="date"
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-stone-200 text-sm focus:border-rose-500 focus:ring-2 focus:ring-rose-100 outline-hidden transition-all"
                />
              </div>
            </div>
          )}

          <button
            id="auth-submit-btn"
            type="submit"
            disabled={isLoading}
            className="w-full mt-2 py-3 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-semibold text-sm shadow-md shadow-rose-200 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            {isLoading ? (
              <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{mode === 'register' ? 'Criar Minha Conta' : 'Acessar Conta'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Quick Test Demo Accounts */}
        <div className="mt-6 pt-5 border-t border-stone-100 text-center">
          <p className="text-[11px] text-stone-400 font-medium mb-2.5">
            Ou teste instantaneamente com uma conta de demonstração:
          </p>
          <div className="flex gap-2 justify-center">
            <button
              id="demo-user-1-btn"
              type="button"
              onClick={() => handleDemoAccount('Camila', 'camila.demo@exemplo.com')}
              disabled={isLoading}
              className="px-3 py-1.5 rounded-lg bg-stone-100 hover:bg-rose-50 hover:text-rose-600 text-stone-700 text-xs font-medium border border-stone-200 transition-colors"
            >
              Demo: Camila
            </button>
            <button
              id="demo-user-2-btn"
              type="button"
              onClick={() => handleDemoAccount('Juliana', 'juliana.demo@exemplo.com')}
              disabled={isLoading}
              className="px-3 py-1.5 rounded-lg bg-stone-100 hover:bg-rose-50 hover:text-rose-600 text-stone-700 text-xs font-medium border border-stone-200 transition-colors"
            >
              Demo: Juliana
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
