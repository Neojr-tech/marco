import React from 'react';
import { Heart, Sparkles, Brain, UserCheck, Shield, MessageSquareText, ArrowRight } from 'lucide-react';

interface OnboardingViewProps {
  onContinue: () => void;
}

export const OnboardingView: React.FC<OnboardingViewProps> = ({ onContinue }) => {
  return (
    <div className="min-h-[calc(100vh-65px)] flex items-center justify-center p-4 sm:p-6 bg-gradient-to-b from-stone-50 via-rose-50/30 to-stone-50">
      <div className="max-w-3xl w-full bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-stone-200/80">
        {/* Badge & Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-100/70 text-rose-700 text-xs font-semibold mb-4">
            <Heart className="w-3.5 h-3.5 fill-current" />
            <span>Bem-vindo ao Chatbot Namorado Virtual</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight">
            Seu companheiro afetivo com IA e memória contextual
          </h2>
          <p className="mt-3 text-sm sm:text-base text-stone-600 max-w-xl mx-auto leading-relaxed">
            Uma arquitetura inovadora onde você pode escolher a personalidade (Persona), a aparência (Avatar) e construir uma relação duradoura com memória das suas conversas.
          </p>
        </div>

        {/* 4 Pillars of Architecture */}
        <div className="grid sm:grid-cols-2 gap-4 mb-8">
          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/70 hover:border-rose-200 transition-colors">
            <div className="w-9 h-9 rounded-xl bg-rose-500 text-white flex items-center justify-center mb-3">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-stone-900 mb-1">
              Persona & Avatar Separados
            </h3>
            <p className="text-xs text-stone-500 leading-relaxed">
              Personalidade, história e estilo de fala são independentes da aparência visual, permitindo combinações ricas e reutilizáveis.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/70 hover:border-rose-200 transition-colors">
            <div className="w-9 h-9 rounded-xl bg-purple-500 text-white flex items-center justify-center mb-3">
              <Brain className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-stone-900 mb-1">
              Memória Contextual em Camadas
            </h3>
            <p className="text-xs text-stone-500 leading-relaxed">
              O parceiro lembra do seu dia a dia, das suas preferências compartilhadas e do histórico da relação a cada conversa.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/70 hover:border-rose-200 transition-colors">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center mb-3">
              <Shield className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-stone-900 mb-1">
              AI-Gateway Isolado
            </h3>
            <p className="text-xs text-stone-500 leading-relaxed">
              Conexão protegida com modelos de linguagem (Gemini 3.7 Flash) com injeção automática de contexto e regras de segurança.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/70 hover:border-rose-200 transition-colors">
            <div className="w-9 h-9 rounded-xl bg-emerald-500 text-white flex items-center justify-center mb-3">
              <MessageSquareText className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-stone-900 mb-1">
              Evolução do Vínculo
            </h3>
            <p className="text-xs text-stone-500 leading-relaxed">
              Conforme você conversa, o nível do relacionamento sobe, desbloqueando intimidade emocional e novos marcos afetivos.
            </p>
          </div>
        </div>

        {/* CTA Button */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-stone-100">
          <div className="text-xs text-stone-500 flex items-center gap-1.5">
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <span>Cadastro simples para salvar seu histórico e personagens</span>
          </div>

          <button
            id="onboarding-continue-btn"
            onClick={onContinue}
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-sm shadow-md shadow-rose-200 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <span>Criar Conta ou Entrar</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
