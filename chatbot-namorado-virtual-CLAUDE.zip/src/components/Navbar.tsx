import React from 'react';
import { User, Character } from '../types';
import { Heart, Sparkles, UserPlus, LogOut, Layers, ShieldCheck } from 'lucide-react';

interface NavbarProps {
  currentUser: User | null;
  activeCharacter: Character | null;
  characters: Character[];
  onSelectCharacter: (char: Character) => void;
  onOpenCreationModal: () => void;
  onOpenArchitectureModal: () => void;
  onLogout: () => void;
  currentView: 'chat' | 'characters';
  onNavigateView: (view: 'chat' | 'characters') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  activeCharacter,
  characters,
  onSelectCharacter,
  onOpenCreationModal,
  onOpenArchitectureModal,
  onLogout,
  currentView,
  onNavigateView,
}) => {
  return (
    <header id="main-navbar" className="bg-white/90 backdrop-blur-md border-b border-rose-100 sticky top-0 z-40 px-4 lg:px-8 py-3.5 shadow-xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 to-pink-500 flex items-center justify-center text-white shadow-md shadow-rose-200">
            <Heart className="w-5 h-5 fill-current animate-pulse" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-bold tracking-tight text-stone-900 leading-tight flex items-center gap-2">
              Namorado Virtual
              <span className="text-[10px] uppercase font-semibold tracking-wider px-2 py-0.5 rounded-full bg-rose-50 text-rose-600 border border-rose-200">
                Protótipo
              </span>
            </h1>
            <p className="text-xs text-stone-500 font-medium hidden sm:block">
              IA Afetiva com Persona, Avatar e Memória
            </p>
          </div>
        </div>

        {/* Center / Navigation items if authenticated */}
        {currentUser && (
          <nav className="hidden md:flex items-center gap-1 bg-stone-100/80 p-1 rounded-xl border border-stone-200/60">
            <button
              id="nav-chat-btn"
              onClick={() => onNavigateView('chat')}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                currentView === 'chat'
                  ? 'bg-white text-rose-600 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Conversa
            </button>
            <button
              id="nav-characters-btn"
              onClick={() => onNavigateView('characters')}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                currentView === 'characters'
                  ? 'bg-white text-rose-600 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Personagens ({characters.length})
            </button>
          </nav>
        )}

        {/* Right Actions */}
        <div className="flex items-center gap-2.5">
          {currentUser ? (
            <>
              {/* Architecture & Memory Inspector */}
              <button
                id="open-architecture-btn"
                onClick={onOpenArchitectureModal}
                title="Inspecionar Arquitetura, Gateway e Memória"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-medium border border-stone-200 transition-colors"
              >
                <Layers className="w-4 h-4 text-rose-500" />
                <span className="hidden sm:inline">Arquitetura</span>
              </button>

              {/* New Character Button */}
              <button
                id="create-character-btn"
                onClick={onOpenCreationModal}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-xs shadow-rose-200 transition-colors"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Novo Personagem</span>
              </button>

              {/* User Dropdown / Info */}
              <div className="flex items-center gap-2 pl-2 border-l border-stone-200">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-semibold text-stone-800 leading-tight">
                    {currentUser.display_name}
                  </p>
                  <p className="text-[10px] text-stone-400 truncate max-w-[120px]">
                    {currentUser.email}
                  </p>
                </div>
                <button
                  id="logout-btn"
                  onClick={onLogout}
                  title="Sair da conta"
                  className="p-2 rounded-xl text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </>
          ) : (
            <button
              id="header-arch-btn"
              onClick={onOpenArchitectureModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-medium border border-stone-200"
            >
              <ShieldCheck className="w-4 h-4 text-rose-500" />
              <span>Ver Especificação Técnica</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
