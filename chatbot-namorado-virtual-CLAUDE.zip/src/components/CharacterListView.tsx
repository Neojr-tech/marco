import React from 'react';
import { Character } from '../types';
import { MessageCircle, Heart, UserPlus, Sparkles, BookOpen, Layers } from 'lucide-react';

interface CharacterListViewProps {
  characters: Character[];
  onSelectCharacter: (char: Character) => void;
  onOpenCreationModal: () => void;
}

export const CharacterListView: React.FC<CharacterListViewProps> = ({
  characters,
  onSelectCharacter,
  onOpenCreationModal,
}) => {
  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-stone-200 shadow-xs">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 text-rose-600 text-xs font-semibold mb-2">
            <Heart className="w-3.5 h-3.5 fill-current" />
            <span>Seus Companheiros Virtuais</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-stone-900">
            Personagens Cadastrados
          </h2>
          <p className="text-xs text-stone-500 mt-1">
            Cada personagem conecta sua conta (User) a uma Persona e um Avatar com memórias próprias.
          </p>
        </div>

        <button
          id="create-char-list-btn"
          onClick={onOpenCreationModal}
          className="px-5 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-md shadow-rose-200 flex items-center gap-2 transition-all cursor-pointer self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>Criar Novo Personagem</span>
        </button>
      </div>

      {/* Grid of Characters */}
      {characters.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-stone-300 max-w-md mx-auto space-y-4">
          <div className="w-16 h-16 rounded-3xl bg-rose-50 text-rose-500 flex items-center justify-center mx-auto">
            <Sparkles className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-stone-800">
            Nenhum personagem criado ainda
          </h3>
          <p className="text-xs text-stone-500 leading-relaxed">
            Crie seu primeiro namorado virtual combinando uma Persona e um Avatar para começar a conversar agora mesmo.
          </p>
          <button
            id="empty-create-char-btn"
            onClick={onOpenCreationModal}
            className="px-6 py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-md shadow-rose-200 transition-all inline-flex items-center gap-2 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Criar Meu Primeiro Namorado</span>
          </button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {characters.map((char) => (
            <div
              key={char.id}
              id={`character-card-${char.id}`}
              className="bg-white rounded-3xl border border-stone-200/90 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col group"
            >
              {/* Avatar Cover Image */}
              <div className="relative h-48 w-full bg-stone-100 overflow-hidden">
                {char.avatar?.image_url ? (
                  <img
                    src={char.avatar.image_url}
                    alt={char.nickname}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-stone-400">
                    Sem Imagem
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-transparent to-transparent" />

                {/* Level Badge */}
                <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-full text-[10px] font-bold text-rose-600 border border-rose-100 shadow-xs flex items-center gap-1">
                  <Heart className="w-3 h-3 fill-rose-500 text-rose-500" />
                  <span>Nível {char.relationshipLevel || 1}</span>
                </div>

                {/* Nickname and Persona name */}
                <div className="absolute bottom-3 left-4 right-4 text-white">
                  <h3 className="text-lg font-bold leading-tight drop-shadow-xs">
                    {char.nickname}
                  </h3>
                  <p className="text-xs text-rose-200 font-medium">
                    Persona: {char.persona?.name}
                  </p>
                </div>
              </div>

              {/* Persona Details */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-lg inline-block">
                    {char.persona?.personality_summary}
                  </p>
                  <p className="text-xs text-stone-600 line-clamp-3 leading-relaxed">
                    {char.persona?.backstory}
                  </p>
                </div>

                {/* Action button */}
                <button
                  id={`chat-with-${char.id}-btn`}
                  onClick={() => onSelectCharacter(char)}
                  className="w-full py-2.5 rounded-xl bg-stone-900 hover:bg-rose-600 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Conversar com {char.nickname}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
