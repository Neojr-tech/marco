import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { Avatar, Persona, Character } from '../types';
import { X, Check, Sparkles, Image as ImageIcon, User, Heart, ChevronRight, ChevronLeft, Plus } from 'lucide-react';

interface CharacterCreationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCharacterCreated: (character: Character) => void;
}

export const CharacterCreationModal: React.FC<CharacterCreationModalProps> = ({
  isOpen,
  onClose,
  onCharacterCreated,
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [avatars, setAvatars] = useState<Avatar[]>([]);
  const [personas, setPersonas] = useState<Persona[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Selected State
  const [selectedAvatarId, setSelectedAvatarId] = useState<string>('');
  const [customAvatarUrl, setCustomAvatarUrl] = useState<string>('');
  const [selectedPersonaId, setSelectedPersonaId] = useState<string>('');
  
  // Custom Persona fields
  const [isCustomPersona, setIsCustomPersona] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customGender, setCustomGender] = useState('male');
  const [customPersonality, setCustomPersonality] = useState('');
  const [customSpeechStyle, setCustomSpeechStyle] = useState('');
  const [customBackstory, setCustomBackstory] = useState('');
  const [customRules, setCustomRules] = useState('');

  // Character Linking
  const [nickname, setNickname] = useState('');

  useEffect(() => {
    if (isOpen) {
      loadAssets();
    }
  }, [isOpen]);

  const loadAssets = async () => {
    setLoading(true);
    setError(null);
    try {
      const [avatarsRes, personasRes] = await Promise.all([
        api.listAvatars(),
        api.listPersonas(),
      ]);
      setAvatars(avatarsRes.avatars);
      setPersonas(personasRes.personas);

      if (avatarsRes.avatars.length > 0 && !selectedAvatarId) {
        setSelectedAvatarId(avatarsRes.avatars[0].id);
      }
      if (personasRes.personas.length > 0 && !selectedPersonaId) {
        setSelectedPersonaId(personasRes.personas[0].id);
        setNickname(personasRes.personas[0].name);
      }
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar avatares e personas.');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCustomAvatar = async () => {
    if (!customAvatarUrl.trim()) return;
    try {
      const res = await api.createAvatar({ imageUrl: customAvatarUrl.trim() });
      setAvatars((prev) => [res.avatar, ...prev]);
      setSelectedAvatarId(res.avatar.id);
      setCustomAvatarUrl('');
    } catch (err: any) {
      setError(err.message || 'Erro ao salvar avatar personalizado.');
    }
  };

  const handleSelectPersonaPreset = (persona: Persona) => {
    setSelectedPersonaId(persona.id);
    setIsCustomPersona(false);
    if (!nickname) {
      setNickname(persona.name);
    }
  };

  const handleFinish = async () => {
    setLoading(true);
    setError(null);

    try {
      let finalPersonaId = selectedPersonaId;

      // If creating custom persona first
      if (isCustomPersona) {
        if (!customName.trim() || !customPersonality.trim()) {
          throw new Error('Informe o nome e personalidade da persona.');
        }
        const createdPersona = await api.createPersona({
          name: customName.trim(),
          gender: customGender,
          personalitySummary: customPersonality.trim(),
          speechStyle: customSpeechStyle.trim() || 'Carinhoso e atencioso',
          backstory: customBackstory.trim() || 'Um companheiro dedicado.',
          behaviorRules: customRules.trim() || 'Seja respeitoso e acolhedor.',
          defaultAvatarId: selectedAvatarId,
        });
        finalPersonaId = createdPersona.persona.id;
      }

      if (!selectedAvatarId) {
        throw new Error('Selecione um Avatar.');
      }

      // Create Character linking User + Persona + Avatar
      const res = await api.createCharacter({
        personaId: finalPersonaId,
        avatarId: selectedAvatarId,
        nickname: nickname.trim() || (isCustomPersona ? customName : 'Namorado'),
      });

      onCharacterCreated(res.character);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Falha ao criar personagem.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const currentSelectedAvatar = avatars.find((a) => a.id === selectedAvatarId);
  const currentSelectedPersona = personas.find((p) => p.id === selectedPersonaId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50/50">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-600 bg-rose-50 px-2.5 py-0.5 rounded-full border border-rose-100">
                Passo {step} de 3
              </span>
              <h3 className="text-base sm:text-lg font-bold text-stone-900">
                {step === 1 && '1. Escolha a Aparência (Avatar)'}
                {step === 2 && '2. Escolha a Personalidade (Persona)'}
                {step === 3 && '3. Definir Apelido e Confirmar'}
              </h3>
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              {step === 1 && 'Selecione a identidade visual do seu namorado virtual.'}
              {step === 2 && 'Defina o comportamento, história e estilo de conversa.'}
              {step === 3 && 'Conecte User + Persona + Avatar para gerar a entidade Character.'}
            </p>
          </div>

          <button
            id="close-creation-modal-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {error && (
            <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs">
              {error}
            </div>
          )}

          {/* STEP 1: AVATAR PICKER */}
          {step === 1 && (
            <div className="space-y-4">
              <label className="block text-xs font-semibold text-stone-700">
                Galeria de Avatares do Sistema
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
                {avatars.map((avatar) => {
                  const isSelected = avatar.id === selectedAvatarId;
                  return (
                    <div
                      key={avatar.id}
                      id={`avatar-option-${avatar.id}`}
                      onClick={() => setSelectedAvatarId(avatar.id)}
                      className={`relative group rounded-2xl overflow-hidden cursor-pointer border-2 transition-all aspect-square ${
                        isSelected
                          ? 'border-rose-500 ring-4 ring-rose-100 shadow-md'
                          : 'border-stone-200 hover:border-stone-400'
                      }`}
                    >
                      <img
                        src={avatar.image_url}
                        alt="Avatar option"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      {isSelected && (
                        <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-rose-500 text-white flex items-center justify-center shadow-xs">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Custom Image URL Upload */}
              <div className="pt-3 border-t border-stone-100">
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Ou adicione uma imagem personalizada via URL:
                </label>
                <div className="flex gap-2">
                  <input
                    id="input-custom-avatar-url"
                    type="url"
                    placeholder="https://exemplo.com/foto.jpg"
                    value={customAvatarUrl}
                    onChange={(e) => setCustomAvatarUrl(e.target.value)}
                    className="flex-1 px-3.5 py-2 rounded-xl border border-stone-200 text-xs focus:border-rose-500 focus:ring-1 focus:ring-rose-200 outline-hidden"
                  />
                  <button
                    id="add-custom-avatar-btn"
                    type="button"
                    onClick={handleCreateCustomAvatar}
                    className="px-3 py-2 rounded-xl bg-stone-800 hover:bg-stone-900 text-white text-xs font-semibold transition-colors"
                  >
                    Adicionar
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: PERSONA SETUP */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-stone-700">
                  Modelos de Personalidade (Personas)
                </label>
                <button
                  id="toggle-custom-persona-btn"
                  type="button"
                  onClick={() => setIsCustomPersona(!isCustomPersona)}
                  className="text-xs font-semibold text-rose-600 hover:text-rose-700 flex items-center gap-1"
                >
                  {isCustomPersona ? 'Escolher Persona Pronta' : '+ Criar Persona Customizada'}
                </button>
              </div>

              {!isCustomPersona ? (
                <div className="space-y-2.5">
                  {personas.map((persona) => {
                    const isSelected = persona.id === selectedPersonaId;
                    return (
                      <div
                        key={persona.id}
                        id={`persona-option-${persona.id}`}
                        onClick={() => handleSelectPersonaPreset(persona)}
                        className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                          isSelected
                            ? 'border-rose-500 bg-rose-50/40 shadow-xs'
                            : 'border-stone-200 bg-stone-50/60 hover:border-stone-300'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-sm font-bold text-stone-900">
                            {persona.name}
                          </h4>
                          {isSelected && (
                            <span className="text-[10px] font-bold uppercase bg-rose-500 text-white px-2 py-0.5 rounded-full">
                              Selecionado
                            </span>
                          )}
                        </div>
                        <p className="text-xs font-medium text-rose-700 mb-1">
                          {persona.personality_summary}
                        </p>
                        <p className="text-[11px] text-stone-500 line-clamp-2">
                          {persona.backstory}
                        </p>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="space-y-3 p-4 rounded-2xl bg-stone-50 border border-stone-200">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Nome da Persona *
                    </label>
                    <input
                      id="input-custom-persona-name"
                      type="text"
                      placeholder="Ex: Matheus"
                      value={customName}
                      onChange={(e) => setCustomName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-200 text-xs bg-white focus:border-rose-500 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Resumo da Personalidade *
                    </label>
                    <input
                      id="input-custom-persona-personality"
                      type="text"
                      placeholder="Ex: Carinhoso, engraçado e protetor"
                      value={customPersonality}
                      onChange={(e) => setCustomPersonality(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-200 text-xs bg-white focus:border-rose-500 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Estilo de Fala
                    </label>
                    <input
                      id="input-custom-persona-speech"
                      type="text"
                      placeholder="Ex: Doce, usa emojis e apelidos carinhosos"
                      value={customSpeechStyle}
                      onChange={(e) => setCustomSpeechStyle(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-200 text-xs bg-white focus:border-rose-500 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      História / Fundo Pessoal (Backstory)
                    </label>
                    <textarea
                      id="input-custom-persona-backstory"
                      rows={2}
                      placeholder="Ex: É médico veterinário, adora animais, café e praia aos fins de semana..."
                      value={customBackstory}
                      onChange={(e) => setCustomBackstory(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-200 text-xs bg-white focus:border-rose-500 outline-hidden"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 3: NICKNAME & CONFIRMATION */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-rose-50/50 border border-rose-100 flex items-center gap-4">
                {currentSelectedAvatar && (
                  <img
                    src={currentSelectedAvatar.image_url}
                    alt="Preview"
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-2xl object-cover border border-rose-200 shadow-xs"
                  />
                )}
                <div>
                  <h4 className="text-sm font-bold text-stone-900">
                    {isCustomPersona ? customName || 'Persona Customizada' : currentSelectedPersona?.name}
                  </h4>
                  <p className="text-xs text-stone-500">
                    {isCustomPersona
                      ? customPersonality || 'Personalidade própria'
                      : currentSelectedPersona?.personality_summary}
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Apelido / Como você prefere chamá-lo no chat:
                </label>
                <input
                  id="input-character-nickname"
                  type="text"
                  placeholder="Ex: Luquinhas, Meu Bem, Rafa..."
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-sm focus:border-rose-500 focus:ring-1 focus:ring-rose-200 outline-hidden"
                />
              </div>

              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 text-xs text-stone-600 space-y-1">
                <p className="font-semibold text-stone-800">Estrutura Entitária:</p>
                <p>• <strong>User</strong>: Sua conta autenticada</p>
                <p>• <strong>Persona</strong>: {isCustomPersona ? customName : currentSelectedPersona?.name}</p>
                <p>• <strong>Avatar</strong>: {selectedAvatarId}</p>
                <p>• <strong>Character</strong>: Conectando as 3 entidades com memória contextual e IA.</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        <div className="p-4 sm:p-5 border-t border-stone-100 bg-stone-50/50 flex items-center justify-between">
          {step > 1 ? (
            <button
              id="step-prev-btn"
              type="button"
              onClick={() => setStep((s) => (s - 1) as 1 | 2 | 3)}
              className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Voltar</span>
            </button>
          ) : (
            <div />
          )}

          {step < 3 ? (
            <button
              id="step-next-btn"
              type="button"
              onClick={() => setStep((s) => (s + 1) as 1 | 2 | 3)}
              className="px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs shadow-rose-200 transition-colors"
            >
              <span>Avançar</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              id="confirm-create-character-btn"
              type="button"
              disabled={loading}
              onClick={handleFinish}
              className="px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-rose-200 transition-colors cursor-pointer"
            >
              {loading ? (
                <span>Criando...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Criar Personagem & Iniciar Chat</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
