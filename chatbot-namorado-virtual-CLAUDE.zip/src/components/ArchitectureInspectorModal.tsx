import React, { useState } from 'react';
import { X, Layers, Database, Shield, Brain, Cpu, FileText, CheckCircle2, ChevronRight } from 'lucide-react';

interface ArchitectureInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureInspectorModal: React.FC<ArchitectureInspectorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'schema' | 'decisions' | 'prompts'>('architecture');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-stone-900">
                Especificação Técnica & Arquitetura
              </h3>
              <p className="text-xs text-stone-500">
                Documentação viva do Chatbot Namorado Virtual (Backend TS + Frontend React + Flutter App)
              </p>
            </div>
          </div>

          <button
            id="close-arch-modal-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-stone-100 px-6 bg-stone-50/30 gap-4">
          <button
            id="tab-arch-overview"
            onClick={() => setActiveTab('architecture')}
            className={`py-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'architecture'
                ? 'border-rose-600 text-rose-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Visão Geral & Pipeline
          </button>
          <button
            id="tab-arch-schema"
            onClick={() => setActiveTab('schema')}
            className={`py-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'schema'
                ? 'border-rose-600 text-rose-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Tabelas & Migrations (1..12)
          </button>
          <button
            id="tab-arch-decisions"
            onClick={() => setActiveTab('decisions')}
            className={`py-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'decisions'
                ? 'border-rose-600 text-rose-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Decisions Log
          </button>
          <button
            id="tab-arch-prompts"
            onClick={() => setActiveTab('prompts')}
            className={`py-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'prompts'
                ? 'border-rose-600 text-rose-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Injeção de Prompts & IA
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto flex-1 text-xs text-stone-600 space-y-6">
          {activeTab === 'architecture' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-rose-50/40 border border-rose-100 text-rose-900 leading-relaxed">
                <p className="font-bold mb-1">Princípio da Separação Entitária:</p>
                <p>
                  <strong>Persona</strong> (Personalidade, história, estilo de fala, regras) e <strong>Avatar</strong> (Identidade visual, imagem, mídias) são entidades desacopladas. O <strong>Character</strong> é a entidade que une o usuário, a persona e o avatar com memórias contínuas.
                </p>
              </div>

              {/* Visual Pipeline Diagram */}
              <div className="p-5 rounded-2xl bg-stone-900 text-white font-mono space-y-3">
                <p className="text-stone-400 text-[11px] font-sans font-bold uppercase tracking-wider">
                  Fluxo de Execução de Mensagem:
                </p>
                <div className="flex flex-col gap-2 text-stone-200">
                  <div className="flex items-center gap-2">
                    <span className="bg-stone-800 px-2.5 py-1 rounded-md text-emerald-400">1. Client Request</span>
                    <span>→ POST /api/chat/individual/message</span>
                  </div>
                  <div className="flex items-center gap-2 pl-4 border-l border-stone-800">
                    <span className="bg-stone-800 px-2.5 py-1 rounded-md text-blue-400">2. IndividualChatService</span>
                    <span>→ Recupera Conversation, Character, Persona, Avatar, Relationship</span>
                  </div>
                  <div className="flex items-center gap-2 pl-8 border-l border-stone-800">
                    <span className="bg-stone-800 px-2.5 py-1 rounded-md text-purple-400">3. Memory Aggregation</span>
                    <span>→ Injeta ConversationMemory + CharacterMemory + UserMemory + Relationship</span>
                  </div>
                  <div className="flex items-center gap-2 pl-12 border-l border-stone-800">
                    <span className="bg-stone-800 px-2.5 py-1 rounded-md text-rose-400">4. AIGateway (Conversation)</span>
                    <span>→ Executa Google Gemini API (gemini-3.7-flash) com fallback seguro</span>
                  </div>
                  <div className="flex items-center gap-2 pl-16 border-l border-stone-800">
                    <span className="bg-stone-800 px-2.5 py-1 rounded-md text-emerald-400">5. State & Memory Update</span>
                    <span>→ Persiste mensagens, atualiza nível da relação e extrai novas memórias</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'schema' && (
            <div className="space-y-4">
              <p className="font-semibold text-stone-800">
                Ordem Estrita de Migrações do Banco de Dados Relacional (PostgreSQL):
              </p>
              <div className="grid sm:grid-cols-2 gap-2.5">
                {[
                  '1. users (identidade e autenticação)',
                  '2. avatars (imagens, voz, vídeo)',
                  '3. personas (alma, estilo, história, regras)',
                  '4. characters (elo user-persona-avatar)',
                  '5. conversations (conversas individuais/grupo)',
                  '6. participants (participantes de conversas)',
                  '7. messages (histórico de mensagens e mídias)',
                  '8. conversation_memories (resumos)',
                  '9. character_memories (fatos fixos da persona)',
                  '10. user_memories (fatos sobre o usuário)',
                  '11. relationships (nível de intimidade e marcos)',
                  '12. subscriptions (planos de assinatura)',
                ].map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-stone-50 border border-stone-200 flex items-center gap-2 font-medium text-stone-700"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'decisions' && (
            <div className="space-y-3">
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
                <h4 className="font-bold text-stone-900">Decisões Arquiteturais Fechadas:</h4>
                <p>• <strong>ADR-001</strong>: Persona e Avatar separados; Character como unificador.</p>
                <p>• <strong>ADR-002</strong>: IA isolada sob `ai-gateway/`.</p>
                <p>• <strong>ADR-003</strong>: Chat individual possui exatamente 1 personagem; grupo 2+.</p>
                <p>• <strong>ADR-004</strong>: Gemini 3.7 Flash ativo no gateway com fallback simulado.</p>
              </div>

              <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200 space-y-2">
                <h4 className="font-bold text-amber-900">Decisões Marcadas como A DEFINIR:</h4>
                <p>• <strong>HTTP vs WebSocket</strong>: REST adotado no protótipo para robustez e compatibilidade.</p>
                <p>• <strong>Atualização de Resumo</strong>: Processamento em lotes a cada 6 mensagens.</p>
                <p>• <strong>Gateways de Mídia</strong>: Voz, vídeo e visão preparados com contratos e stubs.</p>
              </div>
            </div>
          )}

          {activeTab === 'prompts' && (
            <div className="space-y-3">
              <div className="p-4 rounded-2xl bg-stone-900 text-stone-200 font-mono text-[11px] space-y-2 overflow-x-auto">
                <p className="text-rose-400 font-bold">// System Prompt Template</p>
                <p>Você é {`{{character_nickname}}`}, cuja personalidade é inspirada em {`{{persona_name}}`}.</p>
                <p className="text-stone-400">// Injeção de Persona</p>
                <p>• Personalidade: {`{{personality_summary}}`}</p>
                <p>• Estilo de fala: {`{{speech_style}}`}</p>
                <p>• História: {`{{backstory}}`}</p>
                <p>• Regras: {`{{behavior_rules}}`}</p>
                <p className="text-stone-400">// Injeção de Memória e Vínculo</p>
                <p>• Nível da Relação: {`{{relationship_level}}`}</p>
                <p>• Memórias do Usuário: {`{{user_memories}}`}</p>
                <p>• Resumo Anterior: {`{{conversation_summary}}`}</p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-stone-100 bg-stone-50/50 flex justify-end">
          <button
            id="close-arch-footer-btn"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold transition-colors"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};
