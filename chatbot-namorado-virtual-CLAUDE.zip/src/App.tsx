/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { api } from './services/api';
import { User, Character } from './types';
import { Navbar } from './components/Navbar';
import { OnboardingView } from './components/OnboardingView';
import { AuthView } from './components/AuthView';
import { CharacterListView } from './components/CharacterListView';
import { IndividualChatView } from './components/IndividualChatView';
import { CharacterCreationModal } from './components/CharacterCreationModal';
import { ArchitectureInspectorModal } from './components/ArchitectureInspectorModal';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [activeCharacter, setActiveCharacter] = useState<Character | null>(null);
  
  // Navigation / Views
  const [hasSeenOnboarding, setHasSeenOnboarding] = useState<boolean>(() => {
    return localStorage.getItem('namorado_virtual_seen_onboarding') === 'true';
  });
  const [currentView, setCurrentView] = useState<'chat' | 'characters'>('chat');
  const [isCreationModalOpen, setIsCreationModalOpen] = useState(false);
  const [isArchitectureModalOpen, setIsArchitectureModalOpen] = useState(false);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);

  // Initialize auth state
  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const token = api.getToken();
    if (!token) {
      setIsLoadingAuth(false);
      return;
    }

    try {
      const res = await api.getMe();
      setCurrentUser(res.user);
      await loadCharacters();
    } catch {
      api.setToken(null);
      setCurrentUser(null);
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const loadCharacters = async () => {
    try {
      const res = await api.listCharacters();
      setCharacters(res.characters);
      if (res.characters.length > 0) {
        setActiveCharacter((prev) => {
          if (prev && res.characters.some((c) => c.id === prev.id)) {
            return res.characters.find((c) => c.id === prev.id) || res.characters[0];
          }
          return res.characters[0];
        });
      }
    } catch (err) {
      console.error('Falha ao carregar personagens:', err);
    }
  };

  const handleAuthSuccess = async (user: User) => {
    setCurrentUser(user);
    await loadCharacters();
  };

  const handleLogout = () => {
    api.setToken(null);
    setCurrentUser(null);
    setCharacters([]);
    setActiveCharacter(null);
  };

  const handleCharacterCreated = async (char: Character) => {
    await loadCharacters();
    setActiveCharacter(char);
    setCurrentView('chat');
  };

  const handleSelectCharacter = (char: Character) => {
    setActiveCharacter(char);
    setCurrentView('chat');
  };

  const handleCompleteOnboarding = () => {
    localStorage.setItem('namorado_virtual_seen_onboarding', 'true');
    setHasSeenOnboarding(true);
  };

  if (isLoadingAuth) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-4 border-rose-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-semibold text-stone-500">Carregando Namorado Virtual...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 flex flex-col font-sans selection:bg-rose-100 selection:text-rose-900">
      {/* Top Navigation */}
      <Navbar
        currentUser={currentUser}
        activeCharacter={activeCharacter}
        characters={characters}
        onSelectCharacter={handleSelectCharacter}
        onOpenCreationModal={() => setIsCreationModalOpen(true)}
        onOpenArchitectureModal={() => setIsArchitectureModalOpen(true)}
        onLogout={handleLogout}
        currentView={currentView}
        onNavigateView={setCurrentView}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {!currentUser ? (
          !hasSeenOnboarding ? (
            <OnboardingView onContinue={handleCompleteOnboarding} />
          ) : (
            <AuthView onSuccess={handleAuthSuccess} />
          )
        ) : (
          <>
            {currentView === 'characters' || !activeCharacter ? (
              <CharacterListView
                characters={characters}
                onSelectCharacter={handleSelectCharacter}
                onOpenCreationModal={() => setIsCreationModalOpen(true)}
              />
            ) : (
              <IndividualChatView
                character={activeCharacter}
                onBackToCharacters={() => setCurrentView('characters')}
                onOpenCreationModal={() => setIsCreationModalOpen(true)}
              />
            )}
          </>
        )}
      </main>

      {/* Character Creation Modal Wizard */}
      <CharacterCreationModal
        isOpen={isCreationModalOpen}
        onClose={() => setIsCreationModalOpen(false)}
        onCharacterCreated={handleCharacterCreated}
      />

      {/* Architecture & Decision Inspector Modal */}
      <ArchitectureInspectorModal
        isOpen={isArchitectureModalOpen}
        onClose={() => setIsArchitectureModalOpen(false)}
      />
    </div>
  );
}

