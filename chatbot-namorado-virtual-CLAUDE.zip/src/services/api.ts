import { User, Character, Avatar, Persona, ChatSessionData, Message, Relationship } from '../types';

class ApiService {
  private token: string | null = null;

  constructor() {
    this.token = localStorage.getItem('namorado_virtual_token');
  }

  public setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem('namorado_virtual_token', token);
    } else {
      localStorage.removeItem('namorado_virtual_token');
    }
  }

  public getToken(): string | null {
    return this.token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(endpoint, {
      ...options,
      headers,
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || `Erro na requisição (${response.status})`);
    }

    return data as T;
  }

  // Auth Endpoints
  public async register(payload: { email: string; password?: string; displayName: string; birthDate?: string }): Promise<{ user: User; token: string }> {
    const res = await this.request<{ user: User; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    this.setToken(res.token);
    return res;
  }

  public async login(payload: { email: string; password?: string }): Promise<{ user: User; token: string }> {
    const res = await this.request<{ user: User; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    this.setToken(res.token);
    return res;
  }

  // User Endpoints
  public async getMe(): Promise<{ user: User; memories: Array<{ id: string; fact: string }> }> {
    return this.request<{ user: User; memories: Array<{ id: string; fact: string }> }>('/api/user/me');
  }

  public async completeOnboarding(): Promise<{ user: User }> {
    return this.request<{ user: User }>('/api/user/onboarding/complete', {
      method: 'POST',
    });
  }

  // Character Endpoints
  public async listCharacters(): Promise<{ characters: Character[] }> {
    return this.request<{ characters: Character[] }>('/api/characters');
  }

  public async listAvatars(): Promise<{ avatars: Avatar[] }> {
    return this.request<{ avatars: Avatar[] }>('/api/characters/avatars');
  }

  public async listPersonas(): Promise<{ personas: Persona[] }> {
    return this.request<{ personas: Persona[] }>('/api/characters/personas');
  }

  public async createAvatar(payload: { imageUrl: string; voiceRef?: string; videoRef?: string }): Promise<{ avatar: Avatar }> {
    return this.request<{ avatar: Avatar }>('/api/characters/avatars', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  public async createPersona(payload: {
    name: string;
    gender: string;
    personalitySummary: string;
    speechStyle: string;
    backstory: string;
    behaviorRules: string;
    defaultAvatarId?: string | null;
    initialMemories?: string[];
  }): Promise<{ persona: Persona }> {
    return this.request<{ persona: Persona }>('/api/characters/personas', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  public async createCharacter(payload: {
    personaId: string;
    avatarId: string;
    nickname: string;
  }): Promise<{ character: Character }> {
    return this.request<{ character: Character }>('/api/characters', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  // Chat Endpoints
  public async startChatSession(characterId: string): Promise<ChatSessionData> {
    return this.request<ChatSessionData>('/api/chat/individual/session', {
      method: 'POST',
      body: JSON.stringify({ characterId }),
    });
  }

  public async sendMessage(payload: {
    conversationId: string;
    content: string;
  }): Promise<{
    userMessage: Message;
    characterMessage: Message;
    relationship: Relationship;
    contextDebug: { provider: string; model: string; injectedMemoriesCount: number };
  }> {
    return this.request<{
      userMessage: Message;
      characterMessage: Message;
      relationship: Relationship;
      contextDebug: { provider: string; model: string; injectedMemoriesCount: number };
    }>('/api/chat/individual/message', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }
}

export const api = new ApiService();
