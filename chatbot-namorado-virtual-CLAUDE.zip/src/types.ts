export type UserAuthProvider = 'email' | 'google' | 'apple';
export type UserStatus = 'active' | 'suspended' | 'deleted';

export interface User {
  id: string;
  email: string;
  display_name: string;
  birth_date: string | null;
  auth_provider: UserAuthProvider;
  created_at: string;
  updated_at: string;
  status: UserStatus;
  onboarding_completed_at: string | null;
}

export interface Avatar {
  id: string;
  owner_type: 'system' | 'user';
  owner_id: string | null;
  image_url: string;
  voice_ref: string | null;
  video_ref: string | null;
  created_at: string;
}

export interface Persona {
  id: string;
  owner_type: 'system' | 'user';
  owner_id: string | null;
  name: string;
  gender: string;
  personality_summary: string;
  speech_style: string;
  backstory: string;
  behavior_rules: string;
  default_avatar_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Character {
  id: string;
  user_id: string;
  persona_id: string;
  avatar_id: string;
  nickname: string;
  ai_config_override: Record<string, any> | null;
  created_at: string;
  archived_at: string | null;
  persona?: Persona;
  avatar?: Avatar;
  relationshipLevel?: number;
}

export interface Conversation {
  id: string;
  user_id: string;
  type: 'individual' | 'group';
  title: string;
  created_at: string;
  last_message_at: string;
  status: 'active' | 'archived' | 'closed';
}

export interface Participant {
  id: string;
  conversation_id: string;
  character_id: string;
  joined_at: string;
  role_in_group: string | null;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_type: 'user' | 'character';
  sender_id: string;
  content: string;
  content_type: 'text' | 'image' | 'audio' | 'video';
  media_url: string | null;
  created_at: string;
  reply_to_message_id: string | null;
}

export interface ConversationMemory {
  id: string;
  conversation_id: string;
  summary: string;
  updated_at: string;
}

export interface CharacterMemory {
  id: string;
  persona_id: string;
  fact: string;
  created_at: string;
}

export interface UserMemory {
  id: string;
  user_id: string;
  fact: string;
  source_message_id: string | null;
  created_at: string;
}

export interface Relationship {
  id: string;
  subject_type: 'user_character' | 'character_character';
  user_id: string | null;
  character_id: string;
  related_character_id: string | null;
  level: number;
  milestones: string[] | Record<string, any>;
  updated_at: string;
}

export interface ChatSessionData {
  conversation: Conversation;
  character: Character & { persona: Persona; avatar: Avatar };
  relationship: Relationship;
  messages: Message[];
  conversationSummary: string;
  characterMemories: string[];
  userMemories: string[];
}
