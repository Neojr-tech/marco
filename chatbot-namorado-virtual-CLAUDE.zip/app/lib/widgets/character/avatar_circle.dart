import 'package:flutter/material.dart';

class AvatarCircle extends StatelessWidget {
  final String imageUrl;
  final double radius;

  const AvatarCircle({Key? key, required this.imageUrl, this.radius = 24}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundImage: NetworkImage(imageUrl),
    );
  }
}
