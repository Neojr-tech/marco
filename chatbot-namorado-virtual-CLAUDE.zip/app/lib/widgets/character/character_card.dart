import 'package:flutter/material.dart';
import '../../models/character_model.dart';

class CharacterCard extends StatelessWidget {
  final CharacterModel character;
  final VoidCallback onTap;

  const CharacterCard({Key? key, required this.character, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundImage: character.avatar != null ? NetworkImage(character.avatar!.imageUrl) : null,
          child: character.avatar == null ? const Icon(Icons.person) : null,
        ),
        title: Text(character.nickname, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(character.persona?.personalitySummary ?? ''),
        trailing: Chip(label: Text('Nível ${character.relationshipLevel}')),
      ),
    );
  }
}
