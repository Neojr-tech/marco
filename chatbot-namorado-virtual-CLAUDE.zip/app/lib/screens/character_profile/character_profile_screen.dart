import 'package:flutter/material.dart';

class CharacterProfileScreen extends StatelessWidget {
  const CharacterProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Perfil do Personagem')),
      body: const Center(child: Text('Ficha da Persona, memórias e nível de relacionamento')),
    );
  }
}
