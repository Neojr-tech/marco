import 'package:flutter/material.dart';

class PersonalitySetupStep extends StatelessWidget {
  const PersonalitySetupStep({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Passo 2: Configuração de Persona e Personalidade'));
  }
}
