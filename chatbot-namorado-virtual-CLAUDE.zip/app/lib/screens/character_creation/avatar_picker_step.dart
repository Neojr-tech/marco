import 'package:flutter/material.dart';

class AvatarPickerStep extends StatelessWidget {
  const AvatarPickerStep({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Passo 1: Selecionar Avatar'));
  }
}
