import 'package:flutter/material.dart';

class CharacterCreationScreen extends StatelessWidget {
  const CharacterCreationScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Criar Personagem')),
      body: const Center(child: Text('Wizard de Criação de Personagem: Avatar + Persona')),
    );
  }
}
