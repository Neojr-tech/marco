import 'package:flutter/material.dart';

class IndividualChatScreen extends StatelessWidget {
  const IndividualChatScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Conversa com Namorado')),
      body: const Center(child: Text('Chat Individual com IA e Memória Contextual')),
    );
  }
}
