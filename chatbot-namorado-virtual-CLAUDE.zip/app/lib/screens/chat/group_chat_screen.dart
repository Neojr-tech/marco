import 'package:flutter/material.dart';

class GroupChatScreen extends StatelessWidget {
  const GroupChatScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Conversa em Grupo (Preparada)')),
      body: const Center(child: Text('Conversa em grupo com múltiplos personagens')),
    );
  }
}
