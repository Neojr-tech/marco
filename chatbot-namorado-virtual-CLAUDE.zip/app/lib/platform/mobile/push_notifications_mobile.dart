class PushNotificationsMobile {
  Future<void> initialize() async {
    // Configuração de push notification móvel (Firebase Cloud Messaging/APNS)
  }
}
