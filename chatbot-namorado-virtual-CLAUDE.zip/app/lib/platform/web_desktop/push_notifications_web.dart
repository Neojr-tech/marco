class PushNotificationsWeb {
  Future<void> initialize() async {
    // Configuração de push notification web (Service Worker)
  }
}
