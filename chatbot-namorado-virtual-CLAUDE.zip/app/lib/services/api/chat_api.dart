import 'dart:convert';
import 'package:http/http.dart' as http;
import '../local/session_storage.dart';
import '../../models/character_model.dart';
import '../../models/message_model.dart';

class ChatApi {
  final String baseUrl;
  final SessionStorage sessionStorage;

  ChatApi({required this.baseUrl, required this.sessionStorage});

  Future<Map<String, dynamic>> startIndividualSession(String characterId) async {
    final token = await sessionStorage.getToken();
    final response = await http.post(
      Uri.parse('$baseUrl/api/chat/individual/session'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'characterId': characterId}),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Erro ao abrir sessão de chat');
    }
  }

  Future<Map<String, dynamic>> sendMessage(String conversationId, String content) async {
    final token = await sessionStorage.getToken();
    final response = await http.post(
      Uri.parse('$baseUrl/api/chat/individual/message'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'conversationId': conversationId, 'content': content}),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Erro ao enviar mensagem');
    }
  }
}
