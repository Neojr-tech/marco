import 'dart:convert';
import 'package:http/http.dart' as http;
import '../local/session_storage.dart';
import '../../models/user_model.dart';

class UserApi {
  final String baseUrl;
  final SessionStorage sessionStorage;

  UserApi({required this.baseUrl, required this.sessionStorage});

  Future<Map<String, dynamic>> getMe() async {
    final token = await sessionStorage.getToken();
    final res = await http.get(
      Uri.parse('$baseUrl/api/user/me'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Erro ao carregar usuário');
  }

  Future<UserModel> completeOnboarding() async {
    final token = await sessionStorage.getToken();
    final res = await http.post(
      Uri.parse('$baseUrl/api/user/onboarding/complete'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      return UserModel.fromJson(data['user']);
    }
    throw Exception('Erro ao concluir onboarding');
  }
}
