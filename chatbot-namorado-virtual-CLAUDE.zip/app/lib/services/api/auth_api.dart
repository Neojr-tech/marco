import 'dart:convert';
import 'package:http/http.dart' as http;
import '../local/session_storage.dart';
import '../../models/user_model.dart';

class AuthApi {
  final String baseUrl;
  final SessionStorage sessionStorage;

  AuthApi({required this.baseUrl, required this.sessionStorage});

  Future<UserModel> login(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      await sessionStorage.saveToken(data['token']);
      return UserModel.fromJson(data['user']);
    } else {
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'Erro no login');
    }
  }

  Future<UserModel> register(String email, String password, String displayName) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password, 'displayName': displayName}),
    );
    if (response.statusCode == 201) {
      final data = jsonDecode(response.body);
      await sessionStorage.saveToken(data['token']);
      return UserModel.fromJson(data['user']);
    } else {
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'Erro no cadastro');
    }
  }
}
