import 'dart:convert';
import 'package:http/http.dart' as http;
import '../local/session_storage.dart';
import '../../models/character_model.dart';
import '../../models/avatar_model.dart';

class CharacterApi {
  final String baseUrl;
  final SessionStorage sessionStorage;

  CharacterApi({required this.baseUrl, required this.sessionStorage});

  Future<List<CharacterModel>> listCharacters() async {
    final token = await sessionStorage.getToken();
    final res = await http.get(
      Uri.parse('$baseUrl/api/characters'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      final list = data['characters'] as List;
      return list.map((c) => CharacterModel.fromJson(c)).toList();
    }
    throw Exception('Erro ao carregar personagens');
  }

  Future<List<AvatarModel>> listAvatars() async {
    final token = await sessionStorage.getToken();
    final res = await http.get(
      Uri.parse('$baseUrl/api/characters/avatars'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      final list = data['avatars'] as List;
      return list.map((a) => AvatarModel.fromJson(a)).toList();
    }
    throw Exception('Erro ao carregar avatares');
  }

  Future<List<PersonaModel>> listPersonas() async {
    final token = await sessionStorage.getToken();
    final res = await http.get(
      Uri.parse('$baseUrl/api/characters/personas'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      final list = data['personas'] as List;
      return list.map((p) => PersonaModel.fromJson(p)).toList();
    }
    throw Exception('Erro ao carregar personas');
  }

  Future<CharacterModel> createCharacter({
    required String personaId,
    required String avatarId,
    required String nickname,
  }) async {
    final token = await sessionStorage.getToken();
    final res = await http.post(
      Uri.parse('$baseUrl/api/characters'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'personaId': personaId,
        'avatarId': avatarId,
        'nickname': nickname,
      }),
    );
    if (res.statusCode == 201) {
      final data = jsonDecode(res.body);
      return CharacterModel.fromJson(data['character']);
    }
    throw Exception('Erro ao criar personagem');
  }
}
