class AvatarModel {
  final String id;
  final String ownerType;
  final String? ownerId;
  final String imageUrl;
  final String? voiceRef;
  final String? videoRef;
  final String createdAt;

  AvatarModel({
    required this.id,
    required this.ownerType,
    this.ownerId,
    required this.imageUrl,
    this.voiceRef,
    this.videoRef,
    required this.createdAt,
  });

  factory AvatarModel.fromJson(Map<String, dynamic> json) {
    return AvatarModel(
      id: json['id'] ?? '',
      ownerType: json['owner_type'] ?? 'system',
      ownerId: json['owner_id'],
      imageUrl: json['image_url'] ?? '',
      voiceRef: json['voice_ref'],
      videoRef: json['video_ref'],
      createdAt: json['created_at'] ?? '',
    );
  }
}
