class MessageModel {
  final String id;
  final String conversationId;
  final String senderType; // 'user' | 'character'
  final String senderId;
  final String content;
  final String contentType;
  final String? mediaUrl;
  final String createdAt;
  final String? replyToMessageId;

  MessageModel({
    required this.id,
    required this.conversationId,
    required this.senderType,
    required this.senderId,
    required this.content,
    this.contentType = 'text',
    this.mediaUrl,
    required this.createdAt,
    this.replyToMessageId,
  });

  factory MessageModel.fromJson(Map<String, dynamic> json) {
    return MessageModel(
      id: json['id'] ?? '',
      conversationId: json['conversation_id'] ?? '',
      senderType: json['sender_type'] ?? 'user',
      senderId: json['sender_id'] ?? '',
      content: json['content'] ?? '',
      contentType: json['content_type'] ?? 'text',
      mediaUrl: json['media_url'],
      createdAt: json['created_at'] ?? '',
      replyToMessageId: json['reply_to_message_id'],
    );
  }
}
