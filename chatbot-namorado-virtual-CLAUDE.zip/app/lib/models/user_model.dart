class UserModel {
  final String id;
  final String email;
  final String displayName;
  final String? birthDate;
  final String authProvider;
  final String createdAt;
  final String? onboardingCompletedAt;

  UserModel({
    required this.id,
    required this.email,
    required this.displayName,
    this.birthDate,
    required this.authProvider,
    required this.createdAt,
    this.onboardingCompletedAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? '',
      email: json['email'] ?? '',
      displayName: json['display_name'] ?? '',
      birthDate: json['birth_date'],
      authProvider: json['auth_provider'] ?? 'email',
      createdAt: json['created_at'] ?? '',
      onboardingCompletedAt: json['onboarding_completed_at'],
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'email': email,
    'display_name': displayName,
    'birth_date': birthDate,
    'auth_provider': authProvider,
    'created_at': createdAt,
    'onboarding_completed_at': onboardingCompletedAt,
  };
}
