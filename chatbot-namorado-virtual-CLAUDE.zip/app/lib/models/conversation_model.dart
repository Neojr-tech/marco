class ConversationModel {
  final String id;
  final String userId;
  final String type; // 'individual' | 'group'
  final String title;
  final String createdAt;
  final String lastMessageAt;
  final String status;

  ConversationModel({
    required this.id,
    required this.userId,
    required this.type,
    required this.title,
    required this.createdAt,
    required this.lastMessageAt,
    required this.status,
  });

  factory ConversationModel.fromJson(Map<String, dynamic> json) {
    return ConversationModel(
      id: json['id'] ?? '',
      userId: json['user_id'] ?? '',
      type: json['type'] ?? 'individual',
      title: json['title'] ?? '',
      createdAt: json['created_at'] ?? '',
      lastMessageAt: json['last_message_at'] ?? '',
      status: json['status'] ?? 'active',
    );
  }
}
