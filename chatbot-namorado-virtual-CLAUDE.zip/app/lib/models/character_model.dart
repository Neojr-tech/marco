import 'avatar_model.dart';

class PersonaModel {
  final String id;
  final String name;
  final String gender;
  final String personalitySummary;
  final String speechStyle;
  final String backstory;
  final String behaviorRules;

  PersonaModel({
    required this.id,
    required this.name,
    required this.gender,
    required this.personalitySummary,
    required this.speechStyle,
    required this.backstory,
    required this.behaviorRules,
  });

  factory PersonaModel.fromJson(Map<String, dynamic> json) {
    return PersonaModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      gender: json['gender'] ?? 'male',
      personalitySummary: json['personality_summary'] ?? '',
      speechStyle: json['speech_style'] ?? '',
      backstory: json['backstory'] ?? '',
      behaviorRules: json['behavior_rules'] ?? '',
    );
  }
}

class CharacterModel {
  final String id;
  final String userId;
  final String personaId;
  final String avatarId;
  final String nickname;
  final PersonaModel? persona;
  final AvatarModel? avatar;
  final int relationshipLevel;

  CharacterModel({
    required this.id,
    required this.userId,
    required this.personaId,
    required this.avatarId,
    required this.nickname,
    this.persona,
    this.avatar,
    this.relationshipLevel = 1,
  });

  factory CharacterModel.fromJson(Map<String, dynamic> json) {
    return CharacterModel(
      id: json['id'] ?? '',
      userId: json['user_id'] ?? '',
      personaId: json['persona_id'] ?? '',
      avatarId: json['avatar_id'] ?? '',
      nickname: json['nickname'] ?? '',
      persona: json['persona'] != null ? PersonaModel.fromJson(json['persona']) : null,
      avatar: json['avatar'] != null ? AvatarModel.fromJson(json['avatar']) : null,
      relationshipLevel: json['relationshipLevel'] ?? 1,
    );
  }
}
