import 'package:flutter/material.dart';
import '../models/character_model.dart';
import '../models/avatar_model.dart';
import '../services/api/character_api.dart';

class CharacterState extends ChangeNotifier {
  final CharacterApi characterApi;

  List<CharacterModel> _characters = [];
  List<AvatarModel> _avatars = [];
  List<PersonaModel> _personas = [];
  CharacterModel? _activeCharacter;
  bool _isLoading = false;

  CharacterState({required this.characterApi});

  List<CharacterModel> get characters => _characters;
  List<AvatarModel> get avatars => _avatars;
  List<PersonaModel> get personas => _personas;
  CharacterModel? get activeCharacter => _activeCharacter;
  bool get isLoading => _isLoading;

  Future<void> loadAll() async {
    _isLoading = true;
    notifyListeners();

    try {
      _characters = await characterApi.listCharacters();
      _avatars = await characterApi.listAvatars();
      _personas = await characterApi.listPersonas();
      if (_characters.isNotEmpty && _activeCharacter == null) {
        _activeCharacter = _characters.first;
      }
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void setActiveCharacter(CharacterModel char) {
    _activeCharacter = char;
    notifyListeners();
  }
}
