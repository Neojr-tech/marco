import 'package:flutter/material.dart';
import '../models/message_model.dart';
import '../services/api/chat_api.dart';

class ChatState extends ChangeNotifier {
  final ChatApi chatApi;

  List<MessageModel> _messages = [];
  bool _isTyping = false;
  String? _conversationId;

  ChatState({required this.chatApi});

  List<MessageModel> get messages => _messages;
  bool get isTyping => _isTyping;
  String? get conversationId => _conversationId;

  Future<void> initSession(String characterId) async {
    _messages.clear();
    notifyListeners();

    final data = await chatApi.startIndividualSession(characterId);
    _conversationId = data['conversation']['id'];
    final msgs = data['messages'] as List;
    _messages = msgs.map((m) => MessageModel.fromJson(m)).toList();
    notifyListeners();
  }

  Future<void> sendMessage(String text) async {
    if (_conversationId == null || text.trim().isEmpty) return;

    _isTyping = true;
    notifyListeners();

    try {
      final res = await chatApi.sendMessage(_conversationId!, text);
      _messages.add(MessageModel.fromJson(res['userMessage']));
      _messages.add(MessageModel.fromJson(res['characterMessage']));
    } finally {
      _isTyping = false;
      notifyListeners();
    }
  }
}
