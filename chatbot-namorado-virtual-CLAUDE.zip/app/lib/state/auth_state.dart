import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/api/auth_api.dart';
import '../services/local/session_storage.dart';

class AuthState extends ChangeNotifier {
  final AuthApi authApi;
  final SessionStorage sessionStorage;

  UserModel? _currentUser;
  bool _isLoading = false;
  String? _errorMessage;

  AuthState({required this.authApi, required this.sessionStorage});

  UserModel? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<void> login(String email, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _currentUser = await authApi.login(email, password);
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> register(String email, String password, String displayName) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _currentUser = await authApi.register(email, password, displayName);
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    await sessionStorage.clear();
    _currentUser = null;
    notifyListeners();
  }
}
