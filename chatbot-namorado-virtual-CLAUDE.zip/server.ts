import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import authRoutes from './backend/src/routes/auth.routes.js';
import userRoutes from './backend/src/routes/user.routes.js';
import characterRoutes from './backend/src/routes/character.routes.js';
import chatRoutes from './backend/src/routes/chat.routes.js';
import groupRoutes from './backend/src/routes/group.routes.js';
import { errorHandlerMiddleware } from './backend/src/middleware/error_handler.middleware.js';
import { createServer as createViteServer } from 'vite';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON and URL-encoded parsers
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'Chatbot Namorado Virtual API',
      timestamp: new Date().toISOString(),
    });
  });

  // Backend API Routes (Mounted first)
  app.use('/api/auth', authRoutes);
  app.use('/api/user', userRoutes);
  app.use('/api/characters', characterRoutes);
  app.use('/api/chat', chatRoutes);
  app.use('/api/group', groupRoutes);

  // Error Handler Middleware for API
  app.use('/api', errorHandlerMiddleware);

  // Vite middleware for development or static serving for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Chatbot Namorado Virtual running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Server Start Error]', err);
});
