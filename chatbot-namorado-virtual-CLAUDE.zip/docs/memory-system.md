# Sistema de Memória em Camadas

## Camadas de Memória
```text
+-------------------------------------------------------------+
|                     CONTEXT BUILDER                         |
+-------------------------------------------------------------+
|  1. ConversationMemory: Resumo cumulativo da conversa       |
|  2. CharacterMemory: Fatos fixos e traços da Persona        |
|  3. UserMemory: Informações extraídas sobre o Usuário       |
|  4. Relationship: Nível de intimidade e marcos alcançados   |
|  5. Histórico Recente: Últimas 10 mensagens                 |
+-------------------------------------------------------------+
                              ↓
                      AI-GATEWAY / GEMINI
```

### Regras de Injeção
- Nenhuma tela acessa memória diretamente.
- A montagem ocorre no `individual_chat.service.ts` antes do envio à IA.
- Novas informações do usuário são extraídas e persistidas em `UserMemory`.
