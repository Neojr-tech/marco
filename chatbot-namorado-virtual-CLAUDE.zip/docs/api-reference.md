# API Reference

## Autenticação (`/api/auth`)
- `POST /api/auth/register`: Cadastro de usuário.
  - Body: `{ email, password, displayName, birthDate }`
  - Response: `{ user, token }`
- `POST /api/auth/login`: Login de usuário.
  - Body: `{ email, password }`
  - Response: `{ user, token }`

## Usuário (`/api/user`)
- `GET /api/user/me`: Dados do usuário autenticado e suas memórias.
- `POST /api/user/onboarding/complete`: Marca conclusão de onboarding.
- `PATCH /api/user/profile`: Atualiza dados do perfil.

## Personagens (`/api/characters`)
- `GET /api/characters`: Lista personagens criados pelo usuário.
- `POST /api/characters`: Cria um novo personagem (conecta User + Persona + Avatar).
  - Body: `{ personaId, avatarId, nickname }`
- `GET /api/characters/:id`: Retorna detalhes do personagem e memórias da Persona.
- `GET /api/characters/avatars`: Lista avatares disponíveis.
- `POST /api/characters/avatars`: Cria avatar personalizado.
- `GET /api/characters/personas`: Lista personas disponíveis.
- `POST /api/characters/personas`: Cria persona personalizada.

## Chat Individual (`/api/chat`)
- `POST /api/chat/individual/session`: Inicia ou recupera sessão de chat com personagem.
  - Body: `{ characterId }`
  - Response: `{ conversation, character, relationship, messages, conversationSummary, characterMemories, userMemories }`
- `POST /api/chat/individual/message`: Envia mensagem e recebe resposta com injeção de contexto.
  - Body: `{ conversationId, content, replyToMessageId? }`
  - Response: `{ userMessage, characterMessage, relationship, contextDebug }`

## Grupo (`/api/group`) [Preparado]
- `POST /api/group/create`: Cria conversa em grupo com múltiplos personagens.
