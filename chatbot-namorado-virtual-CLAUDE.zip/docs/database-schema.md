# Database Schema — PostgreSQL

## Diagrama Conceitual
```text
users (1) ────< (N) characters
personas (1) ─< (N) characters
avatars (1) ──< (N) characters
avatars (1) ──< (N) personas (default_avatar)
users (1) ────< (N) conversations
conversations (1) ──< (N) participants >── (1) characters
conversations (1) ──< (N) messages
conversations (1) ── (0..1) conversation_memories
personas (1) ─< (N) character_memories
users (1) ────< (N) user_memories
(user, character) ── (1) relationships
users (1) ────< (N) subscriptions
```

## Tabelas e Tipos de Dados
1. `users`: id (UUID PK), email, password_hash, display_name, birth_date, auth_provider, created_at, updated_at, status, onboarding_completed_at.
2. `avatars`: id (UUID PK), owner_type, owner_id, image_url, voice_ref, video_ref, created_at.
3. `personas`: id (UUID PK), owner_type, owner_id, name, gender, personality_summary, speech_style, backstory, behavior_rules, default_avatar_id, created_at, updated_at.
4. `characters`: id (UUID PK), user_id (FK), persona_id (FK), avatar_id (FK), nickname, ai_config_override, created_at, archived_at.
5. `conversations`: id (UUID PK), user_id (FK), type ('individual'|'group'), title, created_at, last_message_at, status.
6. `participants`: id (UUID PK), conversation_id (FK), character_id (FK), joined_at, role_in_group.
7. `messages`: id (UUID PK), conversation_id (FK), sender_type ('user'|'character'), sender_id (UUID), content, content_type ('text'|'image'|'audio'|'video'), media_url, created_at, reply_to_message_id.
8. `conversation_memories`: id (UUID PK), conversation_id (FK unique), summary, updated_at.
9. `character_memories`: id (UUID PK), persona_id (FK), fact, created_at.
10. `user_memories`: id (UUID PK), user_id (FK), fact, source_message_id (FK), created_at.
11. `relationships`: id (UUID PK), subject_type, user_id (FK), character_id (FK), related_character_id (FK), level, milestones (JSONB), updated_at.
12. `subscriptions`: id (UUID PK), user_id (FK), plan, status, started_at, ends_at.
