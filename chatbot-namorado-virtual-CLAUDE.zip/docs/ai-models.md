# AI Models & Gateways Reference

## Gateways Arquiteturais
1. **Conversation Gateway** (`ai-gateway/conversation`):
   - Provedor Ativo: Google Gemini API (`gemini-3.7-flash`) via SDK oficial `@google/genai`.
   - Fallback Engine: Motor simulado com diálogos afetuosos pré-estruturados para testes e modo offline.
2. **Vision Gateway** (`ai-gateway/vision`):
   - Status: Preparado (A DEFINIR provedor).
3. **Image Generation Gateway** (`ai-gateway/image-generation`):
   - Status: Preparado (A DEFINIR provedor).
4. **Video Generation Gateway** (`ai-gateway/video-generation`):
   - Status: Preparado (A DEFINIR provedor).
5. **Voice Gateway** (`ai-gateway/voice`):
   - Status: Preparado (A DEFINIR provedor).
