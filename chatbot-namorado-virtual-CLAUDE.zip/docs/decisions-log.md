# Decisions Log (Registro de Decisões do Projeto)

## Decisões Fechadas
- **ADR-001**: Persona e Avatar são entidades separadas. Um Character é o elo entre User, Persona e Avatar.
- **ADR-002**: IA isolada sob `ai-gateway/`.
- **ADR-003**: Conversas individuais possuem exatamente 1 personagem; conversas em grupo possuem 2 ou mais.
- **ADR-004**: Provedor de conversação inicial integrado via Google Gemini (`gemini-3.7-flash`) com fallback de simulação.

## Decisões Abertas (Marcadas como A DEFINIR)
1. **HTTP vs WebSocket para o Chat**:
   * *Status*: A DEFINIR.
   * *Decisão Provisória Adotada no Protótipo*: HTTP REST simples para acelerar validação e garantir compatibilidade universal.
2. **Regra de Atualização de ConversationMemory**:
   * *Status*: A DEFINIR.
   * *Decisão Provisória Adotada no Protótipo*: Atualização periódica a cada 6 mensagens enviadas.
3. **Criação de Personagem (Uma vs Múltiplas Chamadas)**:
   * *Status*: A DEFINIR.
   * *Decisão Provisória Adotada no Protótipo*: Suporte a seleção de Persona/Avatar existentes ou criação encadeada com pré-visualização.
4. **Política de Exclusão Física vs Lógica da Conta/Personagem**:
   * *Status*: A DEFINIR.
   * *Decisão Provisória Adotada no Protótipo*: Soft-delete via `archived_at` / `status='deleted'`.
5. **Valores Exatos de `Persona.gender`**:
   * *Status*: A DEFINIR.
   * *Decisão Provisória Adotada no Protótipo*: `male`, `female`, `non_binary`, `custom`.
6. **Uso de Gamificação em `Relationship` (`level`, `milestones`)**:
   * *Status*: A DEFINIR.
   * *Decisão Provisória Adotada no Protótipo*: Incremento baseado na quantidade de interações (Nível 1 a 10 com marcos afetivos).
7. **Entrada e Saída de Personagens em Grupos**:
   * *Status*: A DEFINIR (futuro).
8. **Provedor Real Definitivo de IA**:
   * *Status*: A DEFINIR (Gemini 3.7 Flash ativo no gateway).
9. **Plano de Assinatura e Monetização**:
   * *Status*: A DEFINIR (estrutura de Subscription preparada).
10. **Modelos e Provedores de Mídia (Visão, Imagem, Vídeo, Voz)**:
    * *Status*: A DEFINIR (interfaces preparadas no gateway).
