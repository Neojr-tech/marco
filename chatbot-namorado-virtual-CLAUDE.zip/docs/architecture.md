# Arquitetura Técnica — Chatbot Namorado Virtual

## 1. Visão Geral do Sistema
O **Chatbot Namorado Virtual** é uma plataforma que permite a criação, personalização e interação afetiva com parceiros virtuais inteligentes com memória contextual e coerência de personalidade.

## 2. Princípios Arquiteturais Centrais
1. **Separação entre Persona e Avatar**:
   - **Persona**: Representa a alma do personagem — nome, gênero, traços de personalidade, história (backstory), estilo de fala e regras de comportamento.
   - **Avatar**: Representa a identidade visual e mídias associadas — imagem, e referências futuras de voz e vídeo.
   - **Character**: Registro de dados que conecta `User`, `Persona` e `Avatar`.
2. **Isolamento de IA (`ai-gateway/`)**:
   - Nenhuma tela de frontend e nenhum serviço de negócio acessa provedores de IA diretamente.
   - Todo acesso passa pelo `ai-gateway/`, permitindo troca de modelos sem impacto nas camadas superiores.
3. **Memória Contextual em Camadas**:
   - `ConversationMemory`: Resumo do histórico e tópicos da conversa ativa.
   - `CharacterMemory`: Fatos fixos da história e preferências da Persona.
   - `UserMemory`: Fatos e preferências do usuário descobertos nas conversas.
   - `Relationship`: Vínculo e nível de intimidade (gamificação).
   - `GroupMemory`: Futura orquestração de grupos.
4. **Acoplamento e Fluxo de Dados**:
   - Frontend: `Screen → API Service → Backend HTTP`
   - Backend: `Route → Service → Model / AI Gateway`
   - Memória: `Chat Service → Memory Services → Context Builder → AI Gateway → Provedor`

## 3. Topologia de Pastas
- `app/lib/`: Estrutura do frontend Flutter (telas, widgets, serviços, modelos, estados).
- `backend/src/`: Código do backend (rotas, serviços, modelos, middleware, prompts, gateways).
- `backend/database/`: Migrations e seeds do banco relacional PostgreSQL.
- `docs/`: Documentação viva do projeto.
