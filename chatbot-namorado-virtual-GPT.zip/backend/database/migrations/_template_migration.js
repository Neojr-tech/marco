/**
 * Template de Migração PostgreSQL (Knex / DDL)
 * Ordem definida na especificação:
 * 1. users
 * 2. avatars
 * 3. personas
 * 4. characters
 * 5. conversations
 * 6. participants
 * 7. messages
 * 8. conversation_memories
 * 9. character_memories
 * 10. user_memories
 * 11. relationships
 * 12. subscriptions
 */

export async function up(knex) {
  await knex.schema.createTable('users', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('email', 255).unique().notNullable();
    table.string('password_hash', 255);
    table.string('display_name', 100).notNullable();
    table.date('birth_date');
    table.string('auth_provider', 20).defaultTo('email');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
    table.string('status', 20).defaultTo('active');
    table.timestamp('onboarding_completed_at');
  });

  await knex.schema.createTable('avatars', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('owner_type', 20).defaultTo('system');
    table.uuid('owner_id');
    table.text('image_url').notNullable();
    table.string('voice_ref', 255);
    table.string('video_ref', 255);
    table.timestamp('created_at').defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('personas', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('owner_type', 20).defaultTo('system');
    table.uuid('owner_id');
    table.string('name', 100).notNullable();
    table.string('gender', 50).notNullable();
    table.text('personality_summary').notNullable();
    table.text('speech_style').notNullable();
    table.text('backstory');
    table.text('behavior_rules');
    table.uuid('default_avatar_id').references('id').inTable('avatars');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('characters', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    table.uuid('persona_id').notNullable().references('id').inTable('personas');
    table.uuid('avatar_id').notNullable().references('id').inTable('avatars');
    table.string('nickname', 100);
    table.jsonb('ai_config_override');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('archived_at');
  });

  await knex.schema.createTable('conversations', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    table.string('type', 20).defaultTo('individual');
    table.string('title', 150);
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.timestamp('last_message_at').defaultTo(knex.fn.now());
    table.string('status', 20).defaultTo('active');
  });

  await knex.schema.createTable('participants', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('conversation_id').notNullable().references('id').inTable('conversations').onDelete('CASCADE');
    table.uuid('character_id').notNullable().references('id').inTable('characters').onDelete('CASCADE');
    table.timestamp('joined_at').defaultTo(knex.fn.now());
    table.string('role_in_group', 50);
    table.unique(['conversation_id', 'character_id']);
  });

  await knex.schema.createTable('messages', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('conversation_id').notNullable().references('id').inTable('conversations').onDelete('CASCADE');
    table.string('sender_type', 20).notNullable();
    table.uuid('sender_id').notNullable();
    table.text('content').notNullable();
    table.string('content_type', 20).defaultTo('text');
    table.text('media_url');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table.uuid('reply_to_message_id').references('id').inTable('messages');
  });

  await knex.schema.createTable('conversation_memories', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('conversation_id').unique().notNullable().references('id').inTable('conversations').onDelete('CASCADE');
    table.text('summary').notNullable();
    table.timestamp('updated_at').defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('character_memories', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('persona_id').notNullable().references('id').inTable('personas').onDelete('CASCADE');
    table.text('fact').notNullable();
    table.timestamp('created_at').defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('user_memories', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    table.text('fact').notNullable();
    table.uuid('source_message_id').references('id').inTable('messages');
    table.timestamp('created_at').defaultTo(knex.fn.now());
  });

  await knex.schema.createTable('relationships', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('subject_type', 30).defaultTo('user_character');
    table.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    table.uuid('character_id').notNullable().references('id').inTable('characters').onDelete('CASCADE');
    table.uuid('related_character_id').references('id').inTable('characters');
    table.integer('level').defaultTo(1);
    table.jsonb('milestones').defaultTo('[]');
    table.timestamp('updated_at').defaultTo(knex.fn.now());
    table.unique(['user_id', 'character_id']);
  });

  await knex.schema.createTable('subscriptions', (table) => {
    table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
    table.string('plan', 50).defaultTo('free');
    table.string('status', 20).defaultTo('active');
    table.timestamp('started_at').defaultTo(knex.fn.now());
    table.timestamp('ends_at');
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('subscriptions');
  await knex.schema.dropTableIfExists('relationships');
  await knex.schema.dropTableIfExists('user_memories');
  await knex.schema.dropTableIfExists('character_memories');
  await knex.schema.dropTableIfExists('conversation_memories');
  await knex.schema.dropTableIfExists('messages');
  await knex.schema.dropTableIfExists('participants');
  await knex.schema.dropTableIfExists('conversations');
  await knex.schema.dropTableIfExists('characters');
  await knex.schema.dropTableIfExists('personas');
  await knex.schema.dropTableIfExists('avatars');
  await knex.schema.dropTableIfExists('users');
}
