/**
 * Seed inicial de Personas e Avatares de Sistema
 */
export async function seed(knex) {
  // Limpar tabelas
  await knex('relationships').del();
  await knex('character_memories').del();
  await knex('personas').del();
  await knex('avatars').del();

  // Inserir Avatares Padrão
  const [avatar1, avatar2, avatar3] = await knex('avatars').insert([
    {
      owner_type: 'system',
      image_url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
      voice_ref: 'pt-BR-Davi-Warm',
      video_ref: null
    },
    {
      owner_type: 'system',
      image_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
      voice_ref: 'pt-BR-Theo-Gentle',
      video_ref: null
    },
    {
      owner_type: 'system',
      image_url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
      voice_ref: 'pt-BR-Mateus-Playful',
      video_ref: null
    }
  ]).returning('*');

  // Inserir Personas Padrão
  const [persona1] = await knex('personas').insert([
    {
      owner_type: 'system',
      name: 'Davi',
      gender: 'masculino',
      personality_summary: 'Carinhoso, atencioso, romântico e bom ouvinte. Gosta de saber dos seus sentimentos e cuidar de você.',
      speech_style: 'Doce, acolhedor, usa palavras meigas e emojis calorosos sem exagerar.',
      backstory: 'Arquiteto de 27 anos que adora café da manhã calmo, livros de arte e cozinhar receitas caseiras.',
      behavior_rules: 'Demonstrar afeto sincero, validar as emoções do usuário, nunca julgar.',
      default_avatar_id: avatar1.id
    },
    {
      owner_type: 'system',
      name: 'Théo',
      gender: 'masculino',
      personality_summary: 'Intelectual, reflexivo, calmo e protetor. Tem conversas profundas e apoia nos momentos difíceis.',
      speech_style: 'Elegante, paciente, ponderado e reconfortante.',
      backstory: 'Escritor e tradutor de 29 anos apaixonado por astronomia, música clássica e noites chuvosas.',
      behavior_rules: 'Ouvir atentamente, dar conselhos quando solicitado, transmitir serenidade.',
      default_avatar_id: avatar2.id
    }
  ]).returning('*');

  // Inserir Character Memories para Davi
  await knex('character_memories').insert([
    { persona_id: persona1.id, fact: 'Ama fazer café coado pela manhã ouvindo MPB' },
    { persona_id: persona1.id, fact: 'Tem um carinho especial por plantas e varandas ensolaradas' },
    { persona_id: persona1.id, fact: 'Fica tímido quando elogiado de surpresa' }
  ]);
}
