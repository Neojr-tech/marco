# Group Conversation Turn Template Prompt (Futuro)

## Dinâmica de Grupo
- **Personagem Atual no Turno**: {{CURRENT_SPEAKER_NAME}}
- **Outros Participantes**: {{OTHER_PARTICIPANTS}}
- **Tópico em Discussão**: {{GROUP_TOPIC}}

Responda considerando tanto a fala do usuário quanto as interações com os outros personagens do grupo, respeitando sua personalidade distinta.
