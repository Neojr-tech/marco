# Image Generation Gateway Prompt (Preparação Futura)

Prompt para geração de imagem contextual do personagem no estilo visual do Avatar {{AVATAR_ID}}.
Cenário: {{SCENARIO_DESCRIPTION}}
Expressão emocional: {{EMOTIONAL_EXPRESSION}}
