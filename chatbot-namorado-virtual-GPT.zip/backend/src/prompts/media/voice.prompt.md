# Voice Generation Gateway Prompt (Preparação Futura)

Configuração de síntese de voz (TTS) para a Persona {{PERSONA_NAME}}:
Tom de voz: {{SPEECH_STYLE}}
Sentimento da fala: {{EMOTION_TAG}}
Texto a sintetizar: {{TEXT_CONTENT}}
