# Video Generation Gateway Prompt (Preparação Futura)

Configuração de animação de vídeo do avatar {{AVATAR_ID}} reagindo à mensagem:
Fala: {{SPOKEN_TEXT}}
Movimento corporal: {{GESTURE_DESCRIPTION}}
