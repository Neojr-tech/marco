# Memory Injection Template Prompt

## Memórias Relevantes sobre o Usuário (UserMemory)
{{USER_MEMORIES}}

## Resumo Contextual de Conversas Anteriores (ConversationMemory)
{{CONVERSATION_SUMMARY}}

Utilize essas memórias para demonstrar que você lembra de conversas passadas, preferências e detalhes da vida do usuário, sem soar forçado ou robótico.
