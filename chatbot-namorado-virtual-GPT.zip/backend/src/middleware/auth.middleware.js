import { config } from '../config/env.js';

/**
 * Authentication Middleware
 * DECISÃO PROVISÓRIA — A VALIDAR: Verificação de token JWT/Bearer
 */
export const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token de autenticação não fornecido' });
  }

  try {
    // Validação de token em base64/JWT simplificado para o protótipo
    const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf8'));
    if (!decoded.userId) {
      return res.status(403).json({ error: 'Token inválido ou expirado' });
    }
    req.user = decoded;
    next();
  } catch (err) {
    // Fallback: se for token mock simples
    if (token.startsWith('user_')) {
      req.user = { userId: token };
      return next();
    }
    return res.status(403).json({ error: 'Falha na validação do token' });
  }
};
