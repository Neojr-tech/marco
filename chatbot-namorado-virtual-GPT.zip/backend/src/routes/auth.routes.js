import { Router } from 'express';
import { authService } from '../services/auth/auth.service.js';

const router = Router();

router.post('/register', async (req, res, next) => {
  try {
    const { email, password, displayName, birthDate } = req.body;
    const result = await authService.register({ email, password, displayName, birthDate });
    res.status(201).json(result);
  } catch (err) {
    next(err);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const result = await authService.login({ email, password });
    res.status(200).json(result);
  } catch (err) {
    next(err);
  }
});

export default router;
