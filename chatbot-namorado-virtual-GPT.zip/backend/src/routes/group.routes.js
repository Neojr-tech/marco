import { Router } from 'express';
import { groupChatService } from '../services/chat/group_chat.service.js';
import { authenticateToken } from '../middleware/auth.middleware.js';

const router = Router();

router.use(authenticateToken);

// Criar conversa em grupo (Preparado arquiteturalmente)
router.post('/create', async (req, res, next) => {
  try {
    const { title, characterIds } = req.body;
    const conversation = await groupChatService.createGroupConversation({
      userId: req.user.userId,
      title,
      characterIds
    });
    res.status(201).json(conversation);
  } catch (err) {
    next(err);
  }
});

export default router;
