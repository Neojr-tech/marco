import { Router } from 'express';
import { characterService } from '../services/character/character.service.js';
import { personaService } from '../services/character/persona.service.js';
import { avatarService } from '../services/character/avatar.service.js';
import { authenticateToken } from '../middleware/auth.middleware.js';

const router = Router();

router.use(authenticateToken);

// Listar avatares
router.get('/avatars', async (req, res, next) => {
  try {
    const avatars = await avatarService.listAvatars(req.user.userId);
    res.json(avatars);
  } catch (err) {
    next(err);
  }
});

// Criar avatar customizado
router.post('/avatars', async (req, res, next) => {
  try {
    const { imageUrl, voiceRef, videoRef } = req.body;
    const avatar = await avatarService.createCustomAvatar({
      userId: req.user.userId,
      imageUrl,
      voiceRef,
      videoRef
    });
    res.status(201).json(avatar);
  } catch (err) {
    next(err);
  }
});

// Listar personas
router.get('/personas', async (req, res, next) => {
  try {
    const personas = await personaService.listPersonas(req.user.userId);
    res.json(personas);
  } catch (err) {
    next(err);
  }
});

// Criar persona customizada
router.post('/personas', async (req, res, next) => {
  try {
    const {
      name,
      gender,
      personalitySummary,
      speechStyle,
      backstory,
      behaviorRules,
      defaultAvatarId
    } = req.body;

    const persona = await personaService.createPersona({
      userId: req.user.userId,
      name,
      gender,
      personalitySummary,
      speechStyle,
      backstory,
      behaviorRules,
      defaultAvatarId
    });
    res.status(201).json(persona);
  } catch (err) {
    next(err);
  }
});

// Listar personagens do usuário
router.get('/list', async (req, res, next) => {
  try {
    const characters = await characterService.listCharacters(req.user.userId);
    res.json(characters);
  } catch (err) {
    next(err);
  }
});

// Criar personagem (Character = User + Persona + Avatar)
router.post('/create', async (req, res, next) => {
  try {
    const { personaId, avatarId, nickname, aiConfigOverride } = req.body;
    const character = await characterService.createCharacter({
      userId: req.user.userId,
      personaId,
      avatarId,
      nickname,
      aiConfigOverride
    });
    res.status(201).json(character);
  } catch (err) {
    next(err);
  }
});

export default router;
