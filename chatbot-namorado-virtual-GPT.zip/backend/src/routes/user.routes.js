import { Router } from 'express';
import { userService } from '../services/user/user.service.js';
import { authenticateToken } from '../middleware/auth.middleware.js';

const router = Router();

router.use(authenticateToken);

router.get('/profile', async (req, res, next) => {
  try {
    const profile = await userService.getProfile(req.user.userId);
    res.json(profile);
  } catch (err) {
    next(err);
  }
});

router.post('/onboarding', async (req, res, next) => {
  try {
    const result = await userService.completeOnboarding(req.user.userId, req.body);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

export default router;
