import { Router } from 'express';
import { individualChatService } from '../services/chat/individual_chat.service.js';
import { authenticateToken } from '../middleware/auth.middleware.js';

const router = Router();

router.use(authenticateToken);

// Listar conversas
router.get('/conversations', async (req, res, next) => {
  try {
    const list = await individualChatService.listConversations(req.user.userId);
    res.json(list);
  } catch (err) {
    next(err);
  }
});

// Iniciar ou obter conversa individual com um Character
router.post('/conversations', async (req, res, next) => {
  try {
    const { characterId } = req.body;
    const conversation = await individualChatService.getOrCreateConversation({
      userId: req.user.userId,
      characterId
    });
    res.json(conversation);
  } catch (err) {
    next(err);
  }
});

// Obter histórico de mensagens e memória de uma conversa
router.get('/conversations/:id/messages', async (req, res, next) => {
  try {
    const data = await individualChatService.getMessages(req.params.id, req.user.userId);
    res.json(data);
  } catch (err) {
    next(err);
  }
});

// Enviar mensagem (Processa memória + AI Gateway + Resposta)
router.post('/messages', async (req, res, next) => {
  try {
    const { conversationId, content, contentType } = req.body;
    const result = await individualChatService.sendMessage({
      conversationId,
      userId: req.user.userId,
      content,
      contentType
    });
    res.json(result);
  } catch (err) {
    next(err);
  }
});

export default router;
