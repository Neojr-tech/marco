import { config } from './env.js';

/**
 * AI Providers Configuration
 * NOTA: Provedor definitivo: A DEFINIR.
 * Provedor provisório ativo: Google Gemini (@google/genai)
 */
export const aiProvidersConfig = {
  activeConversationProvider: 'gemini', // DECISÃO PROVISÓRIA — A VALIDAR
  gemini: {
    apiKey: config.geminiApiKey,
    model: 'gemini-3.7-flash',
    temperature: 0.85,
    topP: 0.95
  },
  // Preparados para futura substituição:
  openai: {
    apiKey: process.env.OPENAI_API_KEY || '',
    model: 'gpt-4o'
  },
  anthropic: {
    apiKey: process.env.ANTHROPIC_API_KEY || '',
    model: 'claude-3-5-sonnet-20241022'
  }
};
