import { config } from './env.js';

export const databaseConfig = {
  client: 'postgresql',
  connection: config.databaseUrl,
  pool: {
    min: 2,
    max: 10
  },
  migrations: {
    tableName: 'knex_migrations',
    directory: '../../database/migrations'
  },
  seeds: {
    directory: '../../database/seeds'
  }
};
