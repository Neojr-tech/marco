import { dbStore } from '../store/db_store.js';
import { CharacterModel } from '../../models/character.model.js';
import { RelationshipModel } from '../../models/relationship.model.js';

export class CharacterService {
  async listCharacters(userId) {
    const list = [];
    for (const char of dbStore.characters.values()) {
      if (char.user_id === userId && !char.archived_at) {
        const persona = dbStore.personas.get(char.persona_id);
        const avatar = dbStore.avatars.get(char.avatar_id);
        list.push({
          ...char,
          persona: persona || null,
          avatar: avatar || null
        });
      }
    }
    return list;
  }

  async getCharacterById(characterId, userId) {
    const char = dbStore.characters.get(characterId);
    if (!char || (userId && char.user_id !== userId)) {
      return null;
    }
    const persona = dbStore.personas.get(char.persona_id);
    const avatar = dbStore.avatars.get(char.avatar_id);
    return {
      ...char,
      persona,
      avatar
    };
  }

  async createCharacter({ userId, personaId, avatarId, nickname, aiConfigOverride }) {
    if (!userId || !personaId || !avatarId) {
      throw new Error('Usuário, Persona e Avatar são obrigatórios para criar um Character.');
    }

    const persona = dbStore.personas.get(personaId);
    if (!persona) {
      throw new Error('Persona informada não existe.');
    }

    const avatar = dbStore.avatars.get(avatarId);
    if (!avatar) {
      throw new Error('Avatar informado não existe.');
    }

    const character = new CharacterModel({
      user_id: userId,
      persona_id: personaId,
      avatar_id: avatarId,
      nickname: nickname || persona.name,
      ai_config_override: aiConfigOverride || null
    });

    dbStore.characters.set(character.id, character);

    // Inicializar relacionamento único Usuário <-> Personagem
    const relationship = new RelationshipModel({
      user_id: userId,
      character_id: character.id,
      level: 1,
      milestones: ['Primeira Conexão']
    });
    dbStore.relationships.set(relationship.id, relationship);

    return {
      ...character,
      persona,
      avatar,
      relationship
    };
  }
}

export const characterService = new CharacterService();
