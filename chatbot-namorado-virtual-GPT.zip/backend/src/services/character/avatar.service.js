import { dbStore } from '../store/db_store.js';
import { AvatarModel } from '../../models/avatar.model.js';

export class AvatarService {
  async listAvatars(userId) {
    const list = [];
    for (const avatar of dbStore.avatars.values()) {
      if (avatar.owner_type === 'system' || avatar.owner_id === userId) {
        list.push(avatar);
      }
    }
    return list;
  }

  async getAvatarById(avatarId) {
    return dbStore.avatars.get(avatarId) || null;
  }

  async createCustomAvatar({ userId, imageUrl, voiceRef, videoRef }) {
    const avatar = new AvatarModel({
      owner_type: 'user',
      owner_id: userId,
      image_url: imageUrl,
      voice_ref: voiceRef || null,
      video_ref: videoRef || null
    });
    dbStore.avatars.set(avatar.id, avatar);
    return avatar;
  }
}

export const avatarService = new AvatarService();
