import { dbStore } from '../store/db_store.js';
import { PersonaModel } from '../../models/persona.model.js';

export class PersonaService {
  async listPersonas(userId) {
    const list = [];
    for (const persona of dbStore.personas.values()) {
      if (persona.owner_type === 'system' || persona.owner_id === userId) {
        list.push(persona);
      }
    }
    return list;
  }

  async getPersonaById(personaId) {
    return dbStore.personas.get(personaId) || null;
  }

  async createPersona({
    userId,
    name,
    gender,
    personalitySummary,
    speechStyle,
    backstory,
    behaviorRules,
    defaultAvatarId
  }) {
    if (!name || !personalitySummary || !speechStyle) {
      throw new Error('Nome, resumo de personalidade e estilo de fala são obrigatórios.');
    }

    const persona = new PersonaModel({
      owner_type: userId ? 'user' : 'system',
      owner_id: userId || null,
      name,
      gender: gender || 'não-especificado',
      personality_summary: personalitySummary,
      speech_style: speechStyle,
      backstory: backstory || '',
      behavior_rules: behaviorRules || '',
      default_avatar_id: defaultAvatarId || null
    });

    dbStore.personas.set(persona.id, persona);
    return persona;
  }
}

export const personaService = new PersonaService();
