import { dbStore } from '../store/db_store.js';

export class UserService {
  async getProfile(userId) {
    const user = dbStore.users.get(userId);
    if (!user) {
      throw new Error('Usuário não encontrado.');
    }
    return {
      id: user.id,
      email: user.email,
      displayName: user.display_name,
      birthDate: user.birth_date,
      status: user.status,
      onboardingCompleted: !!user.onboarding_completed_at,
      createdAt: user.created_at
    };
  }

  async completeOnboarding(userId, preferences = {}) {
    const user = dbStore.users.get(userId);
    if (!user) {
      throw new Error('Usuário não encontrado.');
    }
    user.onboarding_completed_at = new Date().toISOString();
    user.updated_at = new Date().toISOString();
    dbStore.users.set(userId, user);

    return {
      success: true,
      onboardingCompletedAt: user.onboarding_completed_at
    };
  }
}

export const userService = new UserService();
