import { dbStore } from '../store/db_store.js';
import { ConversationMemoryModel } from '../../models/memory.model.js';

export class ConversationMemoryService {
  async getMemory(conversationId) {
    for (const mem of dbStore.conversationMemories.values()) {
      if (mem.conversation_id === conversationId) {
        return mem;
      }
    }
    return null;
  }

  async updateMemory(conversationId, summary) {
    let existing = await this.getMemory(conversationId);
    if (existing) {
      existing.summary = summary;
      existing.updated_at = new Date().toISOString();
      dbStore.conversationMemories.set(existing.id, existing);
      return existing;
    } else {
      const newMem = new ConversationMemoryModel({
        conversation_id: conversationId,
        summary
      });
      dbStore.conversationMemories.set(newMem.id, newMem);
      return newMem;
    }
  }

  /**
   * DECISÃO PROVISÓRIA — A VALIDAR:
   * Atualização incremental periódica do resumo da conversa
   */
  async summarizeRecentTurn(conversationId, userMsg, botMsg) {
    const mem = await this.getMemory(conversationId);
    const prevSummary = mem ? mem.summary : '';
    const newAddition = `Usuário conversou sobre "${userMsg.slice(0, 45)}...". O personagem respondeu afetuosamente.`;
    const updatedSummary = prevSummary ? `${prevSummary} | ${newAddition}` : newAddition;
    return await this.updateMemory(conversationId, updatedSummary);
  }
}

export const conversationMemoryService = new ConversationMemoryService();
