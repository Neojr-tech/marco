import { dbStore } from '../store/db_store.js';
import { UserMemoryModel } from '../../models/memory.model.js';

export class UserMemoryService {
  async getMemoriesByUserId(userId) {
    const list = [];
    for (const mem of dbStore.userMemories.values()) {
      if (mem.user_id === userId) {
        list.push(mem.fact);
      }
    }
    return list;
  }

  async addMemory({ userId, fact, sourceMessageId }) {
    const mem = new UserMemoryModel({
      user_id: userId,
      fact,
      source_message_id: sourceMessageId || null
    });
    dbStore.userMemories.set(mem.id, mem);
    return mem;
  }

  /**
   * Extração heurística/IA de fatos do usuário para teste da camada de memória
   * DECISÃO PROVISÓRIA — A VALIDAR
   */
  async extractAndStoreUserFacts(userId, messageText, messageId) {
    const lower = messageText.toLowerCase();
    const extracted = [];

    if (lower.includes('meu nome é') || lower.includes('me chamo')) {
      extracted.push(`Nome/identificação mencionada na mensagem: "${messageText.slice(0, 50)}"`);
    }
    if (lower.includes('gosto de') || lower.includes('amo') || lower.includes('meu sonho') || lower.includes('trabalho com')) {
      extracted.push(`Gosto/Preferência declarada: "${messageText.slice(0, 60)}"`);
    }
    if (lower.includes('triste') || lower.includes('cansad') || lower.includes('feliz') || lower.includes('ansios')) {
      extracted.push(`Estado emocional expressado: "${messageText.slice(0, 50)}"`);
    }

    for (const fact of extracted) {
      await this.addMemory({ userId, fact, sourceMessageId: messageId });
    }

    return extracted;
  }
}

export const userMemoryService = new UserMemoryService();
