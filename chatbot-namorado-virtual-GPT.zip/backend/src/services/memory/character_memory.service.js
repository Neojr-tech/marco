import { dbStore } from '../store/db_store.js';
import { CharacterMemoryModel } from '../../models/memory.model.js';

export class CharacterMemoryService {
  async getMemoriesByPersonaId(personaId) {
    const list = [];
    for (const mem of dbStore.characterMemories.values()) {
      if (mem.persona_id === personaId) {
        list.push(mem.fact);
      }
    }
    return list;
  }

  async addMemory({ personaId, fact }) {
    const mem = new CharacterMemoryModel({
      persona_id: personaId,
      fact
    });
    dbStore.characterMemories.set(mem.id, mem);
    return mem;
  }
}

export const characterMemoryService = new CharacterMemoryService();
