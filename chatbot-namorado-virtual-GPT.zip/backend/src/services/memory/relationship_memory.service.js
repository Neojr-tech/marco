import { dbStore } from '../store/db_store.js';
import { RelationshipModel } from '../../models/relationship.model.js';

export class RelationshipMemoryService {
  async getRelationship(userId, characterId) {
    for (const rel of dbStore.relationships.values()) {
      if (rel.user_id === userId && rel.character_id === characterId) {
        return rel;
      }
    }

    // Criar se não existir
    const newRel = new RelationshipModel({
      user_id: userId,
      character_id: characterId,
      level: 1,
      milestones: ['Início da Conexão']
    });
    dbStore.relationships.set(newRel.id, newRel);
    return newRel;
  }

  /**
   * Atualização de nível de relacionamento
   * NOTA: Regras de gamificação: A DEFINIR.
   * Incremento provisório suave a cada conversa para demonstrar a camada (DECISÃO PROVISÓRIA — A VALIDAR)
   */
  async incrementInteraction(userId, characterId, totalMessagesCount = 1) {
    const rel = await this.getRelationship(userId, characterId);
    let updated = false;

    if (totalMessagesCount >= 5 && rel.level < 2) {
      rel.level = 2;
      rel.milestones.push('Primeira Troca Profunda');
      updated = true;
    } else if (totalMessagesCount >= 15 && rel.level < 3) {
      rel.level = 3;
      rel.milestones.push('Cumplicidade Estabelecida');
      updated = true;
    }

    if (updated) {
      rel.updated_at = new Date().toISOString();
      dbStore.relationships.set(rel.id, rel);
    }

    return rel;
  }
}

export const relationshipMemoryService = new RelationshipMemoryService();
