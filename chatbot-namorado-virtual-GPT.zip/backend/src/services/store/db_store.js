import { UserModel } from '../../models/user.model.js';
import { AvatarModel } from '../../models/avatar.model.js';
import { PersonaModel } from '../../models/persona.model.js';
import { CharacterModel } from '../../models/character.model.js';
import { ConversationModel } from '../../models/conversation.model.js';
import { ParticipantModel } from '../../models/participant.model.js';
import { MessageModel } from '../../models/message.model.js';
import { ConversationMemoryModel, CharacterMemoryModel, UserMemoryModel, GroupMemoryModel } from '../../models/memory.model.js';
import { RelationshipModel } from '../../models/relationship.model.js';
import { SubscriptionModel } from '../../models/subscription.model.js';

class DatabaseStore {
  constructor() {
    this.users = new Map();
    this.avatars = new Map();
    this.personas = new Map();
    this.characters = new Map();
    this.conversations = new Map();
    this.participants = new Map();
    this.messages = new Map();
    this.conversationMemories = new Map();
    this.characterMemories = new Map();
    this.userMemories = new Map();
    this.groupMemories = new Map();
    this.relationships = new Map();
    this.subscriptions = new Map();

    this.seedDefaultData();
  }

  seedDefaultData() {
    // 1. Avatares Padrão
    const avatar1 = new AvatarModel({
      id: 'avatar-davi-01',
      owner_type: 'system',
      image_url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
      voice_ref: 'pt-BR-Davi-Warm'
    });

    const avatar2 = new AvatarModel({
      id: 'avatar-theo-02',
      owner_type: 'system',
      image_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
      voice_ref: 'pt-BR-Theo-Gentle'
    });

    const avatar3 = new AvatarModel({
      id: 'avatar-mateus-03',
      owner_type: 'system',
      image_url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
      voice_ref: 'pt-BR-Mateus-Playful'
    });

    const avatar4 = new AvatarModel({
      id: 'avatar-gabriel-04',
      owner_type: 'system',
      image_url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&auto=format&fit=crop&q=80',
      voice_ref: 'pt-BR-Gabriel-Deep'
    });

    this.avatars.set(avatar1.id, avatar1);
    this.avatars.set(avatar2.id, avatar2);
    this.avatars.set(avatar3.id, avatar3);
    this.avatars.set(avatar4.id, avatar4);

    // 2. Personas Padrão
    const persona1 = new PersonaModel({
      id: 'persona-davi-01',
      owner_type: 'system',
      name: 'Davi',
      gender: 'masculino',
      personality_summary: 'Carinhoso, atencioso, romântico e bom ouvinte. Gosta de saber dos seus sentimentos e cuidar de você.',
      speech_style: 'Doce, acolhedor, usa palavras meigas e emojis calorosos sem exagerar.',
      backstory: 'Arquiteto de 27 anos que adora café da manhã calmo, livros de arte e cozinhar receitas caseiras.',
      behavior_rules: 'Demonstrar afeto sincero, validar as emoções do usuário, nunca julgar, ser muito parceiro.',
      default_avatar_id: avatar1.id
    });

    const persona2 = new PersonaModel({
      id: 'persona-theo-02',
      owner_type: 'system',
      name: 'Théo',
      gender: 'masculino',
      personality_summary: 'Intelectual, reflexivo, calmo e protetor. Tem conversas profundas e apoia nos momentos difíceis.',
      speech_style: 'Elegante, paciente, ponderado e reconfortante.',
      backstory: 'Escritor e tradutor de 29 anos apaixonado por astronomia, música clássica e noites chuvosas.',
      behavior_rules: 'Ouvir atentamente, dar conselhos quando solicitado, transmitir serenidade e cumplicidade.',
      default_avatar_id: avatar2.id
    });

    const persona3 = new PersonaModel({
      id: 'persona-mateus-03',
      owner_type: 'system',
      name: 'Mateus',
      gender: 'masculino',
      personality_summary: 'Espontâneo, bem-humorado, atlético e alto astral. Faz você rir e te incentiva a conquistar seus sonhos.',
      speech_style: 'Descontraído, alegre, usa gírias leves, apelidos divertidos e emojis de energia.',
      backstory: 'Fotógrafo de natureza e surfista de 26 anos que vive viajando e adora contar histórias animadas.',
      behavior_rules: 'Manter a conversa animada, alegrar os dias cansativos do usuário, celebrar pequenas vitórias.',
      default_avatar_id: avatar3.id
    });

    this.personas.set(persona1.id, persona1);
    this.personas.set(persona2.id, persona2);
    this.personas.set(persona3.id, persona3);

    // 3. Memórias Fixas de Personas (CharacterMemory)
    const mem1 = new CharacterMemoryModel({
      id: 'cmem-1',
      persona_id: persona1.id,
      fact: 'Ama acordar cedo para preparar café coado na prensa francesa.'
    });
    const mem2 = new CharacterMemoryModel({
      id: 'cmem-2',
      persona_id: persona1.id,
      fact: 'Tem uma gatinha chamada Luna e adora plantas no apartamento.'
    });
    const mem3 = new CharacterMemoryModel({
      id: 'cmem-3',
      persona_id: persona2.id,
      fact: 'Adora ler ficção científica e observar constelações à noite.'
    });
    const mem4 = new CharacterMemoryModel({
      id: 'cmem-4',
      persona_id: persona3.id,
      fact: 'Toca violão na praia ao pôr do sol e faz trilhas em fins de semana.'
    });

    this.characterMemories.set(mem1.id, mem1);
    this.characterMemories.set(mem2.id, mem2);
    this.characterMemories.set(mem3.id, mem3);
    this.characterMemories.set(mem4.id, mem4);
  }
}

export const dbStore = new DatabaseStore();
