import { dbStore } from '../store/db_store.js';
import { UserModel } from '../../models/user.model.js';

export class AuthService {
  async register({ email, password, displayName, birthDate }) {
    if (!email || !displayName) {
      throw new Error('E-mail e nome de exibição são obrigatórios.');
    }

    // Verificar se usuário já existe
    for (const user of dbStore.users.values()) {
      if (user.email.toLowerCase() === email.toLowerCase()) {
        throw new Error('E-mail já cadastrado.');
      }
    }

    // Hash simplificado de senha para teste (DECISÃO PROVISÓRIA — A VALIDAR)
    const passwordHash = password ? `hash_${Buffer.from(password).toString('base64')}` : null;

    const user = new UserModel({
      email,
      password_hash: passwordHash,
      display_name: displayName,
      birth_date: birthDate || null,
      auth_provider: 'email',
      status: 'active'
    });

    dbStore.users.set(user.id, user);

    // Gerar token de sessão
    const token = Buffer.from(JSON.stringify({ userId: user.id, email: user.email })).toString('base64');

    return {
      token,
      user: {
        id: user.id,
        email: user.email,
        displayName: user.display_name,
        birthDate: user.birth_date,
        onboardingCompleted: !!user.onboarding_completed_at
      }
    };
  }

  async login({ email, password }) {
    if (!email) {
      throw new Error('E-mail é obrigatório.');
    }

    let foundUser = null;
    for (const user of dbStore.users.values()) {
      if (user.email.toLowerCase() === email.toLowerCase()) {
        foundUser = user;
        break;
      }
    }

    if (!foundUser) {
      // Auto-cadastro para facilitar testes no protótipo se usuário não existir
      const reg = await this.register({
        email,
        password: password || 'default123',
        displayName: email.split('@')[0] || 'Usuário'
      });
      return reg;
    }

    const token = Buffer.from(JSON.stringify({ userId: foundUser.id, email: foundUser.email })).toString('base64');

    return {
      token,
      user: {
        id: foundUser.id,
        email: foundUser.email,
        displayName: foundUser.display_name,
        birthDate: foundUser.birth_date,
        onboardingCompleted: !!foundUser.onboarding_completed_at
      }
    };
  }
}

export const authService = new AuthService();
