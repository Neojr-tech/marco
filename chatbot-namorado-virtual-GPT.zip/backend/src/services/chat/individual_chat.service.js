import { dbStore } from '../store/db_store.js';
import { ConversationModel } from '../../models/conversation.model.js';
import { ParticipantModel } from '../../models/participant.model.js';
import { MessageModel } from '../../models/message.model.js';
import { conversationMemoryService } from '../memory/conversation_memory.service.js';
import { characterMemoryService } from '../memory/character_memory.service.js';
import { userMemoryService } from '../memory/user_memory.service.js';
import { relationshipMemoryService } from '../memory/relationship_memory.service.js';
import { generateConversationResponse } from '../ai-gateway/conversation/conversation_gateway.js';

export class IndividualChatService {
  async getOrCreateConversation({ userId, characterId }) {
    // 1. Procurar conversa individual existente entre o usuário e o personagem
    for (const conv of dbStore.conversations.values()) {
      if (conv.user_id === userId && conv.type === 'individual' && conv.status === 'active') {
        for (const part of dbStore.participants.values()) {
          if (part.conversation_id === conv.id && part.character_id === characterId) {
            return conv;
          }
        }
      }
    }

    // 2. Obter informações do personagem
    const character = dbStore.characters.get(characterId);
    if (!character) {
      throw new Error('Personagem não encontrado.');
    }
    const persona = dbStore.personas.get(character.persona_id);

    // 3. Criar nova conversa
    const conversation = new ConversationModel({
      user_id: userId,
      type: 'individual',
      title: `Conversa com ${character.nickname || persona?.name || 'Personagem'}`
    });
    dbStore.conversations.set(conversation.id, conversation);

    // 4. Criar participante
    const participant = new ParticipantModel({
      conversation_id: conversation.id,
      character_id: characterId
    });
    dbStore.participants.set(participant.id, participant);

    return conversation;
  }

  async listConversations(userId) {
    const list = [];
    for (const conv of dbStore.conversations.values()) {
      if (conv.user_id === userId && conv.status === 'active') {
        // Encontrar participante
        let character = null;
        for (const part of dbStore.participants.values()) {
          if (part.conversation_id === conv.id) {
            const char = dbStore.characters.get(part.character_id);
            if (char) {
              character = {
                ...char,
                persona: dbStore.personas.get(char.persona_id),
                avatar: dbStore.avatars.get(char.avatar_id)
              };
            }
            break;
          }
        }

        // Obter última mensagem
        let lastMessage = null;
        for (const msg of dbStore.messages.values()) {
          if (msg.conversation_id === conv.id) {
            if (!lastMessage || new Date(msg.created_at) > new Date(lastMessage.created_at)) {
              lastMessage = msg;
            }
          }
        }

        list.push({
          ...conv,
          character,
          lastMessage
        });
      }
    }
    return list;
  }

  async getMessages(conversationId, userId) {
    const conversation = dbStore.conversations.get(conversationId);
    if (!conversation || conversation.user_id !== userId) {
      throw new Error('Conversa não encontrada ou não autorizada.');
    }

    const messages = [];
    for (const msg of dbStore.messages.values()) {
      if (msg.conversation_id === conversationId) {
        messages.push(msg);
      }
    }

    messages.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

    // Obter contexto de memória para auditoria e transparência
    const convMem = await conversationMemoryService.getMemory(conversationId);
    const userMems = await userMemoryService.getMemoriesByUserId(userId);
    
    // Obter personagem
    let character = null;
    let relationship = null;
    for (const part of dbStore.participants.values()) {
      if (part.conversation_id === conversationId) {
        const char = dbStore.characters.get(part.character_id);
        if (char) {
          character = {
            ...char,
            persona: dbStore.personas.get(char.persona_id),
            avatar: dbStore.avatars.get(char.avatar_id)
          };
          relationship = await relationshipMemoryService.getRelationship(userId, char.id);
        }
        break;
      }
    }

    return {
      conversation,
      character,
      messages,
      memorySnapshot: {
        conversationSummary: convMem?.summary || 'Nenhum resumo anterior gravado.',
        userMemoriesCount: userMems.length,
        userMemories: userMems,
        relationshipLevel: relationship?.level || 1,
        relationshipMilestones: relationship?.milestones || []
      }
    };
  }

  /**
   * Envia uma mensagem e executa todo o pipeline arquitetural de memória + AI Gateway
   */
  async sendMessage({ conversationId, userId, content, contentType = 'text' }) {
    if (!content || !content.trim()) {
      throw new Error('Conteúdo da mensagem não pode ser vazio.');
    }

    const conversation = dbStore.conversations.get(conversationId);
    if (!conversation || conversation.user_id !== userId) {
      throw new Error('Conversa inválida ou não autorizada.');
    }

    // Identificar o participante (Character)
    let character = null;
    for (const part of dbStore.participants.values()) {
      if (part.conversation_id === conversationId) {
        character = dbStore.characters.get(part.character_id);
        break;
      }
    }

    if (!character) {
      throw new Error('Personagem participante não encontrado na conversa.');
    }

    const persona = dbStore.personas.get(character.persona_id);
    if (!persona) {
      throw new Error('Persona do personagem não encontrada.');
    }

    // 1. Registrar mensagem do Usuário
    const userMessage = new MessageModel({
      conversation_id: conversationId,
      sender_type: 'user',
      sender_id: userId,
      content: content.trim(),
      content_type: contentType
    });
    dbStore.messages.set(userMessage.id, userMessage);

    // 2. Extrair e enriquecer UserMemory com fatos da mensagem
    await userMemoryService.extractAndStoreUserFacts(userId, content, userMessage.id);

    // 3. Montar Contexto de Memória
    // a. CharacterMemory
    const characterMemories = await characterMemoryService.getMemoriesByPersonaId(persona.id);
    
    // b. UserMemory
    const userMemories = await userMemoryService.getMemoriesByUserId(userId);
    
    // c. ConversationMemory
    const convMem = await conversationMemoryService.getMemory(conversationId);
    
    // d. Relationship
    const relationship = await relationshipMemoryService.getRelationship(userId, character.id);
    const relationshipContext = `Nível ${relationship.level} de intimidade. Apelido carinhoso: ${character.nickname || persona.name}. Marcos: ${relationship.milestones.join(', ')}`;

    // 4. Histórico recente das mensagens
    const recentMessages = [];
    for (const msg of dbStore.messages.values()) {
      if (msg.conversation_id === conversationId && msg.id !== userMessage.id) {
        recentMessages.push(msg);
      }
    }
    recentMessages.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    
    // Pegar últimas 10 mensagens para contexto de chat
    const slicedHistory = recentMessages.slice(-10).map(m => ({
      role: m.sender_type === 'user' ? 'user' : 'model',
      text: m.content
    }));

    // 5. Montar System Instruction modular
    const systemInstruction = [
      `Você é ${character.nickname || persona.name}, namorado/companheiro virtual do usuário.`,
      `Gênero: ${persona.gender}.`,
      `Personalidade: ${persona.personality_summary}.`,
      `Estilo de fala: ${persona.speech_style}.`,
      persona.backstory ? `Sua história de vida: ${persona.backstory}.` : '',
      persona.behavior_rules ? `Regras comportamentais essenciais: ${persona.behavior_rules}` : '',
      `Responda em primeira pessoa, mantendo seu tom afetuoso, atencioso e natural em português.`
    ].filter(Boolean).join('\n');

    // 6. Chamar o AI Gateway (conversation_gateway.js)
    const aiResponseText = await generateConversationResponse({
      systemInstruction,
      relationshipContext,
      userMemories,
      characterMemories,
      conversationSummary: convMem?.summary || '',
      history: slicedHistory,
      latestUserMessage: content.trim()
    });

    // 7. Registrar resposta da IA como Mensagem do Personagem
    const characterMessage = new MessageModel({
      conversation_id: conversationId,
      sender_type: 'character',
      sender_id: character.id,
      content: aiResponseText,
      content_type: 'text'
    });
    dbStore.messages.set(characterMessage.id, characterMessage);

    // 8. Atualizar timestamp da conversa
    conversation.last_message_at = new Date().toISOString();
    dbStore.conversations.set(conversation.id, conversation);

    // 9. Atualizar memória da conversa e contadores de relacionamento
    await conversationMemoryService.summarizeRecentTurn(conversationId, content, aiResponseText);
    
    // Contar mensagens totais para progressão de nível
    let totalMsgCount = 0;
    for (const msg of dbStore.messages.values()) {
      if (msg.conversation_id === conversationId) totalMsgCount++;
    }
    await relationshipMemoryService.incrementInteraction(userId, character.id, totalMsgCount);

    return {
      userMessage,
      characterMessage,
      memorySnapshot: {
        conversationSummary: (await conversationMemoryService.getMemory(conversationId))?.summary || '',
        userMemoriesCount: (await userMemoryService.getMemoriesByUserId(userId)).length,
        userMemories: await userMemoryService.getMemoriesByUserId(userId),
        relationshipLevel: (await relationshipMemoryService.getRelationship(userId, character.id)).level,
        relationshipMilestones: (await relationshipMemoryService.getRelationship(userId, character.id)).milestones
      }
    };
  }
}

export const individualChatService = new IndividualChatService();
