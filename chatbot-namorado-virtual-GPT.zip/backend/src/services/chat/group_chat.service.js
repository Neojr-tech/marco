import { dbStore } from '../store/db_store.js';
import { ConversationModel } from '../../models/conversation.model.js';
import { ParticipantModel } from '../../models/participant.model.js';

/**
 * Group Chat Service (Preparado arquiteturalmente para conversas em grupo com 2+ personagens)
 */
export class GroupChatService {
  async createGroupConversation({ userId, title, characterIds = [] }) {
    if (!characterIds || characterIds.length < 2) {
      throw new Error('Conversa em grupo requer 2 ou mais personagens.');
    }

    const conversation = new ConversationModel({
      user_id: userId,
      type: 'group',
      title: title || 'Grupo com Personagens'
    });
    dbStore.conversations.set(conversation.id, conversation);

    for (const charId of characterIds) {
      const part = new ParticipantModel({
        conversation_id: conversation.id,
        character_id: charId,
        role_in_group: 'member'
      });
      dbStore.participants.set(part.id, part);
    }

    return conversation;
  }
}

export const groupChatService = new GroupChatService();
