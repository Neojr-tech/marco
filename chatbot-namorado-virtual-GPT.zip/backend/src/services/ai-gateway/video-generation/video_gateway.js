/**
 * Video Generation Gateway (Preparado arquiteturalmente)
 * Provedor definitivo: A DEFINIR
 */
export async function generateCharacterVideo({ avatarId, spokenText, gesture }) {
  console.log(`[Video Gateway]: Preparado para avatar ${avatarId}`);
  return {
    status: 'prepared',
    provider: 'A DEFINIR',
    videoUrl: null
  };
}
