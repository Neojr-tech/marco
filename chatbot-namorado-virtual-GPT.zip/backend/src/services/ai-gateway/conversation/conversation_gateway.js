import { GoogleGenAI } from '@google/genai';
import { aiProvidersConfig } from '../../../config/ai_providers.config.js';

let geminiClient = null;

function getGeminiClient() {
  if (!geminiClient) {
    const apiKey = process.env.GEMINI_API_KEY || aiProvidersConfig.gemini.apiKey;
    if (apiKey) {
      geminiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });
    }
  }
  return geminiClient;
}

/**
 * Gateway de Conversação
 * Isolamento total: Este é o ÚNICO ponto que interage com o provedor de conversação de IA.
 * DECISÃO PROVISÓRIA — A VALIDAR: Provedor provisório Google Gemini 3.7 Flash
 */
export async function generateConversationResponse({
  systemInstruction,
  relationshipContext,
  userMemories = [],
  characterMemories = [],
  conversationSummary = '',
  history = [],
  latestUserMessage
}) {
  const ai = getGeminiClient();

  // Construir bloco de contexto estruturado
  const contextParts = [
    systemInstruction,
    '\n=== MEMÓRIAS FIXAS DO PERSONAGEM (CharacterMemory) ===',
    characterMemories.length > 0 ? characterMemories.map(m => `- ${m}`).join('\n') : 'Nenhuma memória fixa adicional.',
    '\n=== ESTADO DO RELACIONAMENTO (Relationship) ===',
    relationshipContext || 'Nível 1 - Conexão inicial afetuosa.',
    '\n=== FATOS SOBRE O USUÁRIO (UserMemory) ===',
    userMemories.length > 0 ? userMemories.map(m => `- ${m}`).join('\n') : 'Ainda aprendendo sobre o usuário.',
    '\n=== RESUMO DE CONVERSAS ANTERIORES (ConversationMemory) ===',
    conversationSummary || 'Início da conversa recente.'
  ].join('\n');

  // Fallback seguro se não houver chave de API configurada no ambiente
  if (!ai) {
    console.warn('[AI Gateway Conversation]: Chave GEMINI_API_KEY não encontrada. Utilizando fallback simulado.');
    return `Oi meu bem! Que bom conversar com você. Estou aqui sempre que você quiser desabafar ou só trocar um carinho. O que mais você fez hoje?`;
  }

  try {
    // Formatar histórico para o Gemini
    // Assegurar formato alternado user/model
    const contents = [];
    
    // Incluir mensagens do histórico recente
    for (const msg of history) {
      contents.push({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
      });
    }

    // Adicionar mensagem atual
    contents.push({
      role: 'user',
      parts: [{ text: latestUserMessage }]
    });

    const response = await ai.models.generateContent({
      model: aiProvidersConfig.gemini.model,
      contents,
      config: {
        systemInstruction: contextParts,
        temperature: aiProvidersConfig.gemini.temperature,
        topP: aiProvidersConfig.gemini.topP
      }
    });

    return response.text?.trim() || 'Oi amor, me perdi um segundo nos meus pensamentos aqui... Pode me falar de novo?';
  } catch (error) {
    console.error('[AI Gateway Conversation Error]:', error);
    // Em caso de erro transitório de rede/quota, fornecer resposta empática coerente
    return 'Amor, deu uma falha rápida na minha conexão aqui, mas já estou de volta! Pode me falar mais sobre isso?';
  }
}
