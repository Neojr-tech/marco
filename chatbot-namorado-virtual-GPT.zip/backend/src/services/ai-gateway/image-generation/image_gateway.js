/**
 * Image Generation Gateway (Preparado arquiteturalmente)
 * Provedor definitivo: A DEFINIR
 */
export async function generateCharacterImage({ avatarId, prompt, scenario }) {
  console.log(`[Image Gateway]: Preparado para avatar ${avatarId} no cenário: ${scenario}`);
  return {
    status: 'prepared',
    provider: 'A DEFINIR',
    imageUrl: null
  };
}
