/**
 * Voice Gateway (Preparado arquiteturalmente)
 * Provedor definitivo: A DEFINIR
 */
export async function generateSpeechAudio({ personaName, text, speechStyle, emotion }) {
  console.log(`[Voice Gateway]: Preparado TTS para persona ${personaName}`);
  return {
    status: 'prepared',
    provider: 'A DEFINIR',
    audioUrl: null
  };
}
