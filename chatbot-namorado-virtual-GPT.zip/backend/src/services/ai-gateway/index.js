/**
 * AI Gateway Entry Point
 * Ponto de entrada unificado para todos os gateways de inteligência artificial.
 */
import * as conversationGateway from './conversation/conversation_gateway.js';
import * as visionGateway from './vision/vision_gateway.js';
import * as imageGateway from './image-generation/image_gateway.js';
import * as videoGateway from './video-generation/video_gateway.js';
import * as voiceGateway from './voice/voice_gateway.js';

export const aiGateway = {
  conversation: conversationGateway,
  vision: visionGateway,
  image: imageGateway,
  video: videoGateway,
  voice: voiceGateway
};

export default aiGateway;
