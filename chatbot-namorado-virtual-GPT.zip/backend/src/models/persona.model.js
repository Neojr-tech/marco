import crypto from 'crypto';

export class PersonaModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.owner_type = data.owner_type || 'system'; // system, user
    this.owner_id = data.owner_id || null;
    this.name = data.name;
    this.gender = data.gender; // DECISÃO PROVISÓRIA — A VALIDAR
    this.personality_summary = data.personality_summary;
    this.speech_style = data.speech_style;
    this.backstory = data.backstory || '';
    this.behavior_rules = data.behavior_rules || '';
    this.default_avatar_id = data.default_avatar_id || null;
    this.created_at = data.created_at || new Date().toISOString();
    this.updated_at = data.updated_at || new Date().toISOString();
  }
}
