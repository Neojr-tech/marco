import crypto from 'crypto';

export class RelationshipModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.subject_type = data.subject_type || 'user_character';
    this.user_id = data.user_id;
    this.character_id = data.character_id;
    this.related_character_id = data.related_character_id || null; // Futuro
    this.level = data.level || 1;
    this.milestones = data.milestones || ['Início da Conexão'];
    this.updated_at = data.updated_at || new Date().toISOString();
  }
}
