import crypto from 'crypto';

export class SubscriptionModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.user_id = data.user_id;
    this.plan = data.plan || 'free'; // A DEFINIR
    this.status = data.status || 'active';
    this.started_at = data.started_at || new Date().toISOString();
    this.ends_at = data.ends_at || null;
  }
}
