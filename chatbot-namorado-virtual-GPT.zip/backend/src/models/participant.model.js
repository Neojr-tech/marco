import crypto from 'crypto';

export class ParticipantModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.conversation_id = data.conversation_id;
    this.character_id = data.character_id;
    this.joined_at = data.joined_at || new Date().toISOString();
    this.role_in_group = data.role_in_group || null; // Futuro
  }
}
