import crypto from 'crypto';

export class UserModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.email = data.email;
    this.password_hash = data.password_hash || null;
    this.display_name = data.display_name;
    this.birth_date = data.birth_date || null;
    this.auth_provider = data.auth_provider || 'email';
    this.created_at = data.created_at || new Date().toISOString();
    this.updated_at = data.updated_at || new Date().toISOString();
    this.status = data.status || 'active';
    this.onboarding_completed_at = data.onboarding_completed_at || null;
  }
}
