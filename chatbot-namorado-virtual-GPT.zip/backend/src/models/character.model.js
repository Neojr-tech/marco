import crypto from 'crypto';

export class CharacterModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.user_id = data.user_id;
    this.persona_id = data.persona_id;
    this.avatar_id = data.avatar_id;
    this.nickname = data.nickname || null;
    this.ai_config_override = data.ai_config_override || null; // Futuro
    this.created_at = data.created_at || new Date().toISOString();
    this.archived_at = data.archived_at || null;
  }
}
