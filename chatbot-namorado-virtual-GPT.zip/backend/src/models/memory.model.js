import crypto from 'crypto';

export class ConversationMemoryModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.conversation_id = data.conversation_id;
    this.summary = data.summary || '';
    this.updated_at = data.updated_at || new Date().toISOString();
  }
}

export class CharacterMemoryModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.persona_id = data.persona_id;
    this.fact = data.fact;
    this.created_at = data.created_at || new Date().toISOString();
  }
}

export class UserMemoryModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.user_id = data.user_id;
    this.fact = data.fact;
    this.source_message_id = data.source_message_id || null;
    this.created_at = data.created_at || new Date().toISOString();
  }
}

export class GroupMemoryModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.conversation_id = data.conversation_id;
    this.group_fact = data.group_fact;
    this.created_at = data.created_at || new Date().toISOString();
  }
}
