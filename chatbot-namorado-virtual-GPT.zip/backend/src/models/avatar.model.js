import crypto from 'crypto';

export class AvatarModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.owner_type = data.owner_type || 'system'; // system, user
    this.owner_id = data.owner_id || null;
    this.image_url = data.image_url;
    this.voice_ref = data.voice_ref || null; // Futuro
    this.video_ref = data.video_ref || null; // Futuro
    this.created_at = data.created_at || new Date().toISOString();
  }
}
