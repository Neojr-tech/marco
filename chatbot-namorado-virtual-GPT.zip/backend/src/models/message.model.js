import crypto from 'crypto';

export class MessageModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.conversation_id = data.conversation_id;
    this.sender_type = data.sender_type; // 'user' | 'character'
    this.sender_id = data.sender_id;
    this.content = data.content;
    this.content_type = data.content_type || 'text'; // 'text' | 'image' | 'audio' | 'video'
    this.media_url = data.media_url || null;
    this.created_at = data.created_at || new Date().toISOString();
    this.reply_to_message_id = data.reply_to_message_id || null;
  }
}
