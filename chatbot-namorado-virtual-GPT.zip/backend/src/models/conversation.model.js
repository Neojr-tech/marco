import crypto from 'crypto';

export class ConversationModel {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.user_id = data.user_id;
    this.type = data.type || 'individual'; // individual, group
    this.title = data.title || 'Nova Conversa';
    this.created_at = data.created_at || new Date().toISOString();
    this.last_message_at = data.last_message_at || new Date().toISOString();
    this.status = data.status || 'active';
  }
}
