import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

// Rotas do backend
import authRoutes from './backend/src/routes/auth.routes.js';
import userRoutes from './backend/src/routes/user.routes.js';
import characterRoutes from './backend/src/routes/character.routes.js';
import chatRoutes from './backend/src/routes/chat.routes.js';
import groupRoutes from './backend/src/routes/group.routes.js';
import { errorHandler } from './backend/src/middleware/error_handler.middleware.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Rotas de API
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      app: 'Chatbot Namorado Virtual',
      architecture: {
        backend: 'Node.js Express',
        frontend: 'Flutter (app/) & Web Preview (src/)',
        aiGateway: 'conversation_gateway.js (Google Gemini 3.7 Flash - Provisório)',
        memoryLayers: ['ConversationMemory', 'CharacterMemory', 'UserMemory', 'Relationship']
      },
      timestamp: new Date().toISOString()
    });
  });

  app.use('/api/auth', authRoutes);
  app.use('/api/user', userRoutes);
  app.use('/api/character', characterRoutes);
  app.use('/api/chat', chatRoutes);
  app.use('/api/group', groupRoutes);

  // Tratador central de erros de API
  app.use(errorHandler);

  // Vite middleware para desenvolvimento / SPA no navegador
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Namorado Virtual Server] Executando na porta ${PORT} (0.0.0.0:${PORT})`);
  });
}

startServer();
