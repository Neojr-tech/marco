import React, { useState } from 'react';
import { Heart, Lock, Mail, User, Sparkles } from 'lucide-react';

interface AuthModalProps {
  onLogin: (email: string, pass: string) => Promise<boolean>;
  onRegister: (email: string, pass: string, name: string) => Promise<boolean>;
  isLoading: boolean;
  errorMessage: string | null;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  onLogin,
  onRegister,
  isLoading,
  errorMessage
}) => {
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('Usuário');
  const [email, setEmail] = useState('usuario@exemplo.com');
  const [password, setPassword] = useState('senha123');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isRegister) {
      await onRegister(email, password, name);
    } else {
      await onLogin(email, password);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <div className="bg-white/95 backdrop-blur-md rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl shadow-pink-200/40 border border-[#FFCCD5] animate-in fade-in zoom-in duration-200">
        <div className="text-center mb-6">
          <div className="w-14 h-14 bg-[#FFF0F3] border border-[#FFCCD5] rounded-2xl flex items-center justify-center mx-auto mb-3 text-[#FF4D6D] shadow-sm shadow-[#FF4D6D]/15">
            <Heart className="w-7 h-7 fill-[#FF4D6D]" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
            Chatbot Namorado Virtual
          </h2>
          <p className="text-xs text-slate-500 mt-1 font-medium">
            {isRegister ? 'Crie sua conta para conhecer seu parceiro' : 'Acesse sua conta para continuar conversando'}
          </p>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 bg-[#FFF0F3] text-[#C9184A] text-xs rounded-xl border border-[#FFCCD5] font-medium">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Seu Nome / Apelido</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Como quer ser chamado(a)?"
                  className="w-full pl-9 pr-3 py-2.5 bg-[#FFF0F3]/40 border border-[#FFCCD5] rounded-xl text-sm focus:outline-hidden focus:border-[#FF4D6D] focus:ring-2 focus:ring-[#FF4D6D]/20 focus:bg-white transition-all text-slate-800"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">E-mail</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                className="w-full pl-9 pr-3 py-2.5 bg-[#FFF0F3]/40 border border-[#FFCCD5] rounded-xl text-sm focus:outline-hidden focus:border-[#FF4D6D] focus:ring-2 focus:ring-[#FF4D6D]/20 focus:bg-white transition-all text-slate-800"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Senha</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2.5 bg-[#FFF0F3]/40 border border-[#FFCCD5] rounded-xl text-sm focus:outline-hidden focus:border-[#FF4D6D] focus:ring-2 focus:ring-[#FF4D6D]/20 focus:bg-white transition-all text-slate-800"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-2 py-3 px-4 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] active:scale-[0.99] text-white text-sm font-semibold rounded-xl transition-all shadow-md shadow-[#FF4D6D]/25 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                {isRegister ? 'Cadastrar e Começar' : 'Entrar na Conta'}
              </>
            )}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            type="button"
            onClick={() => setIsRegister(!isRegister)}
            className="text-xs text-[#C9184A] hover:text-[#800F2F] font-bold hover:underline"
          >
            {isRegister ? 'Já possui conta? Clique para Entrar' : 'Não tem conta? Crie uma agora'}
          </button>
        </div>
      </div>
    </div>
  );
};
