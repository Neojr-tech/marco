import React from 'react';
import { User, Character } from '../types';
import { Settings, User as UserIcon, LogOut, X, Sparkles, Shield, RefreshCw } from 'lucide-react';

interface SettingsModalProps {
  user: User | null;
  character: Character | null;
  onLogout: () => void;
  onOpenCreation: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  user,
  character,
  onLogout,
  onOpenCreation,
  onClose
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
      <div className="bg-white/95 backdrop-blur-md rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl shadow-pink-200/40 border border-[#FFCCD5] max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#FFCCD5] pb-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#FFF0F3] text-[#FF4D6D] border border-[#FFCCD5] rounded-xl flex items-center justify-center shadow-xs">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Configurações</h2>
              <p className="text-xs text-slate-500 font-medium">Perfil e parâmetros do protótipo</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#FFF0F3] text-slate-400 hover:text-[#FF4D6D] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs">
          {/* Dados do Usuário */}
          <div className="p-4 bg-[#FFF0F3]/40 rounded-2xl border border-[#FFCCD5] space-y-2">
            <h4 className="font-bold text-slate-800 flex items-center gap-2">
              <UserIcon className="w-4 h-4 text-[#FF4D6D]" />
              Sua Conta
            </h4>
            <div className="flex justify-between py-1 border-b border-[#FFCCD5]/60">
              <span className="text-slate-500">Nome:</span>
              <span className="font-semibold text-slate-800">{user?.displayName || 'Usuário'}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-500">E-mail:</span>
              <span className="font-semibold text-slate-800">{user?.email || '-'}</span>
            </div>
          </div>

          {/* Gerenciar Personagens */}
          <div className="p-4 bg-[#FFF0F3] rounded-2xl border border-[#FFCCD5] space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-[#800F2F] flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#FF4D6D]" />
                Personagem Atual
              </h4>
              <span className="text-[11px] font-bold text-[#C9184A] bg-[#FFE5EC] px-2.5 py-0.5 rounded-full border border-[#FFCCD5]">
                {character ? character.nickname || character.persona?.name : 'Nenhum'}
              </span>
            </div>
            <button
              onClick={() => {
                onClose();
                onOpenCreation();
              }}
              className="w-full py-2.5 px-4 bg-white hover:bg-[#FFE5EC] text-[#C9184A] font-bold text-xs rounded-xl border border-[#FFCCD5] shadow-xs transition-colors flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Criar Novo / Trocar Personagem</span>
            </button>
          </div>

          {/* Dados Técnicos */}
          <div className="p-4 bg-[#FFF0F3]/40 rounded-2xl border border-[#FFCCD5] space-y-1.5">
            <h4 className="font-bold text-slate-800 flex items-center gap-2 mb-2">
              <Shield className="w-4 h-4 text-[#FF4D6D]" />
              Parâmetros de Execução
            </h4>
            <p className="text-slate-600 flex justify-between">
              <span>AI Provider:</span>
              <strong className="text-slate-800 font-semibold">Google Gemini 3.7 Flash</strong>
            </p>
            <p className="text-slate-600 flex justify-between">
              <span>Gateway:</span>
              <strong className="text-slate-800 font-semibold">conversation_gateway.js</strong>
            </p>
            <p className="text-slate-600 flex justify-between">
              <span>Camadas de Memória:</span>
              <strong className="text-slate-800 font-semibold">4 camadas ativas</strong>
            </p>
          </div>
        </div>

        <div className="mt-6 flex items-center justify-between">
          <button
            onClick={onLogout}
            className="py-2.5 px-4 bg-[#FFF0F3] hover:bg-[#FFE5EC] text-[#C9184A] font-bold text-xs rounded-xl border border-[#FFCCD5] transition-colors flex items-center gap-1.5"
          >
            <LogOut className="w-4 h-4" />
            <span>Sair da Conta</span>
          </button>

          <button
            onClick={onClose}
            className="py-2.5 px-5 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] text-white font-semibold text-xs rounded-xl transition-all shadow-md shadow-[#FF4D6D]/25"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
