import React, { useState } from 'react';
import { Heart, Brain, Sparkles, Shield, ArrowRight } from 'lucide-react';

interface OnboardingViewProps {
  onComplete: () => void;
}

export const OnboardingView: React.FC<OnboardingViewProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);

  const steps = [
    {
      icon: Heart,
      title: 'Companhia que te entende',
      desc: 'Um namorado virtual carinhoso e atento, pronto para conversar, apoiar e compartilhar seu dia a dia.'
    },
    {
      icon: Brain,
      title: 'Memória Contínua em 4 Camadas',
      desc: 'Ele lembra seus gostos (UserMemory), mantém sua história (CharacterMemory) e evolui a intimidade (Relationship).'
    },
    {
      icon: Sparkles,
      title: 'Separação Arquitetural Rígida',
      desc: 'Você pode escolher a Persona (personalidade) e o Avatar (visual) de forma independente para criar seu par ideal.'
    }
  ];

  const current = steps[step];
  const Icon = current.icon;

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4">
      <div className="bg-white/95 backdrop-blur-md rounded-3xl max-w-lg w-full p-8 md:p-10 shadow-2xl shadow-pink-200/40 border border-[#FFCCD5] text-center animate-in fade-in zoom-in duration-300">
        <div className="w-16 h-16 bg-[#FFF0F3] border border-[#FFCCD5] rounded-2xl flex items-center justify-center mx-auto mb-6 text-[#FF4D6D] shadow-sm shadow-[#FF4D6D]/15">
          <Icon className="w-8 h-8" />
        </div>

        <h2 className="text-2xl font-bold text-slate-900 tracking-tight mb-3">
          {current.title}
        </h2>
        <p className="text-sm text-slate-600 leading-relaxed max-w-sm mx-auto mb-8 font-normal">
          {current.desc}
        </p>

        <div className="flex justify-center gap-2 mb-8">
          {steps.map((_, i) => (
            <div
              key={i}
              className={`h-2 rounded-full transition-all duration-300 ${
                i === step ? 'w-8 bg-[#FF4D6D]' : 'w-2 bg-[#FFCCD5]'
              }`}
            />
          ))}
        </div>

        <button
          onClick={handleNext}
          className="w-full py-3.5 px-6 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] active:scale-[0.99] text-white font-semibold rounded-2xl transition-all shadow-md shadow-[#FF4D6D]/25 flex items-center justify-center gap-2"
        >
          <span>{step === steps.length - 1 ? 'Criar Meu Primeiro Personagem' : 'Avançar'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
