import React from 'react';
import { Character, MemorySnapshot } from '../types';
import { Heart, X, Sparkles, BookOpen, MessageSquare } from 'lucide-react';

interface CharacterProfileModalProps {
  character: Character | null;
  memorySnapshot: MemorySnapshot | null;
  onClose: () => void;
}

export const CharacterProfileModal: React.FC<CharacterProfileModalProps> = ({
  character,
  memorySnapshot,
  onClose
}) => {
  if (!character) return null;

  const persona = character.persona;
  const avatar = character.avatar;
  const name = character.nickname || persona?.name || 'Namorado';

  return (
    <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
      <div className="bg-white/95 backdrop-blur-md rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl shadow-pink-200/40 border border-[#FFCCD5] max-h-[90vh] overflow-y-auto">
        <div className="flex justify-end">
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#FFF0F3] text-slate-400 hover:text-[#FF4D6D] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="text-center -mt-4 mb-6">
          <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-3 p-1 bg-gradient-to-tr from-[#FF4D6D] to-[#FF758F] shadow-lg shadow-[#FF4D6D]/25">
            <img
              src={avatar?.image_url}
              alt={name}
              className="w-full h-full object-cover rounded-full"
              referrerPolicy="no-referrer"
            />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">{name}</h2>
          <div className="flex items-center justify-center gap-2 mt-1">
            <span className="text-xs font-bold text-[#C9184A] bg-[#FFF0F3] border border-[#FFCCD5] px-3 py-0.5 rounded-full capitalize">
              {persona?.gender || 'namorado'}
            </span>
            <span className="text-xs text-slate-300">•</span>
            <span className="text-xs font-semibold text-slate-700">
              Vínculo Nível {memorySnapshot?.relationshipLevel || 1}
            </span>
          </div>
        </div>

        <div className="space-y-4 text-xs">
          <div className="p-4 bg-[#FFF0F3]/50 rounded-2xl border border-[#FFCCD5]">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5 mb-1.5">
              <Sparkles className="w-4 h-4 text-[#FF4D6D]" />
              Personalidade
            </h4>
            <p className="text-slate-600 leading-relaxed font-normal">{persona?.personality_summary}</p>
          </div>

          <div className="p-4 bg-[#FFF0F3]/50 rounded-2xl border border-[#FFCCD5]">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5 mb-1.5">
              <MessageSquare className="w-4 h-4 text-[#FF4D6D]" />
              Estilo de Fala & Conversação
            </h4>
            <p className="text-slate-600 leading-relaxed font-normal">{persona?.speech_style}</p>
          </div>

          {persona?.backstory && (
            <div className="p-4 bg-[#FFF0F3]/50 rounded-2xl border border-[#FFCCD5]">
              <h4 className="font-bold text-slate-900 flex items-center gap-1.5 mb-1.5">
                <BookOpen className="w-4 h-4 text-[#FF4D6D]" />
                História de Vida
              </h4>
              <p className="text-slate-600 leading-relaxed font-normal">{persona.backstory}</p>
            </div>
          )}
        </div>

        <div className="mt-6 text-center">
          <button
            onClick={onClose}
            className="w-full py-3 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] active:scale-[0.99] text-white font-semibold text-xs rounded-xl transition-all shadow-md shadow-[#FF4D6D]/25"
          >
            Continuar Conversa
          </button>
        </div>
      </div>
    </div>
  );
};
