import React from 'react';
import { MemorySnapshot, Character } from '../types';
import { Brain, Heart, Database, Layers, X, Sparkles } from 'lucide-react';

interface MemoryInspectorProps {
  character: Character | null;
  memorySnapshot: MemorySnapshot | null;
  onClose: () => void;
}

export const MemoryInspector: React.FC<MemoryInspectorProps> = ({
  character,
  memorySnapshot,
  onClose
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
      <div className="bg-white/95 backdrop-blur-md rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl shadow-pink-200/40 border border-[#FFCCD5] max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#FFCCD5] pb-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#FFF0F3] text-[#FF4D6D] border border-[#FFCCD5] rounded-xl flex items-center justify-center shadow-xs">
              <Brain className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Auditoria do Sistema de Memória</h2>
              <p className="text-xs text-slate-500 font-medium">As 4 camadas ativas montadas no prompt do AI Gateway</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#FFF0F3] text-slate-400 hover:text-[#FF4D6D] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs">
          {/* Camada 1: Relationship */}
          <div className="p-4 bg-[#FFF0F3] rounded-2xl border border-[#FFCCD5]">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-[#800F2F] flex items-center gap-1.5">
                <Heart className="w-4 h-4 text-[#FF4D6D] fill-[#FF4D6D]" />
                1. Relationship (Vínculo Afetivo)
              </span>
              <span className="bg-[#FFE5EC] text-[#C9184A] border border-[#FFCCD5] font-bold px-2.5 py-0.5 rounded-full text-[11px]">
                Nível {memorySnapshot?.relationshipLevel || 1}
              </span>
            </div>
            <p className="text-slate-600 mb-2">
              Grau de intimidade e apelidos autorizados entre você e o personagem.
            </p>
            <div className="bg-white p-2.5 rounded-xl border border-[#FFCCD5]/80 font-mono text-[11px] text-slate-700">
              Marcos: {memorySnapshot?.relationshipMilestones?.join(' • ') || 'Primeira Conexão'}
            </div>
          </div>

          {/* Camada 2: CharacterMemory */}
          <div className="p-4 bg-white rounded-2xl border border-[#FFCCD5]">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-slate-900 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-[#FF4D6D]" />
                2. CharacterMemory (Memórias Fixas da Persona)
              </span>
            </div>
            <p className="text-slate-600 mb-2">
              Fatos perenes sobre a vida do personagem {character?.persona?.name}:
            </p>
            <ul className="space-y-1 bg-[#FFF0F3]/40 p-2.5 rounded-xl border border-[#FFCCD5]/60 text-slate-700">
              <li>• Profissão e hábitos diários: {character?.persona?.backstory || 'Arquiteto / Fotógrafo apaixonado por arte.'}</li>
              <li>• Regras de Conduta: {character?.persona?.behavior_rules || 'Demonstrar afeto sincero e validar sentimentos.'}</li>
              <li>• Estilo de Conversa: {character?.persona?.speech_style}</li>
            </ul>
          </div>

          {/* Camada 3: UserMemory */}
          <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                <Database className="w-4 h-4 text-emerald-600" />
                3. UserMemory (Fatos Aprendidos sobre Você)
              </span>
              <span className="bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-full text-[11px] border border-emerald-200">
                {memorySnapshot?.userMemories?.length || 0} fatos
              </span>
            </div>
            <p className="text-slate-600 mb-2">
              Extraídos automaticamente a partir das suas mensagens e passados ao contexto da IA:
            </p>
            <div className="bg-white p-2.5 rounded-xl border border-emerald-200/80 text-slate-700">
              {memorySnapshot?.userMemories && memorySnapshot.userMemories.length > 0 ? (
                <ul className="space-y-1">
                  {memorySnapshot.userMemories.map((m, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <span className="text-emerald-500 font-bold">✓</span>
                      <span>{m}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-slate-400 italic">Conforme você conversar e contar sobre sua vida ou sentimentos, os fatos serão salvos aqui.</p>
              )}
            </div>
          </div>

          {/* Camada 4: ConversationMemory */}
          <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-amber-900 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-600" />
                4. ConversationMemory (Resumo Histórico)
              </span>
            </div>
            <p className="text-slate-600 mb-2">
              Resumo condensado da conversa para evitar perda de contexto temporal:
            </p>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/80 text-slate-700">
              <p className="italic">{memorySnapshot?.conversationSummary || 'Início da conversa recente.'}</p>
            </div>
          </div>
        </div>

        <div className="mt-6 text-right">
          <button
            onClick={onClose}
            className="py-2.5 px-6 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] text-white font-semibold text-xs rounded-xl transition-all shadow-md shadow-[#FF4D6D]/25"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
