import React from 'react';
import { Heart, Brain, FileText, Settings, Sparkles, User as UserIcon } from 'lucide-react';
import { Character, User } from '../types';

interface HeaderProps {
  user: User | null;
  character: Character | null;
  relationshipLevel: number;
  onOpenProfile: () => void;
  onOpenMemory: () => void;
  onOpenDocs: () => void;
  onOpenSettings: () => void;
  onOpenCreation: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  character,
  relationshipLevel,
  onOpenProfile,
  onOpenMemory,
  onOpenDocs,
  onOpenSettings,
  onOpenCreation
}) => {
  return (
    <header className="h-16 border-b border-[#FFCCD5] bg-white/90 backdrop-blur-md px-4 md:px-6 flex items-center justify-between sticky top-0 z-20 shadow-xs shadow-pink-100/50">
      <div className="flex items-center space-x-3">
        {character?.avatar?.image_url ? (
          <button
            onClick={onOpenProfile}
            className="relative group focus:outline-hidden"
            title="Ver perfil do personagem"
          >
            <div className="w-10 h-10 rounded-full p-0.5 bg-gradient-to-tr from-[#FF4D6D] to-[#FF758F] shadow-sm shadow-[#FF4D6D]/30 group-hover:scale-105 transition-transform">
              <img
                src={character.avatar.image_url}
                alt={character.nickname || character.persona?.name || 'Avatar'}
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
          </button>
        ) : (
          <div className="w-10 h-10 rounded-full bg-[#FFF0F3] border border-[#FFCCD5] flex items-center justify-center text-[#FF4D6D] shadow-2xs">
            <Heart className="w-5 h-5 fill-[#FF4D6D]" />
          </div>
        )}

        <div>
          <div className="flex items-center space-x-2">
            <button
              onClick={onOpenProfile}
              className="text-base font-bold text-slate-900 hover:text-[#FF4D6D] transition-colors text-left"
            >
              {character ? character.nickname || character.persona?.name : 'Namorado Virtual'}
            </button>
            {character && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#FFF0F3] text-[#C9184A] border border-[#FFCCD5]">
                Nível {relationshipLevel}
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 flex items-center gap-1.5 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block shadow-xs shadow-emerald-400"></span>
            Online • AI Gateway Isolado
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-1.5 sm:space-x-2">
        <button
          onClick={onOpenCreation}
          className="px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] text-white shadow-xs shadow-[#FF4D6D]/20 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center gap-1.5"
          title="Criar novo ou alternar personagem"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Trocar Personagem</span>
        </button>

        <button
          onClick={onOpenMemory}
          className="p-2 rounded-xl text-slate-600 hover:text-[#FF4D6D] hover:bg-[#FFF0F3] border border-transparent hover:border-[#FFCCD5] transition-all relative"
          title="Inspecionar Camada de Memória Multicamada"
        >
          <Brain className="w-5 h-5" />
        </button>

        <button
          onClick={onOpenDocs}
          className="p-2 rounded-xl text-slate-600 hover:text-[#FF4D6D] hover:bg-[#FFF0F3] border border-transparent hover:border-[#FFCCD5] transition-all"
          title="Documentação de Arquitetura & Decisões Provisórias"
        >
          <FileText className="w-5 h-5" />
        </button>

        <button
          onClick={onOpenSettings}
          className="p-2 rounded-xl text-slate-600 hover:text-[#FF4D6D] hover:bg-[#FFF0F3] border border-transparent hover:border-[#FFCCD5] transition-all"
          title="Configurações & Usuário"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};
