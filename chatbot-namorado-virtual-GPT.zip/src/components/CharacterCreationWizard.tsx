import React, { useState, useEffect } from 'react';
import { Avatar, Persona, Character } from '../types';
import { Check, Sparkles, User, MessageCircle, ArrowRight, ArrowLeft } from 'lucide-react';

interface CharacterCreationWizardProps {
  token: string;
  onCharacterCreated: (character: Character) => void;
  onCancel?: () => void;
}

export const CharacterCreationWizard: React.FC<CharacterCreationWizardProps> = ({
  token,
  onCharacterCreated,
  onCancel
}) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [avatars, setAvatars] = useState<Avatar[]>([]);
  const [personas, setPersonas] = useState<Persona[]>([]);
  const [selectedAvatarId, setSelectedAvatarId] = useState<string>('');
  const [selectedPersonaId, setSelectedPersonaId] = useState<string>('');
  const [nickname, setNickname] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadOptions() {
      setIsLoading(true);
      try {
        const [resAvatars, resPersonas] = await Promise.all([
          fetch('/api/character/avatars', { headers: { Authorization: `Bearer ${token}` } }),
          fetch('/api/character/personas', { headers: { Authorization: `Bearer ${token}` } })
        ]);
        const avs: Avatar[] = await resAvatars.json();
        const pers: Persona[] = await resPersonas.json();
        setAvatars(avs);
        setPersonas(pers);
        if (avs.length > 0) setSelectedAvatarId(avs[0].id);
        if (pers.length > 0) setSelectedPersonaId(pers[0].id);
      } catch (err) {
        setError('Erro ao carregar avatares e personas.');
      } finally {
        setIsLoading(false);
      }
    }
    loadOptions();
  }, [token]);

  const handleFinish = async () => {
    if (!selectedAvatarId || !selectedPersonaId) {
      setError('Por favor, selecione tanto um avatar quanto uma persona.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      const res = await fetch('/api/character/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          avatarId: selectedAvatarId,
          personaId: selectedPersonaId,
          nickname: nickname.trim() || undefined
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Falha ao criar personagem');
      }

      const created: Character = await res.json();
      onCharacterCreated(created);
    } catch (err: any) {
      setError(err.message || 'Erro ao criar o personagem');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-12">
        <div className="w-8 h-8 border-3 border-[#FF4D6D] border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs text-slate-500 mt-3 font-medium">Carregando catálogo de avatares e personas...</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-4 sm:p-6 bg-white/95 backdrop-blur-md rounded-3xl border border-[#FFCCD5] shadow-xl shadow-pink-200/30 my-4">
      <div className="flex items-center justify-between border-b border-[#FFCCD5] pb-4 mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#FF4D6D]" />
            Criador de Personagem
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 font-medium">
            Passo {step} de 2: {step === 1 ? 'Escolha o Avatar Visual' : 'Defina a Persona & Personalidade'}
          </p>
        </div>
        {onCancel && (
          <button
            onClick={onCancel}
            className="text-xs font-semibold text-slate-600 hover:text-slate-900 px-3.5 py-1.5 rounded-xl border border-[#FFCCD5] bg-white hover:bg-[#FFF0F3] transition-colors"
          >
            Cancelar
          </button>
        )}
      </div>

      {error && (
        <div className="mb-4 p-3 bg-[#FFF0F3] text-[#C9184A] text-xs rounded-xl border border-[#FFCCD5] font-medium">
          {error}
        </div>
      )}

      {step === 1 ? (
        <div>
          <h3 className="text-sm font-bold text-slate-800 mb-3">1. Selecione a aparência visual do avatar:</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
            {avatars.map((av) => {
              const isSelected = av.id === selectedAvatarId;
              return (
                <div
                  key={av.id}
                  onClick={() => setSelectedAvatarId(av.id)}
                  className={`cursor-pointer group relative rounded-2xl overflow-hidden aspect-square border-2 transition-all ${
                    isSelected
                      ? 'border-[#FF4D6D] ring-4 ring-[#FF4D6D]/20 scale-[1.02] shadow-md shadow-[#FF4D6D]/20'
                      : 'border-[#FFCCD5]/80 hover:border-[#FF758F]'
                  }`}
                >
                  <img
                    src={av.image_url}
                    alt="Avatar option"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  {isSelected && (
                    <div className="absolute top-2 right-2 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] text-white rounded-full p-1.5 shadow-md">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="flex justify-end">
            <button
              onClick={() => setStep(2)}
              className="py-2.5 px-6 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] text-white font-semibold text-sm rounded-xl transition-all shadow-md shadow-[#FF4D6D]/25 flex items-center gap-2"
            >
              <span>Avançar para Personalidade</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <div>
          <h3 className="text-sm font-bold text-slate-800 mb-3">2. Selecione a personalidade (Persona) e apelido:</h3>
          
          <div className="mb-5">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Apelido Carinhoso (Opcional)</label>
            <input
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              placeholder="Ex: Davi, Meu Amor, Gatinho..."
              className="w-full px-3.5 py-2.5 bg-[#FFF0F3]/40 border border-[#FFCCD5] rounded-xl text-sm focus:outline-hidden focus:border-[#FF4D6D] focus:ring-2 focus:ring-[#FF4D6D]/20 focus:bg-white transition-all text-slate-800"
            />
          </div>

          <div className="space-y-3 mb-8">
            {personas.map((p) => {
              const isSelected = p.id === selectedPersonaId;
              return (
                <div
                  key={p.id}
                  onClick={() => setSelectedPersonaId(p.id)}
                  className={`cursor-pointer p-4 rounded-2xl border-2 transition-all ${
                    isSelected
                      ? 'border-[#FF4D6D] bg-[#FFF0F3] ring-2 ring-[#FF4D6D]/15 shadow-xs'
                      : 'border-[#FFCCD5]/80 bg-white hover:border-[#FF758F]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <h4 className="text-sm font-bold text-slate-900">{p.name}</h4>
                    <span className="text-[11px] px-2.5 py-0.5 rounded-full font-bold bg-[#FFE5EC] text-[#C9184A] border border-[#FFCCD5] capitalize">
                      {p.gender}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mb-2 leading-relaxed font-normal">{p.personality_summary}</p>
                  <div className="text-[11px] text-slate-500 italic flex items-center gap-1.5">
                    <MessageCircle className="w-3.5 h-3.5 text-[#FF4D6D]" />
                    <span>Estilo de fala: {p.speech_style}</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between">
            <button
              onClick={() => setStep(1)}
              className="py-2.5 px-4 bg-white hover:bg-[#FFF0F3] text-slate-700 font-semibold text-sm rounded-xl border border-[#FFCCD5] transition-all flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar ao Avatar</span>
            </button>

            <button
              onClick={handleFinish}
              disabled={isSubmitting}
              className="py-2.5 px-6 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] active:scale-[0.99] text-white font-semibold text-sm rounded-xl transition-all shadow-md shadow-[#FF4D6D]/25 disabled:opacity-50 flex items-center gap-2"
            >
              {isSubmitting ? (
                <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Criar Namorado Virtual</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
