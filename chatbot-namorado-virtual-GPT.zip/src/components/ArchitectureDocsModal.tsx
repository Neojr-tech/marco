import React from 'react';
import { FileText, X, CheckCircle2, ShieldCheck, Layers, Cpu, Database } from 'lucide-react';

interface ArchitectureDocsModalProps {
  onClose: () => void;
}

export const ArchitectureDocsModal: React.FC<ArchitectureDocsModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
      <div className="bg-white/95 backdrop-blur-md rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl shadow-pink-200/40 border border-[#FFCCD5] max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#FFCCD5] pb-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#FFF0F3] text-[#FF4D6D] border border-[#FFCCD5] rounded-xl flex items-center justify-center shadow-xs">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Documentação Arquitetural & Decisões</h2>
              <p className="text-xs text-slate-500 font-medium">Conformidade com a especificação técnica do projeto</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#FFF0F3] text-slate-400 hover:text-[#FF4D6D] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-6 text-xs text-slate-700">
          {/* Princípios Arquiteturais */}
          <section className="bg-[#FFF0F3]/40 p-4 rounded-2xl border border-[#FFCCD5] space-y-2">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#FF4D6D]" />
              1. Separação Estrita Persona / Avatar / Character
            </h3>
            <p className="text-slate-600 leading-relaxed font-normal">
              • <strong>Persona</strong>: Módulo puro de personalidade, gênero, regras de fala e memórias fixas.<br />
              • <strong>Avatar</strong>: Módulo visual (imagens, referências futuras de voz e vídeo).<br />
              • <strong>Character</strong>: Vínculo único entre Usuário + Persona + Avatar + Nível de Relacionamento.
            </p>
          </section>

          {/* AI Gateway */}
          <section className="bg-[#FFF0F3]/40 p-4 rounded-2xl border border-[#FFCCD5] space-y-2">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#FF4D6D]" />
              2. Padrão AI Gateway Isolado
            </h3>
            <p className="text-slate-600 leading-relaxed font-normal">
              Nenhum componente do frontend ou regra de negócio chama SDKs diretamente. Todas as interações passam por <code>backend/src/services/ai-gateway/conversation/conversation_gateway.js</code>.
            </p>
            <div className="p-2.5 bg-white rounded-xl border border-[#FFCCD5] font-mono text-[11px] text-slate-700">
              Provedor Provisório Ativo: Google Gemini 3.7 Flash (@google/genai)
            </div>
          </section>

          {/* 12 Entidades do Banco de Dados */}
          <section className="bg-[#FFF0F3]/40 p-4 rounded-2xl border border-[#FFCCD5] space-y-2">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Database className="w-4 h-4 text-[#FF4D6D]" />
              3. As 12 Entidades Implementadas (docs/database-schema.md)
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 font-mono text-[11px]">
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">1. users</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">2. avatars</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">3. personas</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">4. characters</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">5. conversations</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">6. participants</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">7. messages</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">8. conversation_memories</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">9. character_memories</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">10. user_memories</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">11. relationships</span>
              <span className="p-1.5 bg-white rounded-lg border border-[#FFCCD5] text-slate-700">12. subscriptions</span>
            </div>
          </section>

          {/* Registro de Decisões Provisórias */}
          <section className="bg-[#FFF0F3] p-4 rounded-2xl border border-[#FFCCD5] space-y-2">
            <h3 className="font-bold text-[#800F2F] text-sm flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#FF4D6D]" />
              4. Registro de Itens "A DEFINIR" & Decisões Provisórias
            </h3>
            <ul className="space-y-1.5 text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#FF4D6D] shrink-0 mt-0.5" />
                <span><strong>LLM Principal</strong>: Provedor definitivo A DEFINIR. Ativo provisoriamente: Gemini 3.7 Flash via conversation_gateway.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#FF4D6D] shrink-0 mt-0.5" />
                <span><strong>Gateways Multimídia</strong>: Voice, Video, Image e Vision com interfaces estruturadas e preparadas para acoplamento de provedores.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#FF4D6D] shrink-0 mt-0.5" />
                <span><strong>Monetização & Assinaturas</strong>: Modelos de tabela e rotas prontos; regras comerciais definitivas A DEFINIR.</span>
              </li>
            </ul>
          </section>
        </div>

        <div className="mt-6 text-right">
          <button
            onClick={onClose}
            className="py-2.5 px-6 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] text-white font-semibold text-xs rounded-xl transition-all shadow-md shadow-[#FF4D6D]/25"
          >
            Fechar Documentação
          </button>
        </div>
      </div>
    </div>
  );
};
