import React, { useState, useRef, useEffect } from 'react';
import { Character, Message, MemorySnapshot } from '../types';
import { Send, Heart, Brain, Sparkles, AlertCircle } from 'lucide-react';

interface ChatAreaProps {
  character: Character;
  messages: Message[];
  memorySnapshot: MemorySnapshot | null;
  onSendMessage: (text: string) => Promise<void>;
  isSending: boolean;
}

export const ChatArea: React.FC<ChatAreaProps> = ({
  character,
  messages,
  memorySnapshot,
  onSendMessage,
  isSending
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isSending]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isSending) return;
    const msg = inputText;
    setInputText('');
    await onSendMessage(msg);
  };

  const characterName = character.nickname || character.persona?.name || 'Namorado';
  const avatarUrl = character.avatar?.image_url;

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-4rem)] max-w-4xl w-full mx-auto bg-[#FFF0F3]/30 border-x border-[#FFCCD5]">
      {/* Informações de status da conversa e do relacionamento */}
      <div className="bg-white/90 backdrop-blur-md px-4 py-2.5 border-b border-[#FFCCD5] flex items-center justify-between text-xs text-slate-600 shadow-2xs">
        <div className="flex items-center gap-2">
          <Heart className="w-3.5 h-3.5 text-[#FF4D6D] fill-[#FF4D6D]" />
          <span>Vínculo: <strong className="text-[#C9184A]">Nível {memorySnapshot?.relationshipLevel || 1}</strong></span>
          <span className="text-[#FFCCD5]">•</span>
          <span className="font-medium text-slate-700">{memorySnapshot?.relationshipMilestones?.[0] || 'Conexão Estabelecida'}</span>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] text-[#C9184A] bg-[#FFF0F3] border border-[#FFCCD5] px-2.5 py-0.5 rounded-full font-bold shadow-2xs">
          <Brain className="w-3.5 h-3.5 text-[#FF4D6D]" />
          <span>{memorySnapshot?.userMemoriesCount || 0} memórias ativas</span>
        </div>
      </div>

      {/* Lista de Mensagens */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 max-w-md mx-auto">
            <div className="w-20 h-20 rounded-full overflow-hidden mb-4 p-1 bg-gradient-to-tr from-[#FF4D6D] to-[#FF758F] shadow-lg shadow-[#FF4D6D]/20 animate-in zoom-in duration-300">
              <img
                src={avatarUrl}
                alt={characterName}
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />
            </div>
            <h3 className="text-xl font-bold text-slate-900">
              Diga um "Oi" para o {characterName}!
            </h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Ele tem uma personalidade própria ({character.persona?.personality_summary}), lembra do que você conta e responderá afetuosamente através do AI Gateway.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {['Oi amor, como você está?', 'O que você gosta de fazer?', 'Tive um dia cansativo hoje...'].map((sug, idx) => (
                <button
                  key={idx}
                  onClick={() => onSendMessage(sug)}
                  className="text-xs bg-white hover:bg-[#FFF0F3] text-slate-700 hover:text-[#C9184A] font-semibold px-4 py-2 rounded-full border border-[#FFCCD5] shadow-xs hover:border-[#FF758F] transition-all hover:scale-105"
                >
                  "{sug}"
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.sender_type === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 items-end ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-full overflow-hidden shrink-0 border-2 border-[#FFCCD5] shadow-2xs">
                    <img
                      src={avatarUrl}
                      alt={characterName}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}
                <div
                  className={`max-w-[80%] sm:max-w-[70%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-xs ${
                    isUser
                      ? 'bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] text-white rounded-br-xs shadow-[#FF4D6D]/20 font-normal'
                      : 'bg-white text-slate-800 border border-[#FFCCD5] rounded-bl-xs shadow-pink-100/50'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                  <span
                    className={`block text-[10px] mt-1 text-right font-medium ${
                      isUser ? 'text-pink-100' : 'text-slate-400'
                    }`}
                  >
                    {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            );
          })
        )}

        {isSending && (
          <div className="flex gap-3 items-end justify-start">
            <div className="w-8 h-8 rounded-full overflow-hidden shrink-0 border-2 border-[#FFCCD5] shadow-2xs">
              <img
                src={avatarUrl}
                alt={characterName}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="bg-white border border-[#FFCCD5] rounded-2xl rounded-bl-xs px-4 py-3 shadow-xs shadow-pink-100/50 flex items-center gap-2">
              <span className="text-xs text-slate-600 font-medium">{characterName} está pensando com carinho</span>
              <div className="flex gap-1 items-center">
                <span className="w-1.5 h-1.5 bg-[#FF4D6D] rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-[#FF4D6D] rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1.5 h-1.5 bg-[#FF4D6D] rounded-full animate-bounce [animation-delay:0.4s]"></span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Caixa de Entrada de Mensagem */}
      <div className="p-3 sm:p-4 bg-white/90 backdrop-blur-md border-t border-[#FFCCD5]">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={`Conversar com ${characterName}...`}
            className="flex-1 px-4 py-3 bg-[#FFF0F3]/40 border border-[#FFCCD5] rounded-2xl text-sm focus:outline-hidden focus:border-[#FF4D6D] focus:bg-white focus:ring-2 focus:ring-[#FF4D6D]/20 transition-all text-slate-800 placeholder-slate-400"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isSending}
            className="p-3 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] active:scale-95 disabled:opacity-50 text-white rounded-2xl transition-all shadow-md shadow-[#FF4D6D]/30 shrink-0 flex items-center justify-center"
            title="Enviar mensagem"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};
