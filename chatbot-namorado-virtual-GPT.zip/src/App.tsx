import React, { useState, useEffect } from 'react';
import { Sparkles } from 'lucide-react';
import { User, Character, Message, Conversation, MemorySnapshot } from './types';
import { Header } from './components/Header';
import { AuthModal } from './components/AuthModal';
import { OnboardingView } from './components/OnboardingView';
import { CharacterCreationWizard } from './components/CharacterCreationWizard';
import { ChatArea } from './components/ChatArea';
import { MemoryInspector } from './components/MemoryInspector';
import { CharacterProfileModal } from './components/CharacterProfileModal';
import { ArchitectureDocsModal } from './components/ArchitectureDocsModal';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem('namorado_token'));
  const [user, setUser] = useState<User | null>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [activeCharacter, setActiveCharacter] = useState<Character | null>(null);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [memorySnapshot, setMemorySnapshot] = useState<MemorySnapshot | null>(null);
  const [isSending, setIsSending] = useState(false);

  // Modais e Visões
  const [showCreation, setShowCreation] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showMemory, setShowMemory] = useState(false);
  const [showDocs, setShowDocs] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Carregar dados iniciais ao montar ou autenticar
  useEffect(() => {
    async function checkAuth() {
      if (!token) return;
      try {
        const res = await fetch('/api/user/profile', {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          const userData = await res.json();
          setUser(userData);
          loadCharactersAndChat(token);
        } else {
          handleLogout();
        }
      } catch {
        handleLogout();
      }
    }
    checkAuth();
  }, [token]);

  const loadCharactersAndChat = async (authToken: string) => {
    try {
      const res = await fetch('/api/character/list', {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      if (res.ok) {
        const characters: Character[] = await res.json();
        if (characters.length > 0) {
          const firstChar = characters[0];
          setActiveCharacter(firstChar);
          await startOrLoadConversation(authToken, firstChar.id);
        } else {
          setShowCreation(true);
        }
      }
    } catch (err) {
      console.error('Erro ao carregar personagens:', err);
    }
  };

  const startOrLoadConversation = async (authToken: string, characterId: string) => {
    try {
      const convRes = await fetch('/api/chat/conversations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`
        },
        body: JSON.stringify({ characterId })
      });
      const conv: Conversation = await convRes.json();
      setActiveConversation(conv);

      const msgsRes = await fetch(`/api/chat/conversations/${conv.id}/messages`, {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      const data = await msgsRes.json();
      setMessages(data.messages || []);
      setMemorySnapshot(data.memorySnapshot || null);
    } catch (err) {
      console.error('Erro ao iniciar conversa:', err);
    }
  };

  const handleLogin = async (email: string, pass: string): Promise<boolean> => {
    setIsLoadingAuth(true);
    setAuthError(null);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pass })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro no login');

      localStorage.setItem('namorado_token', data.token);
      setToken(data.token);
      setUser(data.user);
      loadCharactersAndChat(data.token);
      return true;
    } catch (err: any) {
      setAuthError(err.message);
      return false;
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const handleRegister = async (email: string, pass: string, name: string): Promise<boolean> => {
    setIsLoadingAuth(true);
    setAuthError(null);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: pass, displayName: name })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro no cadastro');

      localStorage.setItem('namorado_token', data.token);
      setToken(data.token);
      setUser(data.user);
      setShowCreation(true);
      return true;
    } catch (err: any) {
      setAuthError(err.message);
      return false;
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('namorado_token');
    setToken(null);
    setUser(null);
    setActiveCharacter(null);
    setActiveConversation(null);
    setMessages([]);
  };

  const handleSendMessage = async (content: string) => {
    if (!token || !activeConversation || !content.trim()) return;

    setIsSending(true);
    const tempUserMsg: Message = {
      id: `temp-${Date.now()}`,
      conversation_id: activeConversation.id,
      sender_type: 'user',
      sender_id: user?.id || 'me',
      content,
      content_type: 'text',
      created_at: new Date().toISOString()
    };

    setMessages((prev) => [...prev, tempUserMsg]);

    try {
      const res = await fetch('/api/chat/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          conversationId: activeConversation.id,
          content
        })
      });

      if (!res.ok) {
        throw new Error('Falha ao enviar mensagem');
      }

      const data = await res.json();
      setMessages((prev) => [
        ...prev.filter((m) => m.id !== tempUserMsg.id),
        data.userMessage,
        data.characterMessage
      ]);
      setMemorySnapshot(data.memorySnapshot || null);
    } catch (err) {
      console.error('Erro ao enviar mensagem:', err);
    } finally {
      setIsSending(false);
    }
  };

  const handleCharacterCreated = (char: Character) => {
    setActiveCharacter(char);
    setShowCreation(false);
    if (token) {
      startOrLoadConversation(token, char.id);
    }
  };

  // Se não estiver logado
  if (!token || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FFF0F3] via-[#FFE5EC] to-[#FFCCD5] flex items-center justify-center p-4">
        <AuthModal
          onLogin={handleLogin}
          onRegister={handleRegister}
          isLoading={isLoadingAuth}
          errorMessage={authError}
        />
      </div>
    );
  }

  // Onboarding
  if (!user.onboardingCompleted && !showCreation) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FFF0F3] via-[#FFE5EC] to-[#FFCCD5] flex items-center justify-center p-4">
        <OnboardingView
          onComplete={async () => {
            if (token) {
              await fetch('/api/user/onboarding', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({ seenIntro: true })
              });
              setUser({ ...user, onboardingCompleted: true });
              setShowCreation(true);
            }
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF0F3] flex flex-col antialiased text-slate-900 selection:bg-[#FF4D6D] selection:text-white">
      <Header
        user={user}
        character={activeCharacter}
        relationshipLevel={memorySnapshot?.relationshipLevel || 1}
        onOpenProfile={() => setShowProfile(true)}
        onOpenMemory={() => setShowMemory(true)}
        onOpenDocs={() => setShowDocs(true)}
        onOpenSettings={() => setShowSettings(true)}
        onOpenCreation={() => setShowCreation(true)}
      />

      <main className="flex-1 flex flex-col relative overflow-hidden">
        {showCreation ? (
          <div className="flex-1 p-4 overflow-y-auto">
            <CharacterCreationWizard
              token={token}
              onCharacterCreated={handleCharacterCreated}
              onCancel={activeCharacter ? () => setShowCreation(false) : undefined}
            />
          </div>
        ) : activeCharacter ? (
          <ChatArea
            character={activeCharacter}
            messages={messages}
            memorySnapshot={memorySnapshot}
            onSendMessage={handleSendMessage}
            isSending={isSending}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center p-6">
            <div className="text-center max-w-md bg-white/90 backdrop-blur-md p-8 rounded-3xl border border-[#FFCCD5] shadow-xl shadow-pink-200/40">
              <div className="w-16 h-16 bg-[#FFF0F3] text-[#FF4D6D] rounded-2xl flex items-center justify-center mx-auto mb-4 border border-[#FFCCD5]">
                <Sparkles className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 mb-2">Bem-vindo(a)!</h2>
              <p className="text-sm text-slate-600 mb-6">Crie seu primeiro namorado virtual escolhendo um avatar visual e uma personalidade exclusiva.</p>
              <button
                onClick={() => setShowCreation(true)}
                className="py-3 px-6 bg-gradient-to-r from-[#FF4D6D] to-[#FF758F] hover:from-[#E03155] hover:to-[#FF4D6D] text-white font-semibold rounded-2xl shadow-md shadow-[#FF4D6D]/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                Criar Primeiro Namorado Virtual
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Modais do Sistema */}
      {showMemory && (
        <MemoryInspector
          character={activeCharacter}
          memorySnapshot={memorySnapshot}
          onClose={() => setShowMemory(false)}
        />
      )}

      {showProfile && (
        <CharacterProfileModal
          character={activeCharacter}
          memorySnapshot={memorySnapshot}
          onClose={() => setShowProfile(false)}
        />
      )}

      {showDocs && (
        <ArchitectureDocsModal onClose={() => setShowDocs(false)} />
      )}

      {showSettings && (
        <SettingsModal
          user={user}
          character={activeCharacter}
          onLogout={handleLogout}
          onOpenCreation={() => setShowCreation(true)}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  );
}
