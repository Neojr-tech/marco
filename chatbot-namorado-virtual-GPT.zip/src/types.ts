export interface User {
  id: string;
  email: string;
  displayName: string;
  birthDate?: string;
  onboardingCompleted: boolean;
}

export interface Avatar {
  id: string;
  owner_type: 'system' | 'user';
  owner_id?: string;
  image_url: string;
  voice_ref?: string;
  video_ref?: string;
}

export interface Persona {
  id: string;
  owner_type: 'system' | 'user';
  owner_id?: string;
  name: string;
  gender: string;
  personality_summary: string;
  speech_style: string;
  backstory?: string;
  behavior_rules?: string;
  default_avatar_id?: string;
}

export interface Character {
  id: string;
  user_id: string;
  persona_id: string;
  avatar_id: string;
  nickname?: string;
  persona?: Persona;
  avatar?: Avatar;
  createdAt?: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_type: 'user' | 'character';
  sender_id: string;
  content: string;
  content_type: 'text' | 'image' | 'audio' | 'video';
  created_at: string;
}

export interface Conversation {
  id: string;
  user_id: string;
  type: 'individual' | 'group';
  title: string;
  created_at: string;
  last_message_at: string;
  status: string;
  character?: Character;
  lastMessage?: Message;
}

export interface MemorySnapshot {
  conversationSummary: string;
  userMemoriesCount: number;
  userMemories: string[];
  relationshipLevel: number;
  relationshipMilestones: string[];
}
