import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'state/auth_state.dart';
import 'state/character_state.dart';
import 'state/chat_state.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/onboarding/onboarding_screen.dart';
import 'screens/character_creation/character_creation_screen.dart';
import 'screens/chat/individual_chat_screen.dart';
import 'screens/character_profile/character_profile_screen.dart';
import 'screens/settings/settings_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NamoradoVirtualApp());
}

class NamoradoVirtualApp extends StatelessWidget {
  const NamoradoVirtualApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthState()..init()),
        ChangeNotifierProvider(create: (_) => CharacterState()),
        ChangeNotifierProvider(create: (_) => ChatState()),
      ],
      child: MaterialApp(
        title: 'Namorado Virtual',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFFE11D48),
            primary: const Color(0xFFE11D48),
          ),
          scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        ),
        home: const AppRootRouter(),
      ),
    );
  }
}

class AppRootRouter extends StatefulWidget {
  const AppRootRouter({super.key});

  @override
  State<AppRootRouter> createState() => _AppRootRouterState();
}

class _AppRootRouterState extends State<AppRootRouter> {
  bool _isRegistering = false;
  String _currentView = 'chat'; // 'chat', 'profile', 'settings', 'creation'

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthState>();

    if (auth.isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(color: Color(0xFFE11D48)),
        ),
      );
    }

    // 1. Não autenticado
    if (!auth.isAuthenticated) {
      if (_isRegistering) {
        return RegisterScreen(onNavigateToLogin: () => setState(() => _isRegistering = false));
      }
      return LoginScreen(onNavigateToRegister: () => setState(() => _isRegistering = true));
    }

    final user = auth.user!;

    // 2. Onboarding
    if (!user.isOnboardingCompleted) {
      return OnboardingScreen(
        onFinishOnboarding: () {
          setState(() => _currentView = 'creation');
        },
      );
    }

    // 3. Telas autenticadas
    switch (_currentView) {
      case 'profile':
        return CharacterProfileScreen(onBack: () => setState(() => _currentView = 'chat'));
      case 'settings':
        return SettingsScreen(
          onBack: () => setState(() => _currentView = 'chat'),
          onSwitchCharacter: () => setState(() => _currentView = 'creation'),
        );
      case 'creation':
        return CharacterCreationScreen(onCharacterCreated: () => setState(() => _currentView = 'chat'));
      case 'chat':
      default:
        return IndividualChatScreen(
          onOpenProfile: () => setState(() => _currentView = 'profile'),
          onOpenSettings: () => setState(() => _currentView = 'settings'),
        );
    }
  }
}
