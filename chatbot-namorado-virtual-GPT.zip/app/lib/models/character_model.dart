import 'avatar_model.dart';

class PersonaModel {
  final String id;
  final String ownerType;
  final String name;
  final String gender;
  final String personalitySummary;
  final String speechStyle;
  final String backstory;
  final String behaviorRules;
  final String? defaultAvatarId;

  PersonaModel({
    required this.id,
    this.ownerType = 'system',
    required this.name,
    required this.gender,
    required this.personalitySummary,
    required this.speechStyle,
    this.backstory = '',
    this.behaviorRules = '',
    this.defaultAvatarId,
  });

  factory PersonaModel.fromJson(Map<String, dynamic> json) {
    return PersonaModel(
      id: json['id'] ?? '',
      ownerType: json['owner_type'] ?? json['ownerType'] ?? 'system',
      name: json['name'] ?? '',
      gender: json['gender'] ?? 'não-especificado',
      personalitySummary: json['personality_summary'] ?? json['personalitySummary'] ?? '',
      speechStyle: json['speech_style'] ?? json['speechStyle'] ?? '',
      backstory: json['backstory'] ?? '',
      behaviorRules: json['behavior_rules'] ?? json['behaviorRules'] ?? '',
      defaultAvatarId: json['default_avatar_id'] ?? json['defaultAvatarId'],
    );
  }
}

class CharacterModel {
  final String id;
  final String userId;
  final String personaId;
  final String avatarId;
  final String? nickname;
  final PersonaModel? persona;
  final AvatarModel? avatar;
  final String? createdAt;

  CharacterModel({
    required this.id,
    required this.userId,
    required this.personaId,
    required this.avatarId,
    this.nickname,
    this.persona,
    this.avatar,
    this.createdAt,
  });

  String get displayName => nickname ?? persona?.name ?? 'Personagem';

  factory CharacterModel.fromJson(Map<String, dynamic> json) {
    return CharacterModel(
      id: json['id'] ?? '',
      userId: json['user_id'] ?? json['userId'] ?? '',
      personaId: json['persona_id'] ?? json['personaId'] ?? '',
      avatarId: json['avatar_id'] ?? json['avatarId'] ?? '',
      nickname: json['nickname'],
      persona: json['persona'] != null ? PersonaModel.fromJson(json['persona']) : null,
      avatar: json['avatar'] != null ? AvatarModel.fromJson(json['avatar']) : null,
      createdAt: json['created_at'] ?? json['createdAt'],
    );
  }
}
