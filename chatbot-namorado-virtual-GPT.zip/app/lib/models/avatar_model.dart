class AvatarModel {
  final String id;
  final String ownerType;
  final String? ownerId;
  final String imageUrl;
  final String? voiceRef;
  final String? videoRef;

  AvatarModel({
    required this.id,
    this.ownerType = 'system',
    this.ownerId,
    required this.imageUrl,
    this.voiceRef,
    this.videoRef,
  });

  factory AvatarModel.fromJson(Map<String, dynamic> json) {
    return AvatarModel(
      id: json['id'] ?? '',
      ownerType: json['owner_type'] ?? json['ownerType'] ?? 'system',
      ownerId: json['owner_id'] ?? json['ownerId'],
      imageUrl: json['image_url'] ?? json['imageUrl'] ?? '',
      voiceRef: json['voice_ref'] ?? json['voiceRef'],
      videoRef: json['video_ref'] ?? json['videoRef'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'ownerType': ownerType,
      'ownerId': ownerId,
      'imageUrl': imageUrl,
      'voiceRef': voiceRef,
      'videoRef': videoRef,
    };
  }
}
