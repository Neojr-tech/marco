class MessageModel {
  final String id;
  final String conversationId;
  final String senderType; // 'user' | 'character'
  final String senderId;
  final String content;
  final String contentType; // 'text' | 'image' | 'audio' | 'video'
  final String? mediaUrl;
  final String createdAt;
  final String? replyToMessageId;

  MessageModel({
    required this.id,
    required this.conversationId,
    required this.senderType,
    required this.senderId,
    required this.content,
    this.contentType = 'text',
    this.mediaUrl,
    required this.createdAt,
    this.replyToMessageId,
  });

  bool get isUser => senderType == 'user';

  factory MessageModel.fromJson(Map<String, dynamic> json) {
    return MessageModel(
      id: json['id'] ?? '',
      conversationId: json['conversation_id'] ?? json['conversationId'] ?? '',
      senderType: json['sender_type'] ?? json['senderType'] ?? 'user',
      senderId: json['sender_id'] ?? json['senderId'] ?? '',
      content: json['content'] ?? '',
      contentType: json['content_type'] ?? json['contentType'] ?? 'text',
      mediaUrl: json['media_url'] ?? json['mediaUrl'],
      createdAt: json['created_at'] ?? json['createdAt'] ?? DateTime.now().toIso8601String(),
      replyToMessageId: json['reply_to_message_id'] ?? json['replyToMessageId'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'conversationId': conversationId,
      'senderType': senderType,
      'senderId': senderId,
      'content': content,
      'contentType': contentType,
      'mediaUrl': mediaUrl,
      'createdAt': createdAt,
      'replyToMessageId': replyToMessageId,
    };
  }
}
