class UserModel {
  final String id;
  final String email;
  final String displayName;
  final String? birthDate;
  final String authProvider;
  final String status;
  final String? onboardingCompletedAt;

  UserModel({
    required this.id,
    required this.email,
    required this.displayName,
    this.birthDate,
    this.authProvider = 'email',
    this.status = 'active',
    this.onboardingCompletedAt,
  });

  bool get isOnboardingCompleted => onboardingCompletedAt != null;

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? '',
      email: json['email'] ?? '',
      displayName: json['displayName'] ?? json['display_name'] ?? '',
      birthDate: json['birthDate'] ?? json['birth_date'],
      authProvider: json['authProvider'] ?? json['auth_provider'] ?? 'email',
      status: json['status'] ?? 'active',
      onboardingCompletedAt: json['onboardingCompletedAt'] ?? json['onboarding_completed_at'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'displayName': displayName,
      'birthDate': birthDate,
      'authProvider': authProvider,
      'status': status,
      'onboardingCompletedAt': onboardingCompletedAt,
    };
  }
}
