import 'character_model.dart';
import 'message_model.dart';

class ConversationModel {
  final String id;
  final String userId;
  final String type; // 'individual' | 'group'
  final String title;
  final String createdAt;
  final String lastMessageAt;
  final String status;
  final CharacterModel? character;
  final MessageModel? lastMessage;

  ConversationModel({
    required this.id,
    required this.userId,
    this.type = 'individual',
    required this.title,
    required this.createdAt,
    required this.lastMessageAt,
    this.status = 'active',
    this.character,
    this.lastMessage,
  });

  factory ConversationModel.fromJson(Map<String, dynamic> json) {
    return ConversationModel(
      id: json['id'] ?? '',
      userId: json['user_id'] ?? json['userId'] ?? '',
      type: json['type'] ?? 'individual',
      title: json['title'] ?? 'Conversa',
      createdAt: json['created_at'] ?? json['createdAt'] ?? '',
      lastMessageAt: json['last_message_at'] ?? json['lastMessageAt'] ?? '',
      status: json['status'] ?? 'active',
      character: json['character'] != null ? CharacterModel.fromJson(json['character']) : null,
      lastMessage: json['lastMessage'] != null ? MessageModel.fromJson(json['lastMessage']) : null,
    );
  }
}
