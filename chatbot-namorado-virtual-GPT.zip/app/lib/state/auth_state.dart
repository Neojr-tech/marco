import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import '../services/api/auth_api.dart';
import '../services/api/user_api.dart';
import '../services/local/session_storage.dart';

class AuthState extends ChangeNotifier {
  final AuthApi _authApi = AuthApi();
  final UserApi _userApi = UserApi();
  final SessionStorage _sessionStorage = SessionStorage();

  UserModel? _user;
  String? _token;
  bool _isLoading = false;
  String? _errorMessage;

  UserModel? get user => _user;
  String? get token => _token;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _token != null && _user != null;

  Future<void> init() async {
    _isLoading = true;
    notifyListeners();

    try {
      _token = await _sessionStorage.getToken();
      _user = await _sessionStorage.getUser();

      if (_token != null) {
        // Atualizar perfil em background
        final profile = await _userApi.getProfile(_token!);
        _user = profile;
        await _sessionStorage.saveSession(token: _token!, user: _user!);
      }
    } catch (e) {
      _token = null;
      _user = null;
      await _sessionStorage.clearSession();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final res = await _authApi.login(email: email, password: password);
      _token = res['token'];
      _user = UserModel.fromJson(res['user']);
      await _sessionStorage.saveSession(token: _token!, user: _user!);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> register(String email, String password, String displayName, {String? birthDate}) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final res = await _authApi.register(
        email: email,
        password: password,
        displayName: displayName,
        birthDate: birthDate,
      );
      _token = res['token'];
      _user = UserModel.fromJson(res['user']);
      await _sessionStorage.saveSession(token: _token!, user: _user!);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> completeOnboarding(Map<String, dynamic> preferences) async {
    if (_token == null) return;
    try {
      await _userApi.completeOnboarding(_token!, preferences);
      if (_user != null) {
        _user = UserModel(
          id: _user!.id,
          email: _user!.email,
          displayName: _user!.displayName,
          birthDate: _user!.birthDate,
          authProvider: _user!.authProvider,
          status: _user!.status,
          onboardingCompletedAt: DateTime.now().toIso8601String(),
        );
        await _sessionStorage.saveSession(token: _token!, user: _user!);
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Erro ao completar onboarding: $e');
    }
  }

  Future<void> logout() async {
    _token = null;
    _user = null;
    await _sessionStorage.clearSession();
    notifyListeners();
  }
}
