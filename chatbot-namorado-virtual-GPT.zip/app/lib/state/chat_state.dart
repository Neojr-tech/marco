import 'package:flutter/foundation.dart';
import '../models/conversation_model.dart';
import '../models/message_model.dart';
import '../services/api/chat_api.dart';

class ChatState extends ChangeNotifier {
  final ChatApi _chatApi = ChatApi();

  List<ConversationModel> _conversations = [];
  ConversationModel? _activeConversation;
  List<MessageModel> _messages = [];
  Map<String, dynamic> _memorySnapshot = {};
  bool _isLoading = false;
  bool _isSending = false;
  String? _errorMessage;

  List<ConversationModel> get conversations => _conversations;
  ConversationModel? get activeConversation => _activeConversation;
  List<MessageModel> get messages => _messages;
  Map<String, dynamic> get memorySnapshot => _memorySnapshot;
  bool get isLoading => _isLoading;
  bool get isSending => _isSending;
  String? get errorMessage => _errorMessage;

  Future<void> loadConversations(String token) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _conversations = await _chatApi.getConversations(token);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> openConversation(String token, String conversationId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final res = await _chatApi.getConversationMessages(token, conversationId);
      _activeConversation = res['conversation'] as ConversationModel;
      _messages = res['messages'] as List<MessageModel>;
      _memorySnapshot = res['memorySnapshot'] as Map<String, dynamic>;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<ConversationModel?> startConversation(String token, String characterId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final conv = await _chatApi.startConversation(token, characterId);
      _activeConversation = conv;
      await openConversation(token, conv.id);
      return conv;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
      return null;
    }
  }

  Future<bool> sendMessage(String token, String content) async {
    if (_activeConversation == null || content.trim().isEmpty) return false;

    _isSending = true;
    _errorMessage = null;

    // Adicionar mensagem provisória na UI para feedback instantâneo
    final tempMsg = MessageModel(
      id: 'temp-${DateTime.now().millisecondsSinceEpoch}',
      conversationId: _activeConversation!.id,
      senderType: 'user',
      senderId: 'current-user',
      content: content,
      createdAt: DateTime.now().toIso8601String(),
    );
    _messages.add(tempMsg);
    notifyListeners();

    try {
      final res = await _chatApi.sendMessage(
        token: token,
        conversationId: _activeConversation!.id,
        content: content,
      );

      // Substituir mensagem temporária pela confirmada e adicionar resposta
      _messages.removeWhere((m) => m.id == tempMsg.id);
      _messages.add(res['userMessage'] as MessageModel);
      _messages.add(res['characterMessage'] as MessageModel);
      _memorySnapshot = res['memorySnapshot'] as Map<String, dynamic>;

      _isSending = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      _isSending = false;
      notifyListeners();
      return false;
    }
  }
}
