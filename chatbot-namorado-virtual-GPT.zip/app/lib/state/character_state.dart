import 'package:flutter/foundation.dart';
import '../models/avatar_model.dart';
import '../models/character_model.dart';
import '../services/api/character_api.dart';

class CharacterState extends ChangeNotifier {
  final CharacterApi _characterApi = CharacterApi();

  List<AvatarModel> _avatars = [];
  List<PersonaModel> _personas = [];
  List<CharacterModel> _myCharacters = [];
  CharacterModel? _selectedCharacter;
  bool _isLoading = false;
  String? _errorMessage;

  List<AvatarModel> get avatars => _avatars;
  List<PersonaModel> get personas => _personas;
  List<CharacterModel> get myCharacters => _myCharacters;
  CharacterModel? get selectedCharacter => _selectedCharacter;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  void selectCharacter(CharacterModel character) {
    _selectedCharacter = character;
    notifyListeners();
  }

  Future<void> loadCreationData(String token) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final avatarsFuture = _characterApi.getAvatars(token);
      final personasFuture = _characterApi.getPersonas(token);
      final results = await Future.wait([avatarsFuture, personasFuture]);

      _avatars = results[0] as List<AvatarModel>;
      _personas = results[1] as List<PersonaModel>;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadMyCharacters(String token) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _myCharacters = await _characterApi.getCharacters(token);
      if (_myCharacters.isNotEmpty && _selectedCharacter == null) {
        _selectedCharacter = _myCharacters.first;
      }
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<CharacterModel?> createCharacter({
    required String token,
    required String personaId,
    required String avatarId,
    String? nickname,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final newChar = await _characterApi.createCharacter(
        token: token,
        personaId: personaId,
        avatarId: avatarId,
        nickname: nickname,
      );
      _myCharacters.add(newChar);
      _selectedCharacter = newChar;
      _isLoading = false;
      notifyListeners();
      return newChar;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
      return null;
    }
  }
}
