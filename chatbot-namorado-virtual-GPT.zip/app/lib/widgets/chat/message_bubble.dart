import 'package:flutter/material.dart';
import '../../models/message_model.dart';
import '../character/avatar_circle.dart';

class MessageBubble extends StatelessWidget {
  final MessageModel message;
  final String? characterAvatarUrl;
  final String? characterName;

  const MessageBubble({
    super.key,
    required this.message,
    this.characterAvatarUrl,
    this.characterName,
  });

  @override
  Widget build(BuildContext context) {
    final isUser = message.isUser;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser) ...[
            AvatarCircle(imageUrl: characterAvatarUrl, radius: 16, isOnline: false),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isUser ? const Color(0xFFE11D48) : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(isUser ? 18 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 18),
                ),
                border: !isUser ? Border.all(color: const Color(0xFFF1F5F9)) : null,
                boxShadow: [
                  BoxShadow(
                    color: isUser
                        ? const Color(0xFFE11D48).withOpacity(0.15)
                        : Colors.black.withOpacity(0.04),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Text(
                message.content,
                style: TextStyle(
                  fontSize: 15,
                  height: 1.4,
                  color: isUser ? Colors.white : const Color(0xFF0F172A),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
