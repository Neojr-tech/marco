import 'package:flutter/material.dart';

class SpeakerTag extends StatelessWidget {
  final String name;
  final bool isUser;

  const SpeakerTag({
    super.key,
    required this.name,
    required this.isUser,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 4),
      child: Text(
        name,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: isUser ? const Color(0xFFE11D48) : const Color(0xFF64748B),
        ),
      ),
    );
  }
}
