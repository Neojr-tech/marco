import 'package:flutter/material.dart';

class AvatarCircle extends StatelessWidget {
  final String? imageUrl;
  final double radius;
  final bool hasStory;
  final bool isOnline;

  const AvatarCircle({
    super.key,
    this.imageUrl,
    this.radius = 28,
    this.hasStory = false,
    this.isOnline = true,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          padding: EdgeInsets.all(hasStory ? 2.5 : 0),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: hasStory
                ? const LinearGradient(
                    colors: [Color(0xFFE11D48), Color(0xFFF43F5E), Color(0xFFFB7185)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : null,
          ),
          child: CircleAvatar(
            radius: radius,
            backgroundColor: const Color(0xFFF1F5F9),
            backgroundImage: imageUrl != null && imageUrl!.isNotEmpty
                ? NetworkImage(imageUrl!)
                : null,
            child: imageUrl == null || imageUrl!.isEmpty
                ? Icon(Icons.person, size: radius * 1.1, color: const Color(0xFF94A3B8))
                : null,
          ),
        ),
        if (isOnline)
          Positioned(
            right: 0,
            bottom: 0,
            child: Container(
              width: radius * 0.45,
              height: radius * 0.45,
              decoration: BoxDecoration(
                color: const Color(0xFF10B981),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
            ),
          ),
      ],
    );
  }
}
