import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../models/user_model.dart';

class UserApi {
  final String baseUrl;

  UserApi({this.baseUrl = '/api/user'});

  Future<UserModel> getProfile(String token) async {
    final response = await http.get(
      Uri.parse('$baseUrl/profile'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      return UserModel.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Falha ao carregar perfil do usuário');
    }
  }

  Future<void> completeOnboarding(String token, Map<String, dynamic> preferences) async {
    final response = await http.post(
      Uri.parse('$baseUrl/onboarding'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode(preferences),
    );

    if (response.statusCode != 200) {
      throw Exception('Falha ao concluir onboarding');
    }
  }
}
