import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../models/conversation_model.dart';
import '../../models/message_model.dart';

class ChatApi {
  final String baseUrl;

  ChatApi({this.baseUrl = '/api/chat'});

  Future<List<ConversationModel>> getConversations(String token) async {
    final response = await http.get(
      Uri.parse('$baseUrl/conversations'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((item) => ConversationModel.fromJson(item)).toList();
    } else {
      throw Exception('Falha ao listar conversas');
    }
  }

  Future<ConversationModel> startConversation(String token, String characterId) async {
    final response = await http.post(
      Uri.parse('$baseUrl/conversations'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'characterId': characterId}),
    );

    if (response.statusCode == 200 || response.statusCode == 201) {
      return ConversationModel.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Falha ao iniciar conversa');
    }
  }

  Future<Map<String, dynamic>> getConversationMessages(String token, String conversationId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/conversations/$conversationId/messages'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List msgs = data['messages'] ?? [];
      return {
        'conversation': ConversationModel.fromJson(data['conversation']),
        'character': data['character'],
        'messages': msgs.map((m) => MessageModel.fromJson(m)).toList(),
        'memorySnapshot': data['memorySnapshot'] ?? {},
      };
    } else {
      throw Exception('Falha ao carregar mensagens da conversa');
    }
  }

  Future<Map<String, dynamic>> sendMessage({
    required String token,
    required String conversationId,
    required String content,
    String contentType = 'text',
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/messages'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'conversationId': conversationId,
        'content': content,
        'contentType': contentType,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return {
        'userMessage': MessageModel.fromJson(data['userMessage']),
        'characterMessage': MessageModel.fromJson(data['characterMessage']),
        'memorySnapshot': data['memorySnapshot'] ?? {},
      };
    } else {
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'Falha ao enviar mensagem');
    }
  }
}
