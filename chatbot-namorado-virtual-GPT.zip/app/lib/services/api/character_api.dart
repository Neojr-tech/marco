import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../models/avatar_model.dart';
import '../../models/character_model.dart';

class CharacterApi {
  final String baseUrl;

  CharacterApi({this.baseUrl = '/api/character'});

  Future<List<AvatarModel>> getAvatars(String token) async {
    final response = await http.get(
      Uri.parse('$baseUrl/avatars'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((item) => AvatarModel.fromJson(item)).toList();
    } else {
      throw Exception('Falha ao carregar avatares');
    }
  }

  Future<List<PersonaModel>> getPersonas(String token) async {
    final response = await http.get(
      Uri.parse('$baseUrl/personas'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((item) => PersonaModel.fromJson(item)).toList();
    } else {
      throw Exception('Falha ao carregar personas');
    }
  }

  Future<List<CharacterModel>> getCharacters(String token) async {
    final response = await http.get(
      Uri.parse('$baseUrl/list'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((item) => CharacterModel.fromJson(item)).toList();
    } else {
      throw Exception('Falha ao carregar personagens');
    }
  }

  Future<CharacterModel> createCharacter({
    required String token,
    required String personaId,
    required String avatarId,
    String? nickname,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/create'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'personaId': personaId,
        'avatarId': avatarId,
        'nickname': nickname,
      }),
    );

    if (response.statusCode == 201 || response.statusCode == 200) {
      return CharacterModel.fromJson(jsonDecode(response.body));
    } else {
      final err = jsonDecode(response.body);
      throw Exception(err['error'] ?? 'Falha ao criar personagem');
    }
  }
}
