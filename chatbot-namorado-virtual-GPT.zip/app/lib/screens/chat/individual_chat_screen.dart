import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../state/auth_state.dart';
import '../../state/character_state.dart';
import '../../state/chat_state.dart';
import '../../widgets/character/avatar_circle.dart';
import '../../widgets/chat/message_bubble.dart';
import '../../widgets/chat/typing_indicator.dart';

class IndividualChatScreen extends StatefulWidget {
  final VoidCallback onOpenProfile;
  final VoidCallback onOpenSettings;

  const IndividualChatScreen({
    super.key,
    required this.onOpenProfile,
    required this.onOpenSettings,
  });

  @override
  State<IndividualChatScreen> createState() => _IndividualChatScreenState();
}

class _IndividualChatScreenState extends State<IndividualChatScreen> {
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initChat();
    });
  }

  void _initChat() async {
    final token = context.read<AuthState>().token;
    if (token == null) return;

    final charState = context.read<CharacterState>();
    final chatState = context.read<ChatState>();

    await charState.loadMyCharacters(token);
    if (charState.myCharacters.isNotEmpty) {
      final activeChar = charState.selectedCharacter ?? charState.myCharacters.first;
      await chatState.startConversation(token, activeChar.id);
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendMessage() async {
    final text = _textController.text.trim();
    if (text.isEmpty) return;

    _textController.clear();
    final token = context.read<AuthState>().token;
    if (token != null) {
      _scrollToBottom();
      await context.read<ChatState>().sendMessage(token, text);
      _scrollToBottom();
    }
  }

  @override
  void dispose() {
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final charState = context.watch<CharacterState>();
    final chatState = context.watch<ChatState>();
    final character = charState.selectedCharacter;
    final persona = character?.persona;
    final avatar = character?.avatar;

    final relationshipLevel = chatState.memorySnapshot['relationshipLevel'] ?? 1;

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        leadingWidth: 70,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: GestureDetector(
            onTap: widget.onOpenProfile,
            child: AvatarCircle(
              imageUrl: avatar?.imageUrl,
              radius: 20,
              isOnline: true,
            ),
          ),
        ),
        title: GestureDetector(
          onTap: widget.onOpenProfile,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                character?.displayName ?? 'Namorado Virtual',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0F172A),
                ),
              ),
              Row(
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      color: Color(0xFF10B981),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'Nível $relationshipLevel • Online',
                    style: const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                  ),
                ],
              ),
            ],
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.psychology_outlined, color: Color(0xFF64748B)),
            tooltip: 'Camada de Memória Ativa',
            onPressed: () {
              showModalBottomSheet(
                context: context,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                builder: (ctx) {
                  final mems = chatState.memorySnapshot['userMemories'] as List? ?? [];
                  final summary = chatState.memorySnapshot['conversationSummary'] ?? 'Sem resumo';

                  return Padding(
                    padding: const EdgeInsets.all(20),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: const [
                              Icon(Icons.memory, color: Color(0xFFE11D48)),
                              SizedBox(width: 8),
                              Text(
                                'Auditoria de Memória da Conversa',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          const Divider(height: 24),
                          const Text(
                            'Memória do Relacionamento (Relationship)',
                            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                          ),
                          Text('Nível afetivo: $relationshipLevel', style: const TextStyle(color: Color(0xFF64748B))),
                          const SizedBox(height: 12),
                          const Text(
                            'Resumo Contextual (ConversationMemory)',
                            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                          ),
                          Text(summary, style: const TextStyle(color: Color(0xFF64748B), fontSize: 12)),
                          const SizedBox(height: 12),
                          const Text(
                            'Fatos Aprendidos sobre Você (UserMemory)',
                            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                          ),
                          if (mems.isEmpty)
                            const Text('Nenhum fato extraído ainda.', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12))
                          else
                            ...mems.map((m) => Text('• $m', style: const TextStyle(color: Color(0xFF475569), fontSize: 12))),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined, color: Color(0xFF64748B)),
            onPressed: widget.onOpenSettings,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: chatState.isLoading && chatState.messages.isEmpty
                ? const Center(child: CircularProgressIndicator(color: Color(0xFFE11D48)))
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    itemCount: chatState.messages.length,
                    itemBuilder: (context, index) {
                      final msg = chatState.messages[index];
                      return MessageBubble(
                        message: msg,
                        characterAvatarUrl: avatar?.imageUrl,
                        characterName: character?.displayName,
                      );
                    },
                  ),
          ),
          if (chatState.isSending)
            TypingIndicator(personaName: character?.displayName ?? 'Namorado'),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: Color(0xFFF1F5F9))),
            ),
            child: SafeArea(
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0xFFE2E8F0)),
                      ),
                      child: TextField(
                        controller: _textController,
                        textCapitalization: TextCapitalization.sentences,
                        decoration: const InputDecoration(
                          hintText: 'Escreva uma mensagem...',
                          hintStyle: TextStyle(color: Color(0xFF94A3B8), fontSize: 14),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(vertical: 10),
                        ),
                        onSubmitted: (_) => _sendMessage(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    decoration: const BoxDecoration(
                      color: Color(0xFFE11D48),
                      shape: BoxShape.circle,
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                      onPressed: _sendMessage,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
