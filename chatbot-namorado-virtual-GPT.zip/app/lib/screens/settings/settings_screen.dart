import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../state/auth_state.dart';
import '../../widgets/common/app_button.dart';

class SettingsScreen extends StatelessWidget {
  final VoidCallback onBack;
  final VoidCallback onSwitchCharacter;

  const SettingsScreen({
    super.key,
    required this.onBack,
    required this.onSwitchCharacter,
  });

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthState>();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF0F172A)),
          onPressed: onBack,
        ),
        title: const Text(
          'Configurações',
          style: TextStyle(color: Color(0xFF0F172A), fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.person_add_alt_1, color: Color(0xFFE11D48)),
              title: const Text('Criar ou trocar de namorado', style: TextStyle(fontWeight: FontWeight.w600)),
              subtitle: const Text('Configurar uma nova persona ou avatar'),
              trailing: const Icon(Icons.chevron_right),
              onTap: onSwitchCharacter,
            ),
            const Divider(height: 24),
            const Text(
              'Informações do Protótipo',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF64748B)),
            ),
            const SizedBox(height: 12),
            _infoTile('Gateway de Conversação', 'Google Gemini 3.7 Flash (Provisório)'),
            _infoTile('Autenticação', 'JWT Bearer'),
            _infoTile('Usuário Conectado', auth.user?.displayName ?? 'Usuário'),
            _infoTile('E-mail', auth.user?.email ?? '-'),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: AppButton(
                label: 'Sair da Conta',
                isSecondary: true,
                onPressed: () {
                  auth.logout();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoTile(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, color: Color(0xFF64748B))),
          Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Color(0xFF0F172A))),
        ],
      ),
    );
  }
}
