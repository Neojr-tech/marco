import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../state/character_state.dart';
import '../../state/chat_state.dart';
import '../../widgets/character/avatar_circle.dart';

class CharacterProfileScreen extends StatelessWidget {
  final VoidCallback onBack;

  const CharacterProfileScreen({super.key, required this.onBack});

  @override
  Widget build(BuildContext context) {
    final charState = context.watch<CharacterState>();
    final chatState = context.watch<ChatState>();
    final character = charState.selectedCharacter;
    final persona = character?.persona;
    final avatar = character?.avatar;
    final relationshipLevel = chatState.memorySnapshot['relationshipLevel'] ?? 1;
    final userMems = chatState.memorySnapshot['userMemories'] as List? ?? [];

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF0F172A)),
          onPressed: onBack,
        ),
        title: const Text(
          'Perfil do Namorado',
          style: TextStyle(color: Color(0xFF0F172A), fontWeight: FontWeight.bold),
        ),
      ),
      body: character == null
          ? const Center(child: Text('Nenhum personagem selecionado.'))
          : SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              child: Column(
                children: [
                  Center(
                    child: AvatarCircle(
                      imageUrl: avatar?.imageUrl,
                      radius: 52,
                      hasStory: true,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    character.displayName,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0F172A),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Nível de Relacionamento: $relationshipLevel',
                    style: const TextStyle(
                      fontSize: 14,
                      color: Color(0xFFE11D48),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 24),
                  _buildSection(
                    title: 'Personalidade & Estilo',
                    icon: Icons.psychology,
                    content: persona?.personalitySummary ?? 'Personalidade amável.',
                  ),
                  const SizedBox(height: 16),
                  _buildSection(
                    title: 'Como ele conversa com você',
                    icon: Icons.chat_bubble_outline,
                    content: persona?.speechStyle ?? 'Afetuoso e atencioso.',
                  ),
                  if (persona?.backstory != null && persona!.backstory.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    _buildSection(
                      title: 'História & Origem',
                      icon: Icons.auto_stories_outlined,
                      content: persona.backstory,
                    ),
                  ],
                  const SizedBox(height: 16),
                  _buildSection(
                    title: 'Fatos que ele aprendeu sobre você',
                    icon: Icons.memory,
                    content: userMems.isEmpty
                        ? 'Ele ainda está conhecendo você. Conforme conversarem, as memórias aparecerão aqui.'
                        : userMems.map((m) => '• $m').join('\n'),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildSection({required String title, required IconData icon, required String content}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF1F5F9)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: const Color(0xFFE11D48)),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0F172A),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            content,
            style: const TextStyle(fontSize: 13, color: Color(0xFF475569), height: 1.4),
          ),
        ],
      ),
    );
  }
}
