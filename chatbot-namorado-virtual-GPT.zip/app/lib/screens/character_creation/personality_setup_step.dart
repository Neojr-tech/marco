import 'package:flutter/material.dart';
import '../../models/character_model.dart';
import '../../widgets/common/app_text_field.dart';

class PersonalitySetupStep extends StatelessWidget {
  final List<PersonaModel> personas;
  final String? selectedPersonaId;
  final ValueChanged<String> onSelectPersona;
  final TextEditingController nicknameController;

  const PersonalitySetupStep({
    super.key,
    required this.personas,
    required this.selectedPersonaId,
    required this.onSelectPersona,
    required this.nicknameController,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '2. Escolha a Personalidade & Nome',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF0F172A),
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'Como você quer que ele converse com você?',
          style: TextStyle(fontSize: 14, color: Color(0xFF64748B)),
        ),
        const SizedBox(height: 20),
        AppTextField(
          label: 'Apelido carinhoso (opcional)',
          hintText: 'Ex: Davi, Meu Amor, Théo...',
          controller: nicknameController,
          prefixIcon: Icons.edit_outlined,
        ),
        const SizedBox(height: 20),
        const Text(
          'Personalidades Disponíveis',
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Color(0xFF334155),
          ),
        ),
        const SizedBox(height: 10),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: personas.length,
          itemBuilder: (context, index) {
            final persona = personas[index];
            final isSelected = persona.id == selectedPersonaId;

            return GestureDetector(
              onTap: () => onSelectPersona(persona.id),
              child: Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isSelected ? const Color(0xFFFFF1F2) : Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: isSelected ? const Color(0xFFE11D48) : const Color(0xFFE2E8F0),
                    width: isSelected ? 2 : 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          persona.name,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: isSelected ? const Color(0xFFE11D48) : const Color(0xFF0F172A),
                          ),
                        ),
                        if (isSelected)
                          const Icon(Icons.check_circle, color: Color(0xFFE11D48), size: 20),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      persona.personalitySummary,
                      style: const TextStyle(fontSize: 13, color: Color(0xFF475569), height: 1.4),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.chat_bubble_outline, size: 14, color: Color(0xFF94A3B8)),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            'Estilo: ${persona.speechStyle}',
                            style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontStyle: FontStyle.italic),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
