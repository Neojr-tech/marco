import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../state/auth_state.dart';
import '../../state/character_state.dart';
import '../../widgets/common/app_button.dart';
import 'avatar_picker_step.dart';
import 'personality_setup_step.dart';

class CharacterCreationScreen extends StatefulWidget {
  final VoidCallback onCharacterCreated;

  const CharacterCreationScreen({super.key, required this.onCharacterCreated});

  @override
  State<CharacterCreationScreen> createState() => _CharacterCreationScreenState();
}

class _CharacterCreationScreenState extends State<CharacterCreationScreen> {
  int _currentStep = 0;
  String? _selectedAvatarId;
  String? _selectedPersonaId;
  final _nicknameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final token = context.read<AuthState>().token;
      if (token != null) {
        context.read<CharacterState>().loadCreationData(token);
      }
    });
  }

  @override
  void dispose() {
    _nicknameController.dispose();
    super.dispose();
  }

  void _next() async {
    if (_currentStep == 0) {
      if (_selectedAvatarId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Por favor, selecione um avatar.')),
        );
        return;
      }
      setState(() => _currentStep = 1);
    } else {
      if (_selectedPersonaId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Por favor, selecione uma personalidade.')),
        );
        return;
      }

      final token = context.read<AuthState>().token;
      if (token != null) {
        final char = await context.read<CharacterState>().createCharacter(
          token: token,
          personaId: _selectedPersonaId!,
          avatarId: _selectedAvatarId!,
          nickname: _nicknameController.text.trim().isNotEmpty
              ? _nicknameController.text.trim()
              : null,
        );

        if (char != null && mounted) {
          widget.onCharacterCreated();
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CharacterState>();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: _currentStep > 0
            ? IconButton(
                icon: const Icon(Icons.arrow_back, color: Color(0xFF0F172A)),
                onPressed: () => setState(() => _currentStep = 0),
              )
            : null,
        title: const Text(
          'Personalizar Namorado',
          style: TextStyle(color: Color(0xFF0F172A), fontWeight: FontWeight.bold, fontSize: 18),
        ),
      ),
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFE11D48)))
          : SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                child: Column(
                  children: [
                    if (_currentStep == 0)
                      AvatarPickerStep(
                        avatars: state.avatars,
                        selectedAvatarId: _selectedAvatarId ?? (state.avatars.isNotEmpty ? state.avatars.first.id : null),
                        onSelectAvatar: (id) => setState(() => _selectedAvatarId = id),
                      )
                    else
                      PersonalitySetupStep(
                        personas: state.personas,
                        selectedPersonaId: _selectedPersonaId ?? (state.personas.isNotEmpty ? state.personas.first.id : null),
                        onSelectPersona: (id) => setState(() => _selectedPersonaId = id),
                        nicknameController: _nicknameController,
                      ),
                    const SizedBox(height: 32),
                    SizedBox(
                      width: double.infinity,
                      child: AppButton(
                        label: _currentStep == 0 ? 'Avançar para Personalidade' : 'Concluir Criação',
                        onPressed: _next,
                        isLoading: state.isLoading,
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
    );
  }
}
