/**
 * Push Notifications Mobile (FCM / APNs) — A DEFINIR
 */
class PushNotificationsMobile {
  static Future<void> initialize() async {
    // Preparado para integração FCM em dispositivo móvel real
  }
}
