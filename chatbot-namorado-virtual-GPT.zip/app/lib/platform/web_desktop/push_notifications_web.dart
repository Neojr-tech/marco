/**
 * Push Notifications Web / Desktop — A DEFINIR
 */
class PushNotificationsWeb {
  static Future<void> initialize() async {
    // Preparado para Web Push / ServiceWorker
  }
}
