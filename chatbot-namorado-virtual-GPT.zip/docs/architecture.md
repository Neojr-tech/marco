# Arquitetura Técnica — Chatbot Namorado Virtual

## 1. Visão Geral
O sistema **Chatbot Namorado Virtual** é uma plataforma desenhada para permitir que usuários criem, configurem e mantenham conversas interativas com personagens virtuais dotados de inteligência artificial e memória contextual persistente multicamada.

## 2. Princípios Arquiteturais Fundamentais

### 2.1 Separação Rígida entre Persona, Avatar e Character
- **Persona**: Entidade que encapsula a inteligência e identidade psicológica do personagem (personalidade, estilo de fala, história pregressa, regras comportamentais).
- **Avatar**: Entidade de representação visual e sensorial (imagem, referências futuras de voz e vídeo).
- **Character**: A entidade de junção que conecta `User`, `Persona` e `Avatar`. Permite que o mesmo Avatar seja reutilizado por múltiplas Personas, e que um Usuário personalize seu companheiro virtual mantendo estruturas genéricas.

### 2.2 Isolamento da Camada de IA (`ai-gateway/`)
Nenhum componente de frontend (telas/widgets) ou serviço de negócio (serviço de chat, memória, personagens) tem permissão de chamar diretamente um provedor ou SDK de IA externo.
Todas as interações são mediadas pelo `ai-gateway/`, com sub-gateways especializados:
- `conversation_gateway` (ativo no protótipo)
- `vision_gateway` (preparado)
- `image_gateway` (preparado)
- `video_gateway` (preparado)
- `voice_gateway` (preparado)

### 2.3 Camadas de Memória Contextual
Antes de despachar o contexto para o `ai-gateway`, o serviço de chat orquestra e monta o contexto a partir de 4 camadas:
1. **ConversationMemory**: Resumo acumulado e pontos chave da conversa atual.
2. **CharacterMemory**: Fatos imutáveis e regras centrais da Persona.
3. **UserMemory**: Fatos, gostos e preferências extraídos das mensagens do usuário.
4. **Relationship**: Estado afetivo, nível de proximidade e marcos (milestones) entre Usuário e Personagem.
*(GroupMemory permanece estruturada para conversas em grupo futuras).*

### 2.4 Fluxo de Execução Frontend/Backend
```
Flutter Screen
   ↓
API Service (chat_api.dart, etc.)
   ↓
HTTP / JSON (REST)
   ↓
Backend Route (chat.routes.js)
   ↓
Service Layer (individual_chat.service.js)
   ↓
Memory Services (Assembly)
   ↓
AI Gateway (conversation_gateway.js)
   ↓
AI Provider Response
   ↓
Message Persistence & Memory Update
   ↓
Frontend State (chat_state.dart) & UI
```
