# Sistema de Memória Multicamada — Chatbot Namorado Virtual

## 1. As 5 Camadas de Memória

### 1.1 CharacterMemory
- **Escopo**: Fixa e perene à Persona.
- **Exemplos**: Aniversário fictício, prato favorito, profissão, hobbies, medos da Persona.
- **Injeção**: Sempre incluída nas instruções do sistema do personagem.

### 1.2 UserMemory
- **Escopo**: Fatos compartilhados pelo Usuário ao longo de conversas.
- **Exemplos**: "O usuário trabalha com design", "Tem um gato chamado Pipoca", "Mora em Curitiba".
- **Origem**: Extração a partir de `messages` com referência a `source_message_id`.

### 1.3 Relationship
- **Escopo**: Vínculo afetivo dinâmico Usuário ↔ Personagem.
- **Atributos**: Nível de intimidade (`level`), apelidos carinhosos autorizados, marcos atingidos (`milestones` como 'Primeiro encontro', '100 mensagens trocadas').

### 1.4 ConversationMemory
- **Escopo**: Resumo condensado de uma conversa específica.
- **Função**: Evitar estouro de janela de contexto do LLM preservando decisões e conversas passadas.

### 1.5 GroupMemory (Futuro)
- **Escopo**: Interações e memórias compartilhadas em conversas de grupo com múltiplos personagens.

---

## 2. Pipeline de Montagem de Contexto
```
[Mensagem do Usuário Recebida]
           │
           ▼
[1. Carregar CharacterMemory da Persona]
           │
           ▼
[2. Carregar UserMemory do Usuário]
           │
           ▼
[3. Carregar Relationship do par User-Character]
           │
           ▼
[4. Carregar ConversationMemory (Resumo Histórico)]
           │
           ▼
[5. Carregar últimas N Mensagens recentes da conversa]
           │
           ▼
[6. Montar Prompt Unificado via memory_injection.prompt.md]
           │
           ▼
[7. Despachar para conversation_gateway.js]
```
