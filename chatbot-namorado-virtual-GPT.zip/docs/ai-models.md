# Modelos e Gateways de IA — Chatbot Namorado Virtual

## 1. Isolamento através do AI Gateway
A arquitetura do projeto define que nenhum componente externo acessa diretamente SDKs de IA.

```
+-------------------------------------------------------------+
|                      Backend Services                       |
|           (individual_chat.service.js, etc.)                |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|                         AI-GATEWAY                          |
|  +--------------------+  +-------------------------------+  |
|  |conversation_gateway|  | vision / image / video / voice|  |
|  +--------------------+  +-------------------------------+  |
+-------------------------------------------------------------+
                              |
                              v
+-------------------------------------------------------------+
|                  AI Providers (Configurable)                |
|             Google Gemini / OpenAI / Anthropic              |
+-------------------------------------------------------------+
```

## 2. Status dos Gateways no Protótipo

| Gateway | Finalidade | Status Protótipo | Provedor Provisório |
| :--- | :--- | :--- | :--- |
| `conversation_gateway` | Diálogo, roleplay, estilo de fala | **Ativo e Funcional** | Google Gemini 3.7 Flash (`DECISÃO PROVISÓRIA — A VALIDAR`) |
| `vision_gateway` | Reconhecimento de fotos enviadas pelo usuário | Preparado (Interface pronta) | A DEFINIR |
| `image_gateway` | Envio de selfies/fotos geradas pelo personagem | Preparado (Interface pronta) | A DEFINIR |
| `video_gateway` | Vídeos curtos do avatar | Preparado (Interface pronta) | A DEFINIR |
| `voice_gateway` | Síntese de áudio (TTS) com voz do avatar | Preparado (Interface pronta) | A DEFINIR |

## 3. Formato Padrão de Entrada do `conversation_gateway`
```javascript
{
  systemInstruction: string, // Prompts base + Persona + Regras de comportamento
  relationshipContext: string, // Nível afetivo e marcos
  userMemories: string[], // Fatos conhecidos sobre o usuário
  conversationSummary: string, // Resumo de memórias anteriores
  history: Array<{ role: 'user' | 'model', text: string }>,
  latestUserMessage: string
}
```
