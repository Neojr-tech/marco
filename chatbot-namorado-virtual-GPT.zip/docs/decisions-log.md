# Registro de Decisões Técnicas (Decisions Log) — Chatbot Namorado Virtual

Este documento registra todas as decisões de projeto e documenta explicitamente as **DECISÕES PROVISÓRIAS — A VALIDAR** adotadas para viabilizar a execução do protótipo funcional no ambiente atual.

---

## 1. Provedor de IA Provisório para Conversação
- **Status**: `DECISÃO PROVISÓRIA — A VALIDAR`
- **Decisão Tomada**: Utilização do modelo Google Gemini 3.7 Flash via SDK `@google/genai` no gateway de conversação do backend (`conversation_gateway.js`).
- **Motivo**: Necessidade de prover uma IA conversacional real de alta fluidez em língua portuguesa para validar o fluxo de montagem de contexto, histórico e memória.
- **Impacto**: O backend isola 100% da chamada dentro de `ai-gateway/conversation/conversation_gateway.js`. Nenhuma rota, serviço de negócio ou tela do app importa o SDK ou depende de especificidades do Gemini.
- **Como Substituir Posteriormente**: Basta trocar a implementação interna de `conversation_gateway.js` (ou configurar chave de provider em `ai_providers.config.js`) por OpenAI GPT-4o, Claude 3.5 Sonnet, Llama 3 local ou outro LLM sem alterar nenhuma linha dos services ou do frontend.

---

## 2. Mecanismo Provisório de Autenticação
- **Status**: `DECISÃO PROVISÓRIA — A VALIDAR`
- **Decisão Tomada**: Autenticação baseada em JWT (JSON Web Token) com hash SHA-256/bcrypt simplificado e middleware de autorização Bearer Token no backend (`auth.middleware.js`).
- **Motivo**: Permitir sessões de teste no protótipo, isolar dados entre múltiplos usuários e validar a proteção das rotas de personagem e chat.
- **Impacto**: Rotas protegidas exigem o cabeçalho `Authorization: Bearer <token>`. O frontend armazena a sessão no `session_storage.dart`.
- **Como Substituir Posteriormente**: Pode ser substituído por OAuth 2.0 / OpenID Connect, Firebase Auth, Supabase Auth ou Auth0 apenas adaptando `auth.service.js` e `auth.middleware.js`.

---

## 3. Protocolo de Comunicação do Chat
- **Status**: `DECISÃO PROVISÓRIA — A VALIDAR`
- **Decisão Tomada**: Comunicação HTTP REST com endpoints `POST /api/chat/messages` e `GET /api/chat/conversations/:id/messages`.
- **Motivo**: Simplicidade e robustez para validação determinística do ciclo de requisição-resposta no protótipo inicial.
- **Impacto**: O cliente envia a mensagem e aguarda a resposta do backend que já inclui a mensagem do usuário salva e a resposta do personagem gerada pelo gateway.
- **Como Substituir Posteriormente**: O backend e o Flutter service (`chat_api.dart`) estão preparados para migração transparente para WebSocket (ex: `socket.io` ou `web_socket_channel`) através de hooks no `chat_state.dart`.

---

## 4. Valores Provisórios para `Persona.gender`
- **Status**: `DECISÃO PROVISÓRIA — A VALIDAR`
- **Decisão Tomada**: Suporte flexível a strings livres com opções padrão no UI (`"masculino"`, `"feminino"`, `"não-binário"`, `"outro"`).
- **Motivo**: Permitir seleção e teste imediato na tela de criação de personagem (`personality_setup_step.dart`).
- **Impacto**: Não impõe constraints rígidas no banco, aceitando qualquer string UTF-8.
- **Como Substituir Posteriormente**: Aplicar enum rígido no PostgreSQL e validação no DTO do `persona.service.js`.

---

## 5. Regra Provisória de Atualização de `ConversationMemory` e `UserMemory`
- **Status**: `DECISÃO PROVISÓRIA — A VALIDAR`
- **Decisão Tomada**: Extração heurística/IA básica disparada a cada 4 turnos de mensagem ou quando fatos explícitos são informados (ex: "meu nome é...", "eu gosto de...").
- **Motivo**: Demonstrar visualmente a evolução da memória no painel de contexto do protótipo sem onerar a latência de cada mensagem.
- **Impacto**: O `conversation_memory.service.js` mantém o resumo atualizado progressivamente.
- **Como Substituir Posteriormente**: Integrar job assíncrono em background (ex: BullMQ / Celery) ou pipeline de embeddings vetoriais (RAG com PGVector).

---

## 6. Camada de Persistência Provisória no Ambiente de Sandbox
- **Status**: `DECISÃO PROVISÓRIA — A VALIDAR`
- **Decisão Tomada**: Camada de Repositório em memória com persistência local (State Store) compatível 1:1 com os models relacionais SQL do PostgreSQL. Os scripts de migração DDL PostgreSQL foram gerados integralmente na pasta `database/migrations/` e documentados em `docs/database-schema.md`.
- **Motivo**: O ambiente em sandbox do AI Studio roda em contêiner Node/Vite web sem servidor PostgreSQL local rodando em background; o store emula as constraints relacionais e chaves estrangeiras com fidelidade.
- **Impacto**: Permite teste imediato sem necessidade de provisionamento externo de banco.
- **Como Substituir Posteriormente**: Bastará conectar a string `DATABASE_URL` no `database.config.js` apontando para o PostgreSQL de produção via `pg` / `knex` / `drizzle`.
