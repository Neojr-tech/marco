# API Reference — Chatbot Namorado Virtual

Todas as respostas são estruturadas em JSON. Rotas autenticadas exigem `Authorization: Bearer <token>`.

---

## 1. Autenticação (`/api/auth`)

### `POST /api/auth/register`
Cadastra um novo usuário.
- **Body**:
  ```json
  {
    "email": "user@example.com",
    "password": "secretpassword",
    "displayName": "Lucas Silva",
    "birthDate": "2000-05-12"
  }
  ```
- **Response (201)**:
  ```json
  {
    "token": "jwt_token_here",
    "user": {
      "id": "uuid",
      "email": "user@example.com",
      "displayName": "Lucas Silva",
      "status": "active"
    }
  }
  ```

### `POST /api/auth/login`
Autentica com e-mail e senha.
- **Body**:
  ```json
  {
    "email": "user@example.com",
    "password": "secretpassword"
  }
  ```
- **Response (200)**: Token JWT e dados do usuário.

---

## 2. Usuário (`/api/user`)

### `GET /api/user/profile` (Protected)
Obtém os dados do usuário autenticado.

### `POST /api/user/onboarding` (Protected)
Conclui o fluxo de onboarding inicial.

---

## 3. Personagens, Personas & Avatares (`/api/character`)

### `GET /api/character/avatars` (Protected)
Lista avatares disponíveis do sistema ou do usuário.

### `POST /api/character/avatars` (Protected)
Cria um novo avatar customizado.

### `GET /api/character/personas` (Protected)
Lista personas pré-definidas ou do usuário.

### `POST /api/character/personas` (Protected)
Cria uma nova persona com personalidade, estilo de fala e regras.

### `GET /api/character/list` (Protected)
Lista os personagens ativos do usuário (Character = Persona + Avatar + User).

### `POST /api/character/create` (Protected)
Cria um Character conectando Persona e Avatar.
- **Body**:
  ```json
  {
    "personaId": "uuid-persona",
    "avatarId": "uuid-avatar",
    "nickname": "Davi Carinhoso"
  }
  ```

---

## 4. Chat & Conversação (`/api/chat`)

### `GET /api/chat/conversations` (Protected)
Lista as conversas do usuário.

### `POST /api/chat/conversations` (Protected)
Inicia uma nova conversa individual com um Character.
- **Body**:
  ```json
  {
    "characterId": "uuid-character",
    "type": "individual"
  }
  ```

### `GET /api/chat/conversations/:id/messages` (Protected)
Retorna histórico de mensagens e contexto de memória associado.

### `POST /api/chat/messages` (Protected)
Envia uma mensagem na conversa e dispara o ciclo de memória e IA.
- **Body**:
  ```json
  {
    "conversationId": "uuid-conversation",
    "content": "Oi amor, como foi o seu dia?",
    "contentType": "text"
  }
  ```
- **Response (200)**:
  ```json
  {
    "userMessage": { "id": "uuid", "content": "...", "senderType": "user" },
    "characterMessage": { "id": "uuid", "content": "Oi meu bem! Meu dia foi ótimo pensando em você...", "senderType": "character" },
    "memoryContext": {
      "relationshipLevel": 1,
      "userMemoriesCount": 2,
      "conversationSummary": "..."
    }
  }
  ```
